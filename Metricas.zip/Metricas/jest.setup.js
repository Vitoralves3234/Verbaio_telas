/* eslint-env jest */

global.IS_REACT_ACT_ENVIRONMENT = true;

jest.mock("react-native-safe-area-context", () => {
  const React = require("react");

  return {
    SafeAreaProvider: ({ children }) =>
      React.createElement(React.Fragment, null, children),
    useSafeAreaInsets: () => ({ bottom: 0, left: 0, right: 0, top: 0 }),
  };
});

jest.mock("react-native-blob-util", () => ({
  __esModule: true,
  default: {
    MediaCollection: {
      copyToMediaStore: jest.fn(async () => "content://downloads/metricas.pdf"),
    },
    android: {
      actionViewIntent: jest.fn(async () => undefined),
    },
    fs: {
      cp: jest.fn(async () => undefined),
      dirs: {
        CacheDir: "/tmp/verbaio-cache",
        DocumentDir: "/tmp/verbaio-documents",
        DownloadDir: "/tmp/verbaio-downloads",
      },
      writeFile: jest.fn(async () => undefined),
    },
    ios: {
      previewDocument: jest.fn(),
    },
  },
}));

jest.mock("react-native-share", () => ({
  __esModule: true,
  default: {
    open: jest.fn(async () => ({ success: true })),
  },
}));

jest.mock("react-native-print", () => ({
  print: jest.fn(async () => undefined),
}));
