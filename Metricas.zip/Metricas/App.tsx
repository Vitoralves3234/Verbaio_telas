import React from "react";
import { StatusBar } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { MetricsFlow } from "./src/features/metrics/screens/MetricsFlow";
import { colors } from "./src/theme/colors";

function App() {
  return (
    <SafeAreaProvider>
      <StatusBar
        backgroundColor={colors.teal}
        barStyle="light-content"
        translucent={false}
      />
      <MetricsFlow />
    </SafeAreaProvider>
  );
}

export default App;
