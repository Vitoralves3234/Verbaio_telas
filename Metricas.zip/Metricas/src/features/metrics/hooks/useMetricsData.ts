import { useCallback, useEffect, useState } from "react";

import { loadMetricsData } from "../data/metricsDataSource";
import { MetricsDataSource, MetricsPayload } from "../types/metrics";

const emptyPayload: MetricsPayload = {
  patient: { id: "", name: "Paciente não informado" },
  phases: [],
  records: [],
};

export function useMetricsData(
  dataSource: MetricsDataSource = loadMetricsData
) {
  const [data, setData] = useState<MetricsPayload>(emptyPayload);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const nextData = await dataSource();
      const records = nextData.records ?? [];
      setData({
        patient: nextData.patient ?? emptyPayload.patient,
        phases: Array.from(
          new Set([
            ...(nextData.phases ?? []),
            ...records.map((record) => record.phase),
          ])
        ),
        records,
      });
    } catch (cause) {
      setError(
        cause instanceof Error
          ? cause.message
          : "Não foi possível carregar as métricas."
      );
    } finally {
      setLoading(false);
    }
  }, [dataSource]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { data, error, loading, refresh };
}
