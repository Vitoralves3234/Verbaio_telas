export type MetricSkillId =
  | "matching"
  | "identification"
  | "sentences"
  | "interpretation";

export type MetricsPeriod = 7 | 30 | 90 | "all";

export type MetricRecord = {
  attempts: number;
  correctAnswers: number;
  id: string;
  occurredAt: string;
  phase: string;
  skill: MetricSkillId;
};

export type MetricsPatient = {
  id: string;
  name: string;
};

export type MetricsPayload = {
  patient: MetricsPatient;
  phases: string[];
  records: MetricRecord[];
};

export type MetricsDataSource = () => Promise<MetricsPayload>;

export type MetricsFilter = {
  period: MetricsPeriod;
  phase: string;
};

export type GeneralMetrics = {
  correctAnswers: number;
  errorRate: number;
  errors: number;
  successRate: number;
  totalAttempts: number;
};

export type SkillMetric = {
  accentColor: string;
  hits: number;
  icon: string;
  id: MetricSkillId;
  score: number;
  softColor: string;
  title: string;
  totalAttempts: number;
};

export type EvolutionSeries = {
  color: string;
  id: MetricSkillId;
  label: string;
  values: Array<number | null>;
};

export type MetricsDashboard = {
  evolutionDates: string[];
  evolutionSeries: EvolutionSeries[];
  general: GeneralMetrics;
  hasData: boolean;
  recordCount: number;
  skills: SkillMetric[];
};

export type GeneratedMetricsPdf = {
  fileName: string;
  generatedAt: string;
  localPath: string;
  patientName: string;
  phaseLabel: string;
  periodLabel: string;
};
