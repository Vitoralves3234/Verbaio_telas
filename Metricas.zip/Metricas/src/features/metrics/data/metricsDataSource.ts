import { MetricsDataSource } from "../types/metrics";

/**
 * Ponto de integração com o banco de dados ou API.
 * Substitua o retorno desta função pelos dados reais do paciente.
 */
export const loadMetricsData: MetricsDataSource = async () => ({
  patient: {
    id: "",
    name: "Paciente não informado",
  },
  phases: ["Fase 1", "Fase 2", "Fase 3"],
  records: [],
});
