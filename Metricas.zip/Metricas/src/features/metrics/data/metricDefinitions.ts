import { colors } from "../../../theme/colors";
import { MetricSkillId, MetricsPeriod } from "../types/metrics";

export type SkillDefinition = {
  accentColor: string;
  icon: string;
  id: MetricSkillId;
  label: string;
  softColor: string;
  title: string;
};

export const skillDefinitions: SkillDefinition[] = [
  {
    accentColor: colors.teal,
    icon: "P",
    id: "matching",
    label: "Pareamentos",
    softColor: colors.tealSoft,
    title: "Acertos em pareamentos",
  },
  {
    accentColor: colors.yellowDark,
    icon: "I",
    id: "identification",
    label: "Identificação",
    softColor: colors.yellowSoft,
    title: "Acertos em identificação",
  },
  {
    accentColor: colors.blue,
    icon: "F",
    id: "sentences",
    label: "Formação de frases",
    softColor: colors.blueSoft,
    title: "Acertos em formação de frases",
  },
  {
    accentColor: colors.purple,
    icon: "C",
    id: "interpretation",
    label: "Interpretação",
    softColor: colors.purpleSoft,
    title: "Acertos em interpretação (comunicação)",
  },
];

export const periodOptions: Array<{
  label: string;
  shortLabel: string;
  value: MetricsPeriod;
}> = [
  { label: "Últimos 7 dias", shortLabel: "7 dias", value: 7 },
  { label: "Últimos 30 dias", shortLabel: "30 dias", value: 30 },
  { label: "Últimos 90 dias", shortLabel: "90 dias", value: 90 },
  { label: "Todo o período", shortLabel: "Tudo", value: "all" },
];

export function getPeriodLabel(period: MetricsPeriod) {
  return (
    periodOptions.find((option) => option.value === period)?.label ??
    "Todo o período"
  );
}
