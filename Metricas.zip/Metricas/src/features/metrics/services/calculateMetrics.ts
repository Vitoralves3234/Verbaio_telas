import { skillDefinitions } from "../data/metricDefinitions";
import {
  MetricRecord,
  MetricsDashboard,
  MetricsFilter,
} from "../types/metrics";

const DAY_IN_MS = 24 * 60 * 60 * 1000;

function roundPercentage(value: number, total: number) {
  if (total <= 0) {
    return 0;
  }

  return Math.round((value / total) * 100);
}

function normalizeRecord(record: MetricRecord): MetricRecord | null {
  const date = new Date(record.occurredAt);
  const attempts = Math.max(0, Math.round(Number(record.attempts) || 0));
  const correctAnswers = Math.min(
    attempts,
    Math.max(0, Math.round(Number(record.correctAnswers) || 0))
  );

  if (Number.isNaN(date.getTime()) || attempts === 0) {
    return null;
  }

  return { ...record, attempts, correctAnswers };
}

function isInsidePeriod(
  occurredAt: string,
  period: MetricsFilter["period"],
  now: Date
) {
  if (period === "all") {
    return true;
  }

  const occurredTime = new Date(occurredAt).getTime();
  const startTime = now.getTime() - period * DAY_IN_MS;
  return occurredTime >= startTime && occurredTime <= now.getTime();
}

function dateKey(occurredAt: string) {
  return new Date(occurredAt).toISOString().slice(0, 10);
}

function formatDate(key: string) {
  const [, month, day] = key.split("-");
  return `${day}/${month}`;
}

export function calculateMetrics(
  records: MetricRecord[],
  filter: MetricsFilter,
  now = new Date()
): MetricsDashboard {
  const filteredRecords = records
    .map(normalizeRecord)
    .filter((record): record is MetricRecord => record !== null)
    .filter((record) => filter.phase === "all" || record.phase === filter.phase)
    .filter((record) => isInsidePeriod(record.occurredAt, filter.period, now));

  const totalAttempts = filteredRecords.reduce(
    (total, record) => total + record.attempts,
    0
  );
  const correctAnswers = filteredRecords.reduce(
    (total, record) => total + record.correctAnswers,
    0
  );
  const errors = totalAttempts - correctAnswers;

  const skills = skillDefinitions.map((definition) => {
    const skillRecords = filteredRecords.filter(
      (record) => record.skill === definition.id
    );
    const skillAttempts = skillRecords.reduce(
      (total, record) => total + record.attempts,
      0
    );
    const hits = skillRecords.reduce(
      (total, record) => total + record.correctAnswers,
      0
    );

    return {
      accentColor: definition.accentColor,
      hits,
      icon: definition.icon,
      id: definition.id,
      score: roundPercentage(hits, skillAttempts),
      softColor: definition.softColor,
      title: definition.title,
      totalAttempts: skillAttempts,
    };
  });

  const evolutionKeys = Array.from(
    new Set(filteredRecords.map((record) => dateKey(record.occurredAt)))
  )
    .sort()
    .slice(-6);

  const evolutionSeries = skillDefinitions.map((definition) => ({
    color: definition.accentColor,
    id: definition.id,
    label: definition.label,
    values: evolutionKeys.map((key) => {
      const dayRecords = filteredRecords.filter(
        (record) =>
          dateKey(record.occurredAt) === key && record.skill === definition.id
      );
      const attempts = dayRecords.reduce(
        (total, record) => total + record.attempts,
        0
      );
      const hits = dayRecords.reduce(
        (total, record) => total + record.correctAnswers,
        0
      );

      return attempts > 0 ? roundPercentage(hits, attempts) : null;
    }),
  }));

  return {
    evolutionDates: evolutionKeys.map(formatDate),
    evolutionSeries,
    general: {
      correctAnswers,
      errorRate: roundPercentage(errors, totalAttempts),
      errors,
      successRate: roundPercentage(correctAnswers, totalAttempts),
      totalAttempts,
    },
    hasData: totalAttempts > 0,
    recordCount: filteredRecords.length,
    skills,
  };
}
