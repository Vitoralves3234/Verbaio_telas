import { Platform } from "react-native";
import ReactNativeBlobUtil from "react-native-blob-util";
import { print } from "react-native-print";
import Share from "react-native-share";

import { GeneratedMetricsPdf, MetricsDashboard } from "../types/metrics";

type CreateMetricsPdfInput = {
  dashboard: MetricsDashboard;
  patientName: string;
  phaseLabel: string;
  periodLabel: string;
};

export type SavedPdfResult = {
  fileName: string;
  location: string;
};

function ascii(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\x20-\x7E]/g, "?");
}

function escapePdfText(value: string) {
  return ascii(value).replace(/([\\()])/g, "\\$1");
}

function shorten(value: string, limit: number) {
  const normalized = ascii(value);
  return normalized.length > limit
    ? `${normalized.slice(0, Math.max(0, limit - 3))}...`
    : normalized;
}

function pdfText(
  x: number,
  y: number,
  size: number,
  value: string,
  options: { bold?: boolean; color?: string } = {}
) {
  const font = options.bold ? "F2" : "F1";
  const color = options.color ?? "0.12 0.18 0.27";
  return `BT /${font} ${size} Tf ${color} rg ${x} ${y} Td (${escapePdfText(
    value
  )}) Tj ET`;
}

function pdfRect(
  x: number,
  y: number,
  width: number,
  height: number,
  color: string
) {
  return `${color} rg ${x} ${y} ${width} ${height} re f`;
}

function buildPdfDocument(input: CreateMetricsPdfInput) {
  const { dashboard } = input;
  const commands: string[] = [];
  const teal = "0.07 0.60 0.61";
  const darkTeal = "0.04 0.42 0.45";
  const lightTeal = "0.89 0.97 0.96";
  const lightGray = "0.92 0.94 0.96";
  const skillColors = [
    "0.10 0.65 0.66",
    "0.97 0.72 0.09",
    "0.27 0.60 0.94",
    "0.60 0.29 0.78",
  ];

  commands.push(pdfRect(0, 730, 595, 112, teal));
  commands.push(
    pdfText(42, 789, 25, "Relatorio de metricas", {
      bold: true,
      color: "1 1 1",
    })
  );
  commands.push(
    pdfText(42, 762, 11, "Desempenho e evolucao do paciente", {
      color: "1 1 1",
    })
  );
  commands.push(
    pdfText(42, 706, 12, `Paciente: ${shorten(input.patientName, 54)}`, {
      bold: true,
      color: darkTeal,
    })
  );
  commands.push(pdfText(42, 684, 10, `Fase: ${shorten(input.phaseLabel, 28)}`));
  commands.push(
    pdfText(300, 684, 10, `Periodo: ${shorten(input.periodLabel, 28)}`)
  );

  commands.push(pdfRect(42, 594, 511, 65, lightTeal));
  commands.push(
    pdfText(58, 634, 12, "Desempenho geral", { bold: true, color: darkTeal })
  );
  commands.push(
    pdfText(58, 608, 20, `${dashboard.general.successRate}%`, {
      bold: true,
      color: teal,
    })
  );
  commands.push(
    pdfText(130, 611, 10, `${dashboard.general.correctAnswers} acertos`)
  );
  commands.push(pdfText(250, 611, 10, `${dashboard.general.errors} erros`));
  commands.push(
    pdfText(355, 611, 10, `${dashboard.general.totalAttempts} tentativas`)
  );

  commands.push(
    pdfText(42, 556, 15, "Desempenho por habilidade", {
      bold: true,
      color: darkTeal,
    })
  );
  dashboard.skills.forEach((skill, index) => {
    const y = 516 - index * 58;
    const barWidth = 225;
    const filledWidth = (barWidth * skill.score) / 100;
    commands.push(
      pdfText(50, y + 19, 10, shorten(skill.title, 42), { bold: true })
    );
    commands.push(
      pdfText(455, y + 19, 12, `${skill.score}%`, {
        bold: true,
        color: skillColors[index],
      })
    );
    commands.push(pdfRect(50, y, barWidth, 8, lightGray));
    commands.push(pdfRect(50, y, filledWidth, 8, skillColors[index]));
    commands.push(
      pdfText(
        290,
        y + 1,
        8,
        `${skill.hits} de ${skill.totalAttempts} tentativas`
      )
    );
  });

  commands.push(
    pdfText(42, 304, 15, "Evolucao no periodo", { bold: true, color: darkTeal })
  );
  const chartX = 55;
  const chartY = 125;
  const chartWidth = 485;
  const chartHeight = 145;

  [0, 25, 50, 75, 100].forEach((value) => {
    const y = chartY + (value / 100) * chartHeight;
    commands.push(
      `0.86 0.89 0.92 RG 0.7 w ${chartX} ${y} m ${chartX + chartWidth} ${y} l S`
    );
    commands.push(
      pdfText(24, y - 3, 7, `${value}%`, { color: "0.42 0.45 0.50" })
    );
  });

  if (dashboard.evolutionDates.length === 0) {
    commands.push(
      pdfText(
        145,
        196,
        11,
        "Sem dados de evolucao para o filtro selecionado.",
        { color: "0.42 0.45 0.50" }
      )
    );
  } else {
    dashboard.evolutionDates.forEach((date, index) => {
      const denominator = Math.max(1, dashboard.evolutionDates.length - 1);
      const x = chartX + (index / denominator) * chartWidth;
      commands.push(pdfText(x - 10, 108, 7, date, { color: "0.42 0.45 0.50" }));
    });

    dashboard.evolutionSeries.forEach((series, seriesIndex) => {
      let previousPoint: { x: number; y: number } | null = null;
      series.values.forEach((value, index) => {
        if (value === null) {
          previousPoint = null;
          return;
        }

        const denominator = Math.max(1, dashboard.evolutionDates.length - 1);
        const point = {
          x: chartX + (index / denominator) * chartWidth,
          y: chartY + (value / 100) * chartHeight,
        };

        if (previousPoint) {
          commands.push(
            `${skillColors[seriesIndex]} RG 2 w ${previousPoint.x} ${previousPoint.y} m ${point.x} ${point.y} l S`
          );
        }
        commands.push(
          pdfRect(point.x - 2, point.y - 2, 4, 4, skillColors[seriesIndex])
        );
        previousPoint = point;
      });
    });
  }

  const generatedDate = new Date().toLocaleDateString("pt-BR");
  commands.push(
    pdfText(42, 70, 8, `Gerado em ${generatedDate}`, {
      color: "0.42 0.45 0.50",
    })
  );
  commands.push(pdfText(430, 70, 9, "Verbaio", { bold: true, color: teal }));

  const content = `${commands.join("\n")}\n`;
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
    `<< /Length ${content.length} >>\nstream\n${content}endstream`,
  ];

  let pdf = "%PDF-1.4\n%Verbaio\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(pdf.length);
    pdf += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });

  const xrefOffset = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n`;
  pdf += "0000000000 65535 f \n";
  offsets.slice(1).forEach((offset) => {
    pdf += `${String(offset).padStart(10, "0")} 00000 n \n`;
  });
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\n`;
  pdf += `startxref\n${xrefOffset}\n%%EOF\n`;

  return pdf;
}

export async function createMetricsPdf(
  input: CreateMetricsPdfInput
): Promise<GeneratedMetricsPdf> {
  const generatedAt = new Date().toISOString();
  const compactDate = generatedAt.slice(0, 19).replace(/[-:T]/g, "");
  const fileName = `Metricas_Verbaio_${compactDate}.pdf`;
  const localPath = `${ReactNativeBlobUtil.fs.dirs.CacheDir}/${fileName}`;

  await ReactNativeBlobUtil.fs.writeFile(
    localPath,
    buildPdfDocument(input),
    "utf8"
  );

  return {
    fileName,
    generatedAt,
    localPath,
    patientName: input.patientName,
    phaseLabel: input.phaseLabel,
    periodLabel: input.periodLabel,
  };
}

export async function viewMetricsPdf(pdf: GeneratedMetricsPdf) {
  if (Platform.OS === "ios") {
    ReactNativeBlobUtil.ios.previewDocument(pdf.localPath);
    return;
  }

  if (Platform.OS === "android") {
    await ReactNativeBlobUtil.android.actionViewIntent(
      pdf.localPath,
      "application/pdf",
      "Visualizar PDF"
    );
    return;
  }

  throw new Error(
    "A visualização de PDF não está disponível neste dispositivo."
  );
}

export async function shareMetricsPdf(pdf: GeneratedMetricsPdf) {
  await Share.open({
    failOnCancel: false,
    title: "Compartilhar relatório de métricas",
    type: "application/pdf",
    url: pdf.localPath.startsWith("file://")
      ? pdf.localPath
      : `file://${pdf.localPath}`,
  });
}

export async function saveMetricsPdf(
  pdf: GeneratedMetricsPdf
): Promise<SavedPdfResult> {
  if (Platform.OS === "android" && Number(Platform.Version) >= 29) {
    const descriptor = {
      mimeType: "application/pdf",
      name: pdf.fileName,
      parentFolder: "Verbaio",
    } as unknown as Parameters<
      typeof ReactNativeBlobUtil.MediaCollection.copyToMediaStore
    >[0];
    const storedUri =
      await ReactNativeBlobUtil.MediaCollection.copyToMediaStore(
        descriptor,
        "Download",
        pdf.localPath
      );

    if (!storedUri || storedUri.toLowerCase().startsWith("failed")) {
      throw new Error("O Android não confirmou o download do relatório.");
    }

    return { fileName: pdf.fileName, location: "Downloads/Verbaio" };
  }

  const destinationDirectory =
    Platform.OS === "android"
      ? ReactNativeBlobUtil.fs.dirs.DownloadDir
      : ReactNativeBlobUtil.fs.dirs.DocumentDir;
  const destination = `${destinationDirectory}/${pdf.fileName}`;
  await ReactNativeBlobUtil.fs.cp(pdf.localPath, destination);

  return {
    fileName: pdf.fileName,
    location: Platform.OS === "android" ? "Downloads" : "Arquivos",
  };
}

export async function printMetricsPdf(pdf: GeneratedMetricsPdf) {
  await print({ filePath: pdf.localPath, jobName: "Métricas Verbaio" });
}
