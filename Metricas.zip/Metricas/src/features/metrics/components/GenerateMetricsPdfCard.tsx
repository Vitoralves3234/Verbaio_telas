import React from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { colors } from "../../../theme/colors";

type GenerateMetricsPdfCardProps = {
  generating: boolean;
  onGenerate: () => void;
};

export function GenerateMetricsPdfCard({
  generating,
  onGenerate,
}: GenerateMetricsPdfCardProps) {
  return (
    <View style={styles.card}>
      <View style={styles.iconCircle}>
        <Text style={styles.pdfIcon}>PDF</Text>
      </View>

      <View style={styles.copy}>
        <Text style={styles.title}>Relatório de métricas</Text>
        <Text style={styles.description}>
          Gere um PDF com os indicadores e filtros exibidos nesta tela.
        </Text>
      </View>

      <Pressable
        accessibilityLabel="Gerar PDF das métricas"
        accessibilityRole="button"
        disabled={generating}
        onPress={onGenerate}
        style={({ pressed }) => [
          styles.button,
          pressed ? styles.pressed : null,
          generating ? styles.disabled : null,
        ]}
      >
        {generating ? (
          <ActivityIndicator color={colors.white} size="small" />
        ) : (
          <Text style={styles.buttonText}>Gerar PDF</Text>
        )}
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: "center",
    backgroundColor: colors.tealSoft,
    borderColor: "#CDEAE7",
    borderRadius: 22,
    borderWidth: 1,
    flexDirection: "row",
    minHeight: 112,
    paddingHorizontal: 14,
    paddingVertical: 14,
  },
  iconCircle: {
    alignItems: "center",
    backgroundColor: colors.yellowSoft,
    borderRadius: 25,
    height: 50,
    justifyContent: "center",
    marginRight: 10,
    width: 50,
  },
  pdfIcon: {
    color: colors.yellowDark,
    fontSize: 11,
    fontWeight: "900",
  },
  copy: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    color: colors.tealDark,
    fontSize: 14,
    fontWeight: "800",
    marginBottom: 4,
  },
  description: {
    color: colors.text,
    fontSize: 10.5,
    lineHeight: 14,
  },
  button: {
    alignItems: "center",
    backgroundColor: colors.teal,
    borderRadius: 22,
    justifyContent: "center",
    marginLeft: 10,
    minHeight: 45,
    minWidth: 100,
    paddingHorizontal: 13,
  },
  buttonText: {
    color: colors.white,
    fontSize: 12,
    fontWeight: "800",
  },
  pressed: {
    opacity: 0.78,
    transform: [{ scale: 0.98 }],
  },
  disabled: {
    opacity: 0.72,
  },
});
