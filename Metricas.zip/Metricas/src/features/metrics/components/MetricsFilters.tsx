import React, { useMemo, useState } from "react";
import { Modal, Pressable, StyleSheet, Text, View } from "react-native";

import { SurfaceCard } from "../../../shared/components/SurfaceCard";
import { colors } from "../../../theme/colors";
import { getPeriodLabel, periodOptions } from "../data/metricDefinitions";
import { MetricsPeriod } from "../types/metrics";

type MetricsFiltersProps = {
  onPeriodChange: (period: MetricsPeriod) => void;
  onPhaseChange: (phase: string) => void;
  period: MetricsPeriod;
  phase: string;
  phases: string[];
};

type FilterModalProps = {
  onClose: () => void;
  onSelect: (value: string) => void;
  options: Array<{ label: string; value: string }>;
  selectedValue: string;
  title: string;
  visible: boolean;
};

function FilterModal({
  onClose,
  onSelect,
  options,
  selectedValue,
  title,
  visible,
}: FilterModalProps) {
  return (
    <Modal
      animationType="fade"
      onRequestClose={onClose}
      transparent
      visible={visible}
    >
      <Pressable onPress={onClose} style={styles.overlay}>
        <Pressable
          onPress={(event) => event.stopPropagation()}
          style={styles.modal}
        >
          <Text style={styles.modalTitle}>{title}</Text>
          {options.map((option) => {
            const selected = option.value === selectedValue;

            return (
              <Pressable
                accessibilityLabel={`Selecionar ${option.label}`}
                accessibilityRole="button"
                key={option.value}
                onPress={() => {
                  onSelect(option.value);
                  onClose();
                }}
                style={({ pressed }) => [
                  styles.option,
                  selected ? styles.selectedOption : null,
                  pressed ? styles.pressed : null,
                ]}
              >
                <Text
                  style={[
                    styles.optionText,
                    selected ? styles.selectedOptionText : null,
                  ]}
                >
                  {option.label}
                </Text>
                {selected ? <Text style={styles.check}>✓</Text> : null}
              </Pressable>
            );
          })}
        </Pressable>
      </Pressable>
    </Modal>
  );
}

type FilterPillProps = {
  accessibilityLabel: string;
  label: string;
  onPress: () => void;
};

function FilterPill({ accessibilityLabel, label, onPress }: FilterPillProps) {
  return (
    <Pressable
      accessibilityLabel={accessibilityLabel}
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.pressable,
        pressed ? styles.pressed : null,
      ]}
    >
      <SurfaceCard style={styles.pill}>
        <View style={styles.calendarIcon}>
          <Text style={styles.calendarText}>▦</Text>
        </View>
        <Text numberOfLines={1} style={styles.label}>
          {label}
        </Text>
        <Text style={styles.chevron}>⌄</Text>
      </SurfaceCard>
    </Pressable>
  );
}

export function MetricsFilters({
  onPeriodChange,
  onPhaseChange,
  period,
  phase,
  phases,
}: MetricsFiltersProps) {
  const [openFilter, setOpenFilter] = useState<"period" | "phase" | null>(null);
  const phaseOptions = useMemo(
    () => [
      { label: "Todas as fases", value: "all" },
      ...phases.map((item) => ({ label: item, value: item })),
    ],
    [phases]
  );
  const periodSelectOptions = periodOptions.map((option) => ({
    label: option.label,
    value: String(option.value),
  }));
  const phaseLabel = phase === "all" ? "Todas as fases" : phase;

  return (
    <>
      <View
        accessibilityLabel={`Filtros: ${phaseLabel}, ${getPeriodLabel(period)}`}
        style={styles.row}
      >
        <View style={styles.phaseFilter}>
          <FilterPill
            accessibilityLabel="Escolher fase"
            label={phaseLabel}
            onPress={() => setOpenFilter("phase")}
          />
        </View>
        <View style={styles.periodFilter}>
          <FilterPill
            accessibilityLabel="Escolher período"
            label={`Período: ${getPeriodLabel(period)}`}
            onPress={() => setOpenFilter("period")}
          />
        </View>
      </View>

      <FilterModal
        onClose={() => setOpenFilter(null)}
        onSelect={onPhaseChange}
        options={phaseOptions}
        selectedValue={phase}
        title="Escolha a fase"
        visible={openFilter === "phase"}
      />
      <FilterModal
        onClose={() => setOpenFilter(null)}
        onSelect={(value) =>
          onPeriodChange(
            value === "all" ? "all" : (Number(value) as MetricsPeriod)
          )
        }
        options={periodSelectOptions}
        selectedValue={String(period)}
        title="Escolha o período"
        visible={openFilter === "period"}
      />
    </>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    gap: 12,
  },
  phaseFilter: {
    flex: 0.82,
  },
  periodFilter: {
    flex: 1.45,
  },
  pressable: {
    borderRadius: 17,
  },
  pill: {
    alignItems: "center",
    borderRadius: 17,
    flexDirection: "row",
    minHeight: 54,
    paddingHorizontal: 13,
  },
  calendarIcon: {
    alignItems: "center",
    height: 24,
    justifyContent: "center",
    marginRight: 9,
    width: 24,
  },
  calendarText: {
    color: colors.teal,
    fontSize: 22,
    fontWeight: "800",
  },
  label: {
    color: colors.ink,
    flex: 1,
    fontSize: 12.5,
    fontWeight: "800",
  },
  chevron: {
    color: colors.ink,
    fontSize: 22,
    fontWeight: "800",
    marginLeft: 5,
    marginTop: -6,
  },
  overlay: {
    alignItems: "center",
    backgroundColor: "rgba(17, 24, 39, 0.45)",
    flex: 1,
    justifyContent: "center",
    padding: 24,
  },
  modal: {
    backgroundColor: colors.white,
    borderRadius: 24,
    maxWidth: 420,
    padding: 18,
    width: "100%",
  },
  modalTitle: {
    color: colors.tealDark,
    fontSize: 20,
    fontWeight: "900",
    marginBottom: 10,
  },
  option: {
    alignItems: "center",
    borderRadius: 14,
    flexDirection: "row",
    minHeight: 48,
    paddingHorizontal: 13,
  },
  selectedOption: {
    backgroundColor: colors.tealSoft,
  },
  optionText: {
    color: colors.text,
    flex: 1,
    fontSize: 14,
    fontWeight: "700",
  },
  selectedOptionText: {
    color: colors.tealDark,
  },
  check: {
    color: colors.teal,
    fontSize: 20,
    fontWeight: "900",
  },
  pressed: {
    opacity: 0.72,
  },
});
