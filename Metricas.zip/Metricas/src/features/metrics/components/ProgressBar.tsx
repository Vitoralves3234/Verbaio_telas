import React from "react";
import { StyleSheet, View } from "react-native";

import { colors } from "../../../theme/colors";

type ProgressBarProps = {
  color: string;
  value: number;
};

export function ProgressBar({ color, value }: ProgressBarProps) {
  const safeValue = Math.max(0, Math.min(value, 100));

  return (
    <View style={styles.track}>
      <View
        style={[
          styles.progress,
          { backgroundColor: color, width: `${safeValue}%` },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  track: {
    backgroundColor: colors.divider,
    borderRadius: 5,
    height: 9,
    overflow: "hidden",
    width: "100%",
  },
  progress: {
    borderRadius: 5,
    height: "100%",
  },
});
