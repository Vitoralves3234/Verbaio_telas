import React, { Fragment, useState } from "react";
import { LayoutChangeEvent, StyleSheet, Text, View } from "react-native";

import { SurfaceCard } from "../../../shared/components/SurfaceCard";
import { colors } from "../../../theme/colors";
import { EvolutionSeries } from "../types/metrics";

const CHART_HEIGHT = 142;
const DOT_SIZE = 8;

type EvolutionChartProps = {
  dates: string[];
  series: EvolutionSeries[];
};

type Point = {
  x: number;
  y: number;
};

function segmentStyle(start: Point, end: Point, color: string) {
  const deltaX = end.x - start.x;
  const deltaY = end.y - start.y;
  const length = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
  const angle = (Math.atan2(deltaY, deltaX) * 180) / Math.PI;

  return {
    backgroundColor: color,
    height: 2.5,
    left: (start.x + end.x - length) / 2,
    position: "absolute" as const,
    top: (start.y + end.y) / 2 - 1.25,
    transform: [{ rotateZ: `${angle}deg` }],
    width: length,
  };
}

export function EvolutionChart({ dates, series }: EvolutionChartProps) {
  const [chartWidth, setChartWidth] = useState(260);

  const handleLayout = (event: LayoutChangeEvent) => {
    const nextWidth = Math.round(event.nativeEvent.layout.width);
    if (nextWidth > 0 && nextWidth !== chartWidth) {
      setChartWidth(nextWidth);
    }
  };

  const pointFor = (index: number, value: number): Point => ({
    x:
      dates.length > 1
        ? (index / (dates.length - 1)) * chartWidth
        : chartWidth / 2,
    y: CHART_HEIGHT - (value / 100) * CHART_HEIGHT,
  });

  return (
    <SurfaceCard style={styles.card}>
      <Text style={styles.sectionTitle}>Evolução no período</Text>

      {dates.length === 0 ? (
        <View style={styles.emptyChart}>
          <Text style={styles.emptyIcon}>↗</Text>
          <Text style={styles.emptyTitle}>Evolução aguardando dados</Text>
          <Text style={styles.emptyText}>
            O gráfico será montado automaticamente após as primeiras atividades.
          </Text>
        </View>
      ) : (
        <>
          <View style={styles.chartRow}>
            <View style={styles.yAxis}>
              {[100, 75, 50, 25, 0].map((value) => (
                <Text key={value} style={styles.yAxisLabel}>
                  {value}%
                </Text>
              ))}
            </View>

            <View style={styles.plotColumn}>
              <View onLayout={handleLayout} style={styles.plot}>
                {[0, 25, 50, 75, 100].map((value) => (
                  <View
                    key={value}
                    style={[
                      styles.gridLine,
                      { top: CHART_HEIGHT - (value / 100) * CHART_HEIGHT },
                    ]}
                  />
                ))}

                {series.map((item) => {
                  const points = item.values.map((value, index) =>
                    value === null ? null : pointFor(index, value)
                  );

                  return (
                    <Fragment key={item.id}>
                      {points.slice(0, -1).map((point, index) => {
                        const nextPoint = points[index + 1];
                        return point && nextPoint ? (
                          <View
                            key={`${item.id}-line-${index}`}
                            style={segmentStyle(point, nextPoint, item.color)}
                          />
                        ) : null;
                      })}
                      {points.map((point, index) =>
                        point ? (
                          <View
                            key={`${item.id}-point-${index}`}
                            style={[
                              styles.point,
                              {
                                backgroundColor: item.color,
                                left: point.x - DOT_SIZE / 2,
                                top: point.y - DOT_SIZE / 2,
                              },
                            ]}
                          />
                        ) : null
                      )}
                    </Fragment>
                  );
                })}
              </View>

              <View style={styles.xAxis}>
                {dates.map((date) => (
                  <Text key={date} style={styles.xAxisLabel}>
                    {date}
                  </Text>
                ))}
              </View>
            </View>
          </View>

          <View style={styles.legend}>
            {series.map((item) => (
              <View key={item.id} style={styles.legendItem}>
                <View
                  style={[styles.legendDot, { backgroundColor: item.color }]}
                />
                <Text style={styles.legendLabel}>{item.label}</Text>
              </View>
            ))}
          </View>
        </>
      )}
    </SurfaceCard>
  );
}

const styles = StyleSheet.create({
  card: {
    paddingHorizontal: 15,
    paddingVertical: 18,
  },
  sectionTitle: {
    color: colors.tealDark,
    fontSize: 19,
    fontWeight: "800",
    letterSpacing: -0.3,
    marginBottom: 16,
  },
  emptyChart: {
    alignItems: "center",
    backgroundColor: colors.readOnly,
    borderRadius: 17,
    minHeight: 142,
    justifyContent: "center",
    padding: 18,
  },
  emptyIcon: {
    color: colors.teal,
    fontSize: 30,
    fontWeight: "900",
  },
  emptyTitle: {
    color: colors.tealDark,
    fontSize: 14,
    fontWeight: "800",
    marginTop: 6,
  },
  emptyText: {
    color: colors.muted,
    fontSize: 10.5,
    lineHeight: 15,
    marginTop: 4,
    textAlign: "center",
  },
  chartRow: {
    flexDirection: "row",
  },
  yAxis: {
    height: CHART_HEIGHT + 1,
    justifyContent: "space-between",
    marginRight: 7,
    width: 30,
  },
  yAxisLabel: {
    color: colors.muted,
    fontSize: 8.5,
    lineHeight: 10,
    textAlign: "right",
  },
  plotColumn: {
    flex: 1,
    minWidth: 0,
  },
  plot: {
    height: CHART_HEIGHT,
    position: "relative",
  },
  gridLine: {
    backgroundColor: colors.chartGrid,
    height: 1,
    left: 0,
    position: "absolute",
    right: 0,
  },
  point: {
    borderRadius: DOT_SIZE / 2,
    height: DOT_SIZE,
    position: "absolute",
    width: DOT_SIZE,
  },
  xAxis: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 9,
  },
  xAxisLabel: {
    color: colors.muted,
    fontSize: 8.5,
  },
  legend: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
    marginTop: 18,
  },
  legendItem: {
    alignItems: "center",
    flexDirection: "row",
    width: "47%",
  },
  legendDot: {
    borderRadius: 5,
    height: 10,
    marginRight: 7,
    width: 10,
  },
  legendLabel: {
    color: colors.muted,
    flex: 1,
    fontSize: 10.5,
  },
});
