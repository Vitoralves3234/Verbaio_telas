import React from "react";
import { StyleSheet, Text, View } from "react-native";

import { SurfaceCard } from "../../../shared/components/SurfaceCard";
import { colors } from "../../../theme/colors";
import { SkillMetric } from "../types/metrics";
import { ProgressBar } from "./ProgressBar";

type SkillPerformanceCardProps = {
  metrics: SkillMetric[];
};

type SkillRowProps = {
  isLast: boolean;
  metric: SkillMetric;
};

function SkillRow({ isLast, metric }: SkillRowProps) {
  return (
    <View
      accessibilityLabel={`${metric.title}: ${metric.score} por cento, ${metric.hits} acertos em ${metric.totalAttempts} tentativas`}
      style={[styles.skillRow, isLast ? styles.lastRow : null]}
    >
      <View style={[styles.iconBox, { backgroundColor: metric.softColor }]}>
        <Text style={[styles.iconText, { color: metric.accentColor }]}>
          {metric.icon}
        </Text>
      </View>

      <View style={styles.skillCopy}>
        <Text numberOfLines={2} style={styles.skillTitle}>
          {metric.title}
        </Text>
        <ProgressBar color={metric.accentColor} value={metric.score} />
      </View>

      <View style={styles.scoreCopy}>
        <Text style={[styles.score, { color: metric.accentColor }]}>
          {metric.score}%
        </Text>
        <Text numberOfLines={2} style={styles.attempts}>
          {metric.hits} acertos{`\n`}/ {metric.totalAttempts} tentativas
        </Text>
      </View>
    </View>
  );
}

export function SkillPerformanceCard({ metrics }: SkillPerformanceCardProps) {
  return (
    <SurfaceCard style={styles.card}>
      <View style={styles.headingRow}>
        <Text style={styles.chartIcon}>▥</Text>
        <Text style={styles.sectionTitle}>Desempenho por habilidade</Text>
      </View>

      <View style={styles.list}>
        {metrics.map((metric, index) => (
          <SkillRow
            isLast={index === metrics.length - 1}
            key={metric.id}
            metric={metric}
          />
        ))}
      </View>
    </SurfaceCard>
  );
}

const styles = StyleSheet.create({
  card: {
    paddingBottom: 8,
    paddingHorizontal: 14,
    paddingTop: 18,
  },
  headingRow: {
    alignItems: "center",
    flexDirection: "row",
    marginBottom: 12,
    paddingHorizontal: 3,
  },
  chartIcon: {
    color: colors.teal,
    fontSize: 23,
    fontWeight: "900",
    marginRight: 9,
  },
  sectionTitle: {
    color: colors.tealDark,
    flex: 1,
    fontSize: 18,
    fontWeight: "800",
    letterSpacing: -0.3,
  },
  list: {
    borderColor: colors.divider,
    borderRadius: 18,
    borderWidth: 1,
    overflow: "hidden",
  },
  skillRow: {
    alignItems: "center",
    borderBottomColor: colors.divider,
    borderBottomWidth: 1,
    flexDirection: "row",
    minHeight: 82,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  lastRow: {
    borderBottomWidth: 0,
  },
  iconBox: {
    alignItems: "center",
    borderRadius: 13,
    height: 46,
    justifyContent: "center",
    marginRight: 10,
    width: 46,
  },
  iconText: {
    fontSize: 20,
    fontWeight: "900",
  },
  skillCopy: {
    flex: 1,
    minWidth: 0,
  },
  skillTitle: {
    color: colors.ink,
    fontSize: 12.5,
    fontWeight: "800",
    lineHeight: 16,
    marginBottom: 8,
  },
  scoreCopy: {
    alignItems: "flex-end",
    marginLeft: 9,
    width: 72,
  },
  score: {
    fontSize: 20,
    fontWeight: "900",
  },
  attempts: {
    color: colors.muted,
    fontSize: 8.5,
    lineHeight: 11,
    marginTop: 3,
    textAlign: "right",
  },
});
