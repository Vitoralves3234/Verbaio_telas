import React from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text } from "react-native";

import { colors } from "../../../theme/colors";

type PdfActionButtonProps = {
  accessibilityLabel: string;
  icon: string;
  label: string;
  loading?: boolean;
  onPress: () => void;
  primary?: boolean;
};

export function PdfActionButton({
  accessibilityLabel,
  icon,
  label,
  loading = false,
  onPress,
  primary = false,
}: PdfActionButtonProps) {
  return (
    <Pressable
      accessibilityLabel={accessibilityLabel}
      accessibilityRole="button"
      disabled={loading}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        primary ? styles.primary : styles.secondary,
        pressed ? styles.pressed : null,
        loading ? styles.disabled : null,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={primary ? colors.white : colors.teal} />
      ) : (
        <>
          <Text style={[styles.icon, primary ? styles.primaryText : null]}>
            {icon}
          </Text>
          <Text style={[styles.label, primary ? styles.primaryText : null]}>
            {label}
          </Text>
        </>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    alignItems: "center",
    borderRadius: 21,
    elevation: 3,
    flex: 1,
    flexDirection: "row",
    justifyContent: "center",
    minHeight: 60,
    paddingHorizontal: 14,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
  },
  primary: {
    backgroundColor: colors.teal,
  },
  secondary: {
    backgroundColor: colors.white,
  },
  icon: {
    color: colors.teal,
    fontSize: 24,
    fontWeight: "900",
    marginRight: 10,
  },
  label: {
    color: colors.tealDark,
    fontSize: 14,
    fontWeight: "900",
  },
  primaryText: {
    color: colors.white,
  },
  pressed: {
    opacity: 0.76,
    transform: [{ scale: 0.99 }],
  },
  disabled: {
    opacity: 0.65,
  },
});
