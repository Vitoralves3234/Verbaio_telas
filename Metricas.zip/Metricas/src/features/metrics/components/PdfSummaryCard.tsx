import React from "react";
import { StyleSheet, Text, View } from "react-native";

import { SurfaceCard } from "../../../shared/components/SurfaceCard";
import { colors } from "../../../theme/colors";
import { GeneratedMetricsPdf } from "../types/metrics";

type PdfSummaryCardProps = {
  pdf: GeneratedMetricsPdf;
};

function formatDate(value: string) {
  return new Date(value).toLocaleDateString("pt-BR");
}

export function PdfSummaryCard({ pdf }: PdfSummaryCardProps) {
  return (
    <>
      <View accessibilityLabel="PDF gerado com sucesso" style={styles.success}>
        <Text style={styles.successMark}>✓</Text>
      </View>

      <SurfaceCard style={styles.card}>
        <View style={styles.cover}>
          <View style={styles.pdfBadge}>
            <Text style={styles.pdfBadgeText}>PDF</Text>
          </View>
          <Text style={styles.brand}>verbaio</Text>
          <Text style={styles.coverTitle}>Relatório{`\n`}de métricas</Text>
          <Text style={styles.coverSubtitle}>Desempenho e evolução</Text>
          <View style={styles.coverWave} />
        </View>

        <View style={styles.details}>
          <View style={styles.detailRow}>
            <Text style={styles.detailIcon}>●</Text>
            <View style={styles.detailCopy}>
              <Text style={styles.detailLabel}>Paciente</Text>
              <Text numberOfLines={2} style={styles.detailValue}>
                {pdf.patientName}
              </Text>
            </View>
          </View>
          <View style={styles.divider} />
          <View style={styles.detailRow}>
            <Text style={styles.detailIcon}>▤</Text>
            <View style={styles.detailCopy}>
              <Text style={styles.detailLabel}>Documento</Text>
              <Text style={styles.detailValue}>Relatório de métricas</Text>
            </View>
          </View>
          <View style={styles.divider} />
          <View style={styles.detailRow}>
            <Text style={styles.detailIcon}>▦</Text>
            <View style={styles.detailCopy}>
              <Text style={styles.detailLabel}>Data de geração</Text>
              <Text style={styles.detailValue}>
                {formatDate(pdf.generatedAt)}
              </Text>
            </View>
          </View>
          <View style={styles.filters}>
            <Text numberOfLines={2} style={styles.filtersText}>
              {pdf.phaseLabel} • {pdf.periodLabel}
            </Text>
          </View>
        </View>
      </SurfaceCard>
    </>
  );
}

const styles = StyleSheet.create({
  success: {
    alignItems: "center",
    alignSelf: "center",
    backgroundColor: "#48CC70",
    borderRadius: 42,
    height: 84,
    justifyContent: "center",
    marginBottom: 4,
    width: 84,
  },
  successMark: {
    color: colors.white,
    fontSize: 48,
    fontWeight: "700",
    marginTop: -5,
  },
  card: {
    flexDirection: "row",
    gap: 16,
    padding: 18,
  },
  cover: {
    backgroundColor: "#F1FBFA",
    borderColor: "#CDEAE7",
    borderRadius: 15,
    borderWidth: 1,
    height: 210,
    overflow: "hidden",
    padding: 13,
    width: 128,
  },
  pdfBadge: {
    alignItems: "center",
    alignSelf: "flex-end",
    backgroundColor: colors.white,
    borderRadius: 8,
    elevation: 2,
    justifyContent: "center",
    paddingHorizontal: 7,
    paddingVertical: 8,
  },
  pdfBadgeText: {
    color: colors.pink,
    fontSize: 10,
    fontWeight: "900",
  },
  brand: {
    color: colors.teal,
    fontSize: 13,
    fontWeight: "900",
    marginTop: -20,
  },
  coverTitle: {
    color: colors.tealDark,
    fontSize: 18,
    fontWeight: "900",
    lineHeight: 21,
    marginTop: 35,
  },
  coverSubtitle: {
    color: colors.muted,
    fontSize: 8,
    marginTop: 6,
  },
  coverWave: {
    backgroundColor: colors.teal,
    bottom: -24,
    height: 55,
    left: -15,
    position: "absolute",
    transform: [{ rotate: "-5deg" }],
    width: 160,
  },
  details: {
    flex: 1,
    justifyContent: "center",
    minWidth: 0,
  },
  detailRow: {
    alignItems: "center",
    flexDirection: "row",
    minHeight: 45,
  },
  detailIcon: {
    color: colors.teal,
    fontSize: 20,
    fontWeight: "900",
    marginRight: 10,
    width: 23,
  },
  detailCopy: {
    flex: 1,
    minWidth: 0,
  },
  detailLabel: {
    color: colors.muted,
    fontSize: 10.5,
  },
  detailValue: {
    color: colors.ink,
    fontSize: 13.5,
    fontWeight: "900",
    marginTop: 2,
  },
  divider: {
    backgroundColor: colors.divider,
    height: 1,
    marginVertical: 4,
  },
  filters: {
    backgroundColor: colors.tealSoft,
    borderRadius: 11,
    marginTop: 10,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  filtersText: {
    color: colors.tealDark,
    fontSize: 9.5,
    fontWeight: "800",
  },
});
