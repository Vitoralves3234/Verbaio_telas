import React from "react";
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { SurfaceCard } from "../../../shared/components/SurfaceCard";
import { colors } from "../../../theme/colors";

type MetricsStatusCardProps = {
  error?: string | null;
  loading?: boolean;
  onRefresh: () => void;
};

export function MetricsStatusCard({
  error,
  loading,
  onRefresh,
}: MetricsStatusCardProps) {
  const isError = Boolean(error);

  return (
    <SurfaceCard style={styles.card}>
      {loading ? (
        <ActivityIndicator color={colors.teal} size="large" />
      ) : (
        <View style={[styles.icon, isError ? styles.errorIcon : null]}>
          <Text style={styles.iconText}>{isError ? "!" : "i"}</Text>
        </View>
      )}

      <View style={styles.copy}>
        <Text style={styles.title}>
          {loading
            ? "Carregando métricas"
            : isError
            ? "Falha ao carregar os dados"
            : "Ainda não existem dados neste filtro"}
        </Text>
        <Text style={styles.description}>
          {loading
            ? "Aguarde enquanto buscamos os registros."
            : isError
            ? error
            : "Quando as atividades forem conectadas, os indicadores serão calculados automaticamente."}
        </Text>
      </View>

      {!loading ? (
        <Pressable
          accessibilityLabel="Atualizar métricas"
          accessibilityRole="button"
          onPress={onRefresh}
          style={({ pressed }) => [
            styles.button,
            pressed ? styles.pressed : null,
          ]}
        >
          <Text style={styles.buttonText}>Atualizar</Text>
        </Pressable>
      ) : null}
    </SurfaceCard>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: "center",
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 15,
    paddingVertical: 15,
  },
  icon: {
    alignItems: "center",
    backgroundColor: colors.tealSoft,
    borderRadius: 22,
    height: 44,
    justifyContent: "center",
    width: 44,
  },
  errorIcon: {
    backgroundColor: colors.pinkSoft,
  },
  iconText: {
    color: colors.teal,
    fontSize: 23,
    fontWeight: "900",
  },
  copy: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    color: colors.tealDark,
    fontSize: 14,
    fontWeight: "800",
    marginBottom: 3,
  },
  description: {
    color: colors.muted,
    fontSize: 10.5,
    lineHeight: 14,
  },
  button: {
    backgroundColor: colors.teal,
    borderRadius: 18,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  buttonText: {
    color: colors.white,
    fontSize: 11,
    fontWeight: "800",
  },
  pressed: {
    opacity: 0.75,
  },
});
