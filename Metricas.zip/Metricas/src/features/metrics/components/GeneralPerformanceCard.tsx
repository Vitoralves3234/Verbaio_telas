import React from "react";
import { StyleSheet, Text, View } from "react-native";

import { SurfaceCard } from "../../../shared/components/SurfaceCard";
import { colors } from "../../../theme/colors";
import { GeneralMetrics } from "../types/metrics";
import { ProgressBar } from "./ProgressBar";

type GeneralPerformanceCardProps = {
  metrics: GeneralMetrics;
};

type MetricStatProps = {
  color: string;
  detail: string;
  label: string;
  value: number;
};

function MetricStat({ color, detail, label, value }: MetricStatProps) {
  return (
    <View style={styles.statCard}>
      <Text numberOfLines={2} style={styles.statLabel}>
        {label}
      </Text>
      <Text style={[styles.statValue, { color }]}>{value}%</Text>
      <ProgressBar color={color} value={value} />
      <Text numberOfLines={1} style={styles.statDetail}>
        {detail}
      </Text>
    </View>
  );
}

export function GeneralPerformanceCard({
  metrics,
}: GeneralPerformanceCardProps) {
  return (
    <SurfaceCard style={styles.card}>
      <View style={styles.headingRow}>
        <Text style={styles.sectionTitle}>Desempenho geral</Text>
        <Text style={styles.attempts}>{metrics.totalAttempts} tentativas</Text>
      </View>

      <View style={styles.content}>
        <View
          accessibilityLabel={`Desempenho geral: ${metrics.successRate} por cento`}
          style={styles.ring}
        >
          <View style={styles.ringContent}>
            <Text style={styles.trophy}>★</Text>
            <Text style={styles.ringValue}>{metrics.successRate}%</Text>
          </View>
        </View>

        <View style={styles.stats}>
          <MetricStat
            color={colors.teal}
            detail={`${metrics.correctAnswers} acertos`}
            label="Taxa de acertos"
            value={metrics.successRate}
          />
          <MetricStat
            color={colors.pink}
            detail={`${metrics.errors} erros`}
            label="Taxa de erros"
            value={metrics.errorRate}
          />
        </View>
      </View>
    </SurfaceCard>
  );
}

const styles = StyleSheet.create({
  card: {
    paddingHorizontal: 17,
    paddingVertical: 18,
  },
  headingRow: {
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  sectionTitle: {
    color: colors.tealDark,
    fontSize: 20,
    fontWeight: "800",
    letterSpacing: -0.3,
  },
  attempts: {
    color: colors.muted,
    fontSize: 10.5,
    fontWeight: "700",
  },
  content: {
    alignItems: "center",
    flexDirection: "row",
    gap: 14,
  },
  ring: {
    alignItems: "center",
    borderColor: colors.teal,
    borderLeftColor: "#DAE9EA",
    borderRadius: 52,
    borderWidth: 11,
    height: 104,
    justifyContent: "center",
    transform: [{ rotate: "16deg" }],
    width: 104,
  },
  ringContent: {
    alignItems: "center",
    transform: [{ rotate: "-16deg" }],
  },
  trophy: {
    color: colors.yellowDark,
    fontSize: 22,
    fontWeight: "900",
    lineHeight: 24,
  },
  ringValue: {
    color: colors.tealDark,
    fontSize: 19,
    fontWeight: "900",
  },
  stats: {
    flex: 1,
    flexDirection: "row",
    gap: 9,
    minWidth: 0,
  },
  statCard: {
    backgroundColor: "#FBFCFD",
    borderColor: colors.divider,
    borderRadius: 15,
    borderWidth: 1,
    flex: 1,
    minHeight: 112,
    minWidth: 0,
    paddingHorizontal: 10,
    paddingVertical: 10,
  },
  statLabel: {
    color: colors.tealDark,
    fontSize: 11,
    fontWeight: "800",
    lineHeight: 14,
    minHeight: 28,
  },
  statValue: {
    fontSize: 26,
    fontWeight: "900",
    letterSpacing: -0.5,
    lineHeight: 32,
  },
  statDetail: {
    color: colors.muted,
    fontSize: 9.5,
    marginTop: 7,
  },
});
