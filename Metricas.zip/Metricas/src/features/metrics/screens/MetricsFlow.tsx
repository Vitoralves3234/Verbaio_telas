import React, { useState } from "react";

import { GeneratedMetricsPdf } from "../types/metrics";
import { MetricsScreen } from "./MetricsScreen";
import { PdfGeneratedScreen } from "./PdfGeneratedScreen";

export function MetricsFlow() {
  const [generatedPdf, setGeneratedPdf] = useState<GeneratedMetricsPdf | null>(
    null
  );

  if (generatedPdf) {
    return (
      <PdfGeneratedScreen
        onBack={() => setGeneratedPdf(null)}
        pdf={generatedPdf}
      />
    );
  }

  return <MetricsScreen onPdfGenerated={setGeneratedPdf} />;
}
