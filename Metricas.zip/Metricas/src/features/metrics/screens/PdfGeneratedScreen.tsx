import React, { useState } from "react";
import { Alert, Pressable, StyleSheet, Text, View } from "react-native";

import { ScreenLayout } from "../../../shared/components/ScreenLayout";
import { colors } from "../../../theme/colors";
import { PdfActionButton } from "../components/PdfActionButton";
import { PdfSummaryCard } from "../components/PdfSummaryCard";
import {
  printMetricsPdf,
  saveMetricsPdf,
  shareMetricsPdf,
  viewMetricsPdf,
} from "../services/metricsPdfService";
import { GeneratedMetricsPdf } from "../types/metrics";

type PdfGeneratedScreenProps = {
  onBack: () => void;
  pdf: GeneratedMetricsPdf;
};

type PdfAction = "download" | "print" | "share" | "view";

export function PdfGeneratedScreen({ onBack, pdf }: PdfGeneratedScreenProps) {
  const [activeAction, setActiveAction] = useState<PdfAction | null>(null);

  const runAction = async (
    action: PdfAction,
    callback: () => Promise<void>
  ) => {
    if (activeAction) {
      return;
    }

    setActiveAction(action);
    try {
      await callback();
    } catch (cause) {
      Alert.alert(
        "Não foi possível concluir",
        cause instanceof Error
          ? cause.message
          : "Tente novamente em alguns instantes."
      );
    } finally {
      setActiveAction(null);
    }
  };

  const handleDownload = () =>
    runAction("download", async () => {
      const result = await saveMetricsPdf(pdf);
      Alert.alert(
        "PDF baixado",
        `${result.fileName} foi salvo em ${result.location}.`
      );
    });

  return (
    <ScreenLayout
      onBack={onBack}
      subtitle="O relatório foi criado com sucesso."
      title="PDF gerado"
    >
      <PdfSummaryCard pdf={pdf} />

      <PdfActionButton
        accessibilityLabel="Visualizar PDF"
        icon="◉"
        label="Visualizar PDF"
        loading={activeAction === "view"}
        onPress={() => runAction("view", () => viewMetricsPdf(pdf))}
        primary
      />

      <View style={styles.actionRow}>
        <PdfActionButton
          accessibilityLabel="Compartilhar PDF"
          icon="⌯"
          label="Compartilhar"
          loading={activeAction === "share"}
          onPress={() => runAction("share", () => shareMetricsPdf(pdf))}
        />
        <PdfActionButton
          accessibilityLabel="Baixar PDF"
          icon="↓"
          label="Baixar"
          loading={activeAction === "download"}
          onPress={handleDownload}
        />
      </View>

      <PdfActionButton
        accessibilityLabel="Imprimir PDF"
        icon="▣"
        label="Imprimir novamente"
        loading={activeAction === "print"}
        onPress={() => runAction("print", () => printMetricsPdf(pdf))}
      />

      <View style={styles.orRow}>
        <View style={styles.line} />
        <Text style={styles.orText}>ou</Text>
        <View style={styles.line} />
      </View>

      <Pressable
        accessibilityLabel="Voltar às métricas"
        accessibilityRole="button"
        onPress={onBack}
        style={({ pressed }) => [
          styles.backButton,
          pressed ? styles.pressed : null,
        ]}
      >
        <Text style={styles.backArrow}>←</Text>
        <Text style={styles.backText}>Voltar às métricas</Text>
      </Pressable>

      <View style={styles.infoCard}>
        <Text style={styles.infoIcon}>i</Text>
        <Text style={styles.infoText}>
          Você pode visualizar, compartilhar, baixar ou imprimir o arquivo
          gerado.
        </Text>
      </View>
    </ScreenLayout>
  );
}

const styles = StyleSheet.create({
  actionRow: {
    flexDirection: "row",
    gap: 12,
  },
  orRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: 13,
    marginTop: 3,
  },
  line: {
    backgroundColor: "#DDDDCE",
    flex: 1,
    height: 1,
  },
  orText: {
    color: colors.muted,
    fontSize: 11,
  },
  backButton: {
    alignItems: "center",
    alignSelf: "center",
    borderRadius: 18,
    flexDirection: "row",
    paddingHorizontal: 18,
    paddingVertical: 10,
  },
  backArrow: {
    color: colors.teal,
    fontSize: 26,
    fontWeight: "700",
    marginRight: 10,
  },
  backText: {
    color: colors.tealDark,
    fontSize: 14,
    fontWeight: "900",
  },
  infoCard: {
    alignItems: "center",
    alignSelf: "center",
    backgroundColor: colors.tealSoft,
    borderRadius: 18,
    flexDirection: "row",
    marginTop: 2,
    maxWidth: 430,
    paddingHorizontal: 18,
    paddingVertical: 15,
    width: "88%",
  },
  infoIcon: {
    color: colors.teal,
    fontSize: 24,
    fontWeight: "900",
    marginRight: 13,
  },
  infoText: {
    color: colors.tealDark,
    flex: 1,
    fontSize: 11.5,
    lineHeight: 17,
  },
  pressed: {
    opacity: 0.7,
  },
});
