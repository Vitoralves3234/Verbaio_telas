import React, { useEffect, useMemo, useState } from "react";
import { Alert } from "react-native";

import { ScreenLayout } from "../../../shared/components/ScreenLayout";
import { EvolutionChart } from "../components/EvolutionChart";
import { GeneralPerformanceCard } from "../components/GeneralPerformanceCard";
import { GenerateMetricsPdfCard } from "../components/GenerateMetricsPdfCard";
import { MetricsFilters } from "../components/MetricsFilters";
import { MetricsStatusCard } from "../components/MetricsStatusCard";
import { SkillPerformanceCard } from "../components/SkillPerformanceCard";
import { getPeriodLabel } from "../data/metricDefinitions";
import { useMetricsData } from "../hooks/useMetricsData";
import { calculateMetrics } from "../services/calculateMetrics";
import { createMetricsPdf } from "../services/metricsPdfService";
import {
  GeneratedMetricsPdf,
  MetricsDataSource,
  MetricsPeriod,
} from "../types/metrics";

type MetricsScreenProps = {
  dataSource?: MetricsDataSource;
  onBack?: () => void;
  onPdfGenerated: (pdf: GeneratedMetricsPdf) => void;
};

export function MetricsScreen({
  dataSource,
  onBack,
  onPdfGenerated,
}: MetricsScreenProps) {
  const { data, error, loading, refresh } = useMetricsData(dataSource);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [period, setPeriod] = useState<MetricsPeriod>(30);
  const [phase, setPhase] = useState("Fase 1");

  useEffect(() => {
    if (
      data.phases.length > 0 &&
      phase !== "all" &&
      !data.phases.includes(phase)
    ) {
      setPhase(data.phases[0]);
    }
  }, [data.phases, phase]);

  const dashboard = useMemo(
    () => calculateMetrics(data.records, { period, phase }),
    [data.records, period, phase]
  );
  const phaseLabel = phase === "all" ? "Todas as fases" : phase;
  const periodLabel = getPeriodLabel(period);

  const handleGeneratePdf = async () => {
    if (generatingPdf) {
      return;
    }

    setGeneratingPdf(true);
    try {
      const pdf = await createMetricsPdf({
        dashboard,
        patientName: data.patient.name || "Paciente não informado",
        periodLabel,
        phaseLabel,
      });
      onPdfGenerated(pdf);
    } catch (cause) {
      Alert.alert(
        "Falha ao gerar o PDF",
        cause instanceof Error
          ? cause.message
          : "Não foi possível criar o relatório agora."
      );
    } finally {
      setGeneratingPdf(false);
    }
  };

  return (
    <ScreenLayout
      onBack={onBack}
      subtitle="Acompanhe o desempenho da criança de forma simples e visual."
      title="Métricas"
    >
      <MetricsFilters
        onPeriodChange={setPeriod}
        onPhaseChange={setPhase}
        period={period}
        phase={phase}
        phases={data.phases}
      />

      {loading || error || !dashboard.hasData ? (
        <MetricsStatusCard
          error={error}
          loading={loading}
          onRefresh={refresh}
        />
      ) : null}

      <GeneralPerformanceCard metrics={dashboard.general} />
      <SkillPerformanceCard metrics={dashboard.skills} />
      <EvolutionChart
        dates={dashboard.evolutionDates}
        series={dashboard.evolutionSeries}
      />
      <GenerateMetricsPdfCard
        generating={generatingPdf}
        onGenerate={handleGeneratePdf}
      />
    </ScreenLayout>
  );
}
