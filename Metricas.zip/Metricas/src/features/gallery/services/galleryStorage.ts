import ReactNativeBlobUtil from 'react-native-blob-util';
import { Asset } from 'react-native-image-picker';

import { GalleryImage } from '../types/gallery';

const galleryDirectory = `${ReactNativeBlobUtil.fs.dirs.DocumentDir}/verbaio-gallery`;
const galleryIndexPath = `${galleryDirectory}/gallery.json`;

async function ensureGalleryDirectory() {
  const exists = await ReactNativeBlobUtil.fs.exists(galleryDirectory);

  if (!exists) {
    await ReactNativeBlobUtil.fs.mkdir(galleryDirectory);
  }
}

function safeExtension(asset: Asset) {
  const fileNameExtension = asset.fileName?.split('.').pop()?.toLowerCase();

  if (fileNameExtension?.match(/^[a-z0-9]{2,5}$/)) {
    return fileNameExtension;
  }

  if (asset.type === 'image/png') {
    return 'png';
  }

  if (asset.type === 'image/webp') {
    return 'webp';
  }

  if (asset.type === 'image/heic' || asset.type === 'image/heif') {
    return 'heic';
  }

  return 'jpg';
}

function makeImageId(index: number) {
  return `${Date.now().toString(36)}-${index}-${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

async function copyAssetToGallery(asset: Asset, index: number) {
  if (!asset.uri) {
    return null;
  }

  await ensureGalleryDirectory();

  const id = makeImageId(index);
  const extension = safeExtension(asset);
  const localPath = `${galleryDirectory}/${id}.${extension}`;

  if (asset.uri.startsWith('content://')) {
    await ReactNativeBlobUtil.MediaCollection.copyToInternal(
      asset.uri,
      localPath,
    );
  } else {
    await ReactNativeBlobUtil.fs.cp(asset.uri.replace(/^file:\/\//, ''), localPath);
  }

  const image: GalleryImage = {
    fileName: asset.fileName || `imagem-${id}.${extension}`,
    height: asset.height,
    id,
    importedAt: new Date().toISOString(),
    localPath,
    mimeType: asset.type || `image/${extension}`,
    selected: false,
    uri: `file://${localPath}`,
    width: asset.width,
  };

  return image;
}

export async function importGalleryImages(assets: Asset[]) {
  const results = await Promise.allSettled(
    assets.map((asset, index) => copyAssetToGallery(asset, index)),
  );

  return results.flatMap(result =>
    result.status === 'fulfilled' && result.value ? [result.value] : [],
  );
}

export async function loadGalleryImages(): Promise<GalleryImage[]> {
  try {
    const indexExists = await ReactNativeBlobUtil.fs.exists(galleryIndexPath);

    if (!indexExists) {
      return [];
    }

    const content = await ReactNativeBlobUtil.fs.readFile(
      galleryIndexPath,
      'utf8',
    );
    const images = JSON.parse(content) as GalleryImage[];
    const checkedImages = await Promise.all(
      images.map(async image => ({
        exists: await ReactNativeBlobUtil.fs.exists(image.localPath),
        image,
      })),
    );

    return checkedImages
      .filter(item => item.exists)
      .map(item => item.image);
  } catch {
    return [];
  }
}

export async function saveGalleryImages(images: GalleryImage[]) {
  await ensureGalleryDirectory();
  await ReactNativeBlobUtil.fs.writeFile(
    galleryIndexPath,
    JSON.stringify(images),
    'utf8',
  );
}

export async function removeGalleryImages(images: GalleryImage[]) {
  await Promise.allSettled(
    images.map(async image => {
      const exists = await ReactNativeBlobUtil.fs.exists(image.localPath);

      if (exists) {
        await ReactNativeBlobUtil.fs.unlink(image.localPath);
      }
    }),
  );
}
