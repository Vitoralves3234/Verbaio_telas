import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';

import { colors } from '../../../theme/colors';

type GalleryImportCardProps = {
  importing: boolean;
  onImport: () => void;
};

export function GalleryImportCard({
  importing,
  onImport,
}: GalleryImportCardProps) {
  return (
    <View style={styles.card}>
      <View style={styles.icon}>
        <Text style={styles.iconText}>＋</Text>
      </View>
      <View style={styles.copy}>
        <Text style={styles.title}>Adicionar imagens</Text>
        <Text style={styles.description}>
          Escolha uma ou várias fotos armazenadas no celular.
        </Text>
      </View>
      <Pressable
        accessibilityLabel="Importar imagens do celular"
        accessibilityRole="button"
        disabled={importing}
        onPress={onImport}
        style={({ pressed }) => [
          styles.button,
          pressed ? styles.pressed : null,
          importing ? styles.disabled : null,
        ]}
      >
        {importing ? (
          <ActivityIndicator color={colors.white} size="small" />
        ) : (
          <Text style={styles.buttonText}>Escolher imagens</Text>
        )}
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: 'center',
    backgroundColor: colors.white,
    borderRadius: 24,
    elevation: 4,
    padding: 20,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.13,
    shadowRadius: 6,
  },
  icon: {
    alignItems: 'center',
    backgroundColor: colors.tealSoft,
    borderRadius: 24,
    height: 48,
    justifyContent: 'center',
    width: 48,
  },
  iconText: {
    color: colors.tealDark,
    fontSize: 31,
    fontWeight: '500',
    lineHeight: 34,
  },
  copy: {
    alignItems: 'center',
    marginBottom: 15,
    marginTop: 10,
  },
  title: {
    color: colors.ink,
    fontSize: 18,
    fontWeight: '800',
  },
  description: {
    color: colors.text,
    fontSize: 13.5,
    lineHeight: 19,
    marginTop: 4,
    textAlign: 'center',
  },
  button: {
    alignItems: 'center',
    backgroundColor: colors.teal,
    borderRadius: 16,
    justifyContent: 'center',
    minHeight: 48,
    paddingHorizontal: 26,
    width: '100%',
  },
  buttonText: {
    color: colors.white,
    fontSize: 15,
    fontWeight: '800',
  },
  disabled: {
    opacity: 0.65,
  },
  pressed: {
    opacity: 0.78,
    transform: [{ scale: 0.99 }],
  },
});
