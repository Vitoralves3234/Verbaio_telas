import React from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';

import { colors } from '../../../theme/colors';
import { GalleryImage } from '../types/gallery';

type GalleryImageCardProps = {
  image: GalleryImage;
  itemWidth: number;
  onToggle: () => void;
};

export function GalleryImageCard({
  image,
  itemWidth,
  onToggle,
}: GalleryImageCardProps) {
  return (
    <Pressable
      accessibilityLabel={`${image.selected ? 'Desmarcar' : 'Selecionar'} imagem ${image.fileName}`}
      accessibilityRole="button"
      onPress={onToggle}
      style={({ pressed }) => [
        styles.card,
        { width: itemWidth },
        image.selected ? styles.selectedCard : null,
        pressed ? styles.pressed : null,
      ]}
    >
      <Image resizeMode="cover" source={{ uri: image.uri }} style={styles.image} />

      <View style={[styles.check, image.selected ? styles.checkSelected : null]}>
        <Text style={[styles.checkText, image.selected ? styles.checkTextSelected : null]}>
          {image.selected ? '✓' : ''}
        </Text>
      </View>

      <View style={styles.nameBar}>
        <Text numberOfLines={1} style={styles.fileName}>
          {image.fileName}
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    aspectRatio: 1,
    backgroundColor: colors.white,
    borderColor: colors.white,
    borderRadius: 19,
    borderWidth: 3,
    elevation: 3,
    overflow: 'hidden',
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.13,
    shadowRadius: 4,
  },
  selectedCard: {
    borderColor: colors.teal,
  },
  image: {
    height: '100%',
    width: '100%',
  },
  check: {
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.92)',
    borderColor: colors.teal,
    borderRadius: 13,
    borderWidth: 2,
    height: 27,
    justifyContent: 'center',
    position: 'absolute',
    right: 9,
    top: 9,
    width: 27,
  },
  checkSelected: {
    backgroundColor: colors.teal,
  },
  checkText: {
    color: 'transparent',
    fontSize: 16,
    fontWeight: '900',
  },
  checkTextSelected: {
    color: colors.white,
  },
  nameBar: {
    backgroundColor: 'rgba(17, 24, 39, 0.72)',
    bottom: 0,
    left: 0,
    paddingHorizontal: 10,
    paddingVertical: 7,
    position: 'absolute',
    right: 0,
  },
  fileName: {
    color: colors.white,
    fontSize: 11.5,
    fontWeight: '700',
  },
  pressed: {
    opacity: 0.82,
    transform: [{ scale: 0.98 }],
  },
});
