export type GalleryImage = {
  fileName: string;
  height?: number;
  id: string;
  importedAt: string;
  localPath: string;
  mimeType: string;
  selected: boolean;
  uri: string;
  width?: number;
};
