import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';

import { ScreenLayout } from '../../../shared/components/ScreenLayout';
import { colors } from '../../../theme/colors';
import { GalleryActions } from '../components/GalleryActions';
import { GalleryEmptyState } from '../components/GalleryEmptyState';
import { GalleryImageCard } from '../components/GalleryImageCard';
import { GalleryImportCard } from '../components/GalleryImportCard';
import {
  importGalleryImages,
  loadGalleryImages,
  removeGalleryImages,
  saveGalleryImages,
} from '../services/galleryStorage';
import { GalleryImage } from '../types/gallery';

export function GalleryScreen() {
  const { width } = useWindowDimensions();
  const [images, setImages] = useState<GalleryImage[]>([]);
  const [importing, setImporting] = useState(false);
  const [loading, setLoading] = useState(true);

  const itemWidth = Math.max(130, (width - 50) / 2);
  const selectedImages = useMemo(
    () => images.filter(image => image.selected),
    [images],
  );

  useEffect(() => {
    let active = true;

    loadGalleryImages().then(storedImages => {
      if (active) {
        setImages(storedImages);
        setLoading(false);
      }
    });

    return () => {
      active = false;
    };
  }, []);

  async function importImages() {
    if (importing) {
      return;
    }

    setImporting(true);

    try {
      const response = await launchImageLibrary({
        assetRepresentationMode: 'compatible',
        includeBase64: false,
        mediaType: 'photo',
        selectionLimit: 0,
      });

      if (response.didCancel) {
        return;
      }

      if (response.errorCode) {
        Alert.alert(
          'Não foi possível abrir a galeria',
          response.errorMessage || 'Tente novamente.',
        );
        return;
      }

      const assets = response.assets || [];
      const importedImages = await importGalleryImages(assets);

      if (!importedImages.length) {
        Alert.alert(
          'Nenhuma imagem importada',
          'Não foi possível copiar as imagens selecionadas.',
        );
        return;
      }

      const nextImages = [...images, ...importedImages];
      await saveGalleryImages(nextImages);
      setImages(nextImages);

      if (importedImages.length < assets.length) {
        Alert.alert(
          'Importação concluída parcialmente',
          `${importedImages.length} de ${assets.length} imagens foram adicionadas.`,
        );
      }
    } catch {
      Alert.alert(
        'Erro ao importar imagens',
        'Não foi possível concluir a importação. Tente novamente.',
      );
    } finally {
      setImporting(false);
    }
  }

  function updateAndSave(nextImages: GalleryImage[]) {
    setImages(nextImages);
    saveGalleryImages(nextImages).catch(() => {});
  }

  function toggleImage(imageId: string) {
    updateAndSave(
      images.map(image =>
        image.id === imageId
          ? { ...image, selected: !image.selected }
          : image,
      ),
    );
  }

  function toggleAllImages() {
    const shouldSelect = selectedImages.length !== images.length;
    updateAndSave(
      images.map(image => ({ ...image, selected: shouldSelect })),
    );
  }

  function confirmRemoveSelected() {
    Alert.alert(
      'Remover da galeria?',
      `As ${selectedImages.length} imagens selecionadas serão removidas apenas do Verbaio. As fotos originais continuarão no celular.`,
      [
        { style: 'cancel', text: 'Cancelar' },
        {
          onPress: async () => {
            await removeGalleryImages(selectedImages);
            const selectedIds = new Set(
              selectedImages.map(image => image.id),
            );
            const remainingImages = images.filter(
              image => !selectedIds.has(image.id),
            );
            await saveGalleryImages(remainingImages);
            setImages(remainingImages);
          },
          style: 'destructive',
          text: 'Remover',
        },
      ],
    );
  }

  return (
    <ScreenLayout
      subtitle="Importe e selecione imagens para usar futuramente."
      title="Galeria"
    >
      <GalleryImportCard importing={importing} onImport={importImages} />

      {loading ? (
        <Text style={styles.loading}>Carregando imagens...</Text>
      ) : images.length ? (
        <>
          <GalleryActions
            imageCount={images.length}
            onRemoveSelected={confirmRemoveSelected}
            onToggleAll={toggleAllImages}
            selectedCount={selectedImages.length}
          />
          <View style={styles.grid}>
            {images.map(image => (
              <GalleryImageCard
                image={image}
                itemWidth={itemWidth}
                key={image.id}
                onToggle={() => toggleImage(image.id)}
              />
            ))}
          </View>
          <View style={styles.futureNote}>
            <Text style={styles.futureNoteTitle}>Seleção pronta para o futuro</Text>
            <Text style={styles.futureNoteText}>
              As imagens marcadas ficam registradas para serem utilizadas quando
              a próxima função do aplicativo for criada.
            </Text>
          </View>
        </>
      ) : (
        <GalleryEmptyState onImport={importImages} />
      )}
    </ScreenLayout>
  );
}

const styles = StyleSheet.create({
  loading: {
    color: colors.muted,
    fontSize: 14,
    paddingVertical: 28,
    textAlign: 'center',
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  futureNote: {
    backgroundColor: colors.yellowSoft,
    borderColor: colors.yellow,
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
  },
  futureNoteTitle: {
    color: colors.ink,
    fontSize: 14.5,
    fontWeight: '800',
  },
  futureNoteText: {
    color: colors.text,
    fontSize: 13,
    lineHeight: 19,
    marginTop: 4,
  },
});
