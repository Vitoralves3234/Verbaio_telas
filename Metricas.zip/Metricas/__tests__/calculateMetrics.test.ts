import { calculateMetrics } from "../src/features/metrics/services/calculateMetrics";
import { MetricRecord } from "../src/features/metrics/types/metrics";

const records: MetricRecord[] = [
  {
    attempts: 10,
    correctAnswers: 8,
    id: "recent-matching",
    occurredAt: "2026-09-08T12:00:00.000Z",
    phase: "Fase 1",
    skill: "matching",
  },
  {
    attempts: 10,
    correctAnswers: 5,
    id: "recent-identification",
    occurredAt: "2026-09-09T12:00:00.000Z",
    phase: "Fase 1",
    skill: "identification",
  },
  {
    attempts: 10,
    correctAnswers: 2,
    id: "old-matching",
    occurredAt: "2026-05-01T12:00:00.000Z",
    phase: "Fase 1",
    skill: "matching",
  },
  {
    attempts: 4,
    correctAnswers: 4,
    id: "other-phase",
    occurredAt: "2026-09-09T13:00:00.000Z",
    phase: "Fase 2",
    skill: "sentences",
  },
];

describe("calculateMetrics", () => {
  it("calcula os indicadores da fase e do período selecionados", () => {
    const dashboard = calculateMetrics(
      records,
      { period: 30, phase: "Fase 1" },
      new Date("2026-09-10T12:00:00.000Z")
    );

    expect(dashboard.general).toEqual({
      correctAnswers: 13,
      errorRate: 35,
      errors: 7,
      successRate: 65,
      totalAttempts: 20,
    });
    expect(
      dashboard.skills.find((skill) => skill.id === "matching")?.score
    ).toBe(80);
    expect(dashboard.evolutionDates).toEqual(["08/09", "09/09"]);
  });

  it("recalcula ao trocar o filtro e mantém zeros quando não há dados", () => {
    const allPeriods = calculateMetrics(
      records,
      { period: "all", phase: "Fase 1" },
      new Date("2026-09-10T12:00:00.000Z")
    );
    const noData = calculateMetrics(
      records,
      { period: 7, phase: "Fase inexistente" },
      new Date("2026-09-10T12:00:00.000Z")
    );

    expect(allPeriods.general.totalAttempts).toBe(30);
    expect(
      allPeriods.skills.find((skill) => skill.id === "matching")?.score
    ).toBe(50);
    expect(noData.hasData).toBe(false);
    expect(noData.general.successRate).toBe(0);
    expect(noData.skills.every((skill) => skill.score === 0)).toBe(true);
  });
});
