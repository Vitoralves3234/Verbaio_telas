import React from "react";
import { Platform } from "react-native";
import ReactNativeBlobUtil from "react-native-blob-util";
import { print } from "react-native-print";
import Share from "react-native-share";
import {
  act,
  create,
  ReactTestInstance,
  ReactTestRenderer,
} from "react-test-renderer";

import { MetricsFlow } from "../src/features/metrics/screens/MetricsFlow";
import { MetricsScreen } from "../src/features/metrics/screens/MetricsScreen";
import { MetricsDataSource } from "../src/features/metrics/types/metrics";

function findByLabel(root: ReactTestInstance, label: string) {
  return root.find((node) => node.props.accessibilityLabel === label);
}

function hasText(root: ReactTestInstance, text: string) {
  return root.findAll((node) => node.props.children === text).length > 0;
}

async function flushEffects() {
  await act(async () => {
    await new Promise<void>((resolve) => setImmediate(() => resolve()));
  });
}

describe("fluxo funcional de métricas", () => {
  let tree: ReactTestRenderer;

  afterEach(async () => {
    await act(async () => {
      tree.unmount();
    });
    jest.clearAllMocks();
  });

  it("carrega dados externos e permite alterar o período", async () => {
    const recentDate = new Date(Date.now() - 2 * 24 * 60 * 60 * 1000);
    const oldDate = new Date(Date.now() - 120 * 24 * 60 * 60 * 1000);
    const dataSource: MetricsDataSource = async () => ({
      patient: { id: "child-1", name: "João Pedro" },
      phases: ["Fase 1"],
      records: [
        {
          attempts: 10,
          correctAnswers: 8,
          id: "recent",
          occurredAt: recentDate.toISOString(),
          phase: "Fase 1",
          skill: "matching",
        },
        {
          attempts: 10,
          correctAnswers: 2,
          id: "old",
          occurredAt: oldDate.toISOString(),
          phase: "Fase 1",
          skill: "matching",
        },
      ],
    });

    await act(async () => {
      tree = create(
        <MetricsScreen dataSource={dataSource} onPdfGenerated={jest.fn()} />
      );
    });
    await flushEffects();

    expect(
      findByLabel(tree.root, "Desempenho geral: 80 por cento")
    ).toBeTruthy();

    act(() => findByLabel(tree.root, "Escolher período").props.onPress());
    act(() =>
      findByLabel(tree.root, "Selecionar Todo o período").props.onPress()
    );

    expect(
      findByLabel(tree.root, "Desempenho geral: 50 por cento")
    ).toBeTruthy();
  });

  it("gera o PDF e abre uma tela independente com ações reais", async () => {
    await act(async () => {
      tree = create(<MetricsFlow />);
    });
    await flushEffects();

    await act(async () => {
      await findByLabel(tree.root, "Gerar PDF das métricas").props.onPress();
    });

    expect(hasText(tree.root, "PDF gerado")).toBe(true);
    expect(findByLabel(tree.root, "Visualizar PDF")).toBeTruthy();
    expect(findByLabel(tree.root, "Compartilhar PDF")).toBeTruthy();
    expect(findByLabel(tree.root, "Baixar PDF")).toBeTruthy();
    expect(findByLabel(tree.root, "Imprimir PDF")).toBeTruthy();
    expect(ReactNativeBlobUtil.fs.writeFile).toHaveBeenCalledWith(
      expect.stringMatching(/Metricas_Verbaio_\d+\.pdf$/),
      expect.stringContaining("%PDF-1.4"),
      "utf8"
    );
  });

  it("executa visualizar, compartilhar, baixar, imprimir e voltar", async () => {
    await act(async () => {
      tree = create(<MetricsFlow />);
    });
    await flushEffects();
    await act(async () => {
      await findByLabel(tree.root, "Gerar PDF das métricas").props.onPress();
    });

    await act(async () => {
      await findByLabel(tree.root, "Visualizar PDF").props.onPress();
    });
    if (Platform.OS === "ios") {
      expect(ReactNativeBlobUtil.ios.previewDocument).toHaveBeenCalled();
    } else {
      expect(ReactNativeBlobUtil.android.actionViewIntent).toHaveBeenCalled();
    }

    await act(async () => {
      await findByLabel(tree.root, "Compartilhar PDF").props.onPress();
    });
    expect(Share.open).toHaveBeenCalledWith(
      expect.objectContaining({ type: "application/pdf" })
    );

    await act(async () => {
      await findByLabel(tree.root, "Baixar PDF").props.onPress();
    });
    expect(ReactNativeBlobUtil.fs.cp).toHaveBeenCalled();

    await act(async () => {
      await findByLabel(tree.root, "Imprimir PDF").props.onPress();
    });
    expect(print).toHaveBeenCalledWith(
      expect.objectContaining({ filePath: expect.stringMatching(/\.pdf$/) })
    );

    act(() => findByLabel(tree.root, "Voltar às métricas").props.onPress());
    await flushEffects();
    expect(hasText(tree.root, "Métricas")).toBe(true);
  });
});
