import fs from "fs";
import path from "path";
import ReactNativeBlobUtil from "react-native-blob-util";

import { calculateMetrics } from "../src/features/metrics/services/calculateMetrics";
import { createMetricsPdf } from "../src/features/metrics/services/metricsPdfService";
import { MetricRecord } from "../src/features/metrics/types/metrics";

describe("metricsPdfService", () => {
  it("gera um PDF válido com os dados calculados", async () => {
    const outputPath = path.resolve(
      __dirname,
      "../tmp/pdfs/metricas-verbaio-amostra.pdf"
    );
    const records: MetricRecord[] = [
      {
        attempts: 20,
        correctAnswers: 16,
        id: "sample-1",
        occurredAt: "2026-09-08T12:00:00.000Z",
        phase: "Fase 1",
        skill: "matching",
      },
      {
        attempts: 20,
        correctAnswers: 14,
        id: "sample-2",
        occurredAt: "2026-09-09T12:00:00.000Z",
        phase: "Fase 1",
        skill: "identification",
      },
      {
        attempts: 10,
        correctAnswers: 6,
        id: "sample-3",
        occurredAt: "2026-09-10T12:00:00.000Z",
        phase: "Fase 1",
        skill: "sentences",
      },
    ];
    const dashboard = calculateMetrics(
      records,
      { period: 30, phase: "Fase 1" },
      new Date("2026-09-10T18:00:00.000Z")
    );
    const writeFileMock = ReactNativeBlobUtil.fs.writeFile as jest.Mock;

    writeFileMock.mockImplementationOnce(
      async (_nativePath: string, data: string) => {
        fs.mkdirSync(path.dirname(outputPath), { recursive: true });
        fs.writeFileSync(outputPath, data, "utf8");
      }
    );

    await createMetricsPdf({
      dashboard,
      patientName: "João Pedro",
      periodLabel: "Últimos 30 dias",
      phaseLabel: "Fase 1",
    });

    const generated = fs.readFileSync(outputPath);
    expect(generated.subarray(0, 8).toString("ascii")).toBe("%PDF-1.4");
    expect(generated.toString("ascii")).toContain("Relatorio de metricas");
    expect(generated.length).toBeGreaterThan(1500);
  });
});
