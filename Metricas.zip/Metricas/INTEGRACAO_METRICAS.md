# Integração das métricas

A tela não contém indicadores fixos. Todos os cartões, percentuais, contadores,
habilidades, linhas do gráfico e valores do PDF são calculados a partir da lista
de registros recebida pela fonte de dados.

## Arquivo que deve ser conectado

Edite somente:

`src/features/metrics/data/metricsDataSource.ts`

A função `loadMetricsData` deve devolver uma `Promise` neste formato:

```ts
{
  patient: { id: 'crianca-123', name: 'João Pedro' },
  phases: ['Fase 1', 'Fase 2'],
  records: [
    {
      id: 'atividade-1',
      occurredAt: '2026-09-10T14:30:00.000Z',
      phase: 'Fase 1',
      skill: 'matching',
      attempts: 10,
      correctAnswers: 8,
    },
  ],
}
```

Valores aceitos em `skill`:

- `matching`: pareamentos;
- `identification`: identificação;
- `sentences`: formação de frases;
- `interpretation`: interpretação/comunicação.

## Exemplo usando uma API

```ts
export const loadMetricsData: MetricsDataSource = async () => {
  const response = await fetch(
    "https://sua-api/pacientes/crianca-123/metricas"
  );

  if (!response.ok) {
    throw new Error("Não foi possível carregar as métricas.");
  }

  return response.json();
};
```

Depois dessa ligação, o botão **Atualizar** consulta a fonte novamente. Os filtros
de fase e período recalculam os dados já carregados, e **Gerar PDF** cria o
relatório exatamente com o filtro exibido na tela.
