import React from 'react';
import { Image, StyleSheet, TextInput, View } from 'react-native';

import { colors } from '../../../theme/colors';

const helpIcon = require('../../../assets/comuns/navegacao_ajuda.png');

type HelpSearchProps = {
  onChangeText: (value: string) => void;
  value: string;
};

export function HelpSearch({ onChangeText, value }: HelpSearchProps) {
  return (
    <View style={styles.container}>
      <Image source={helpIcon} style={styles.icon} />
      <TextInput
        accessibilityLabel="Pesquisar na ajuda"
        autoCapitalize="none"
        clearButtonMode="while-editing"
        onChangeText={onChangeText}
        placeholder="Digite sua dúvida"
        placeholderTextColor={colors.muted}
        returnKeyType="search"
        style={styles.input}
        value={value}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    backgroundColor: colors.white,
    borderColor: colors.divider,
    borderRadius: 18,
    borderWidth: 1,
    elevation: 2,
    flexDirection: 'row',
    minHeight: 58,
    paddingHorizontal: 16,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
  },
  icon: {
    height: 27,
    marginRight: 11,
    resizeMode: 'contain',
    width: 27,
  },
  input: {
    color: colors.ink,
    flex: 1,
    fontSize: 16,
    minHeight: 54,
    paddingVertical: 0,
  },
});
