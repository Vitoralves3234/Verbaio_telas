import React from 'react';
import { Alert, Pressable, StyleSheet, Text, View } from 'react-native';

import { colors } from '../../../theme/colors';

function showSupportInstructions() {
  Alert.alert(
    'Como pedir ajuda',
    'Entre em contato com a clínica ou com o profissional responsável pelo acompanhamento. Informe o nome da criança e descreva o que aconteceu.',
  );
}

export function SupportCard() {
  return (
    <View style={styles.card}>
      <View style={styles.icon}>
        <Text style={styles.iconText}>?</Text>
      </View>
      <View style={styles.copy}>
        <Text style={styles.title}>Ainda precisa de ajuda?</Text>
        <Text style={styles.description}>
          Veja o que informar ao solicitar atendimento.
        </Text>
      </View>
      <Pressable
        accessibilityLabel="Ver como pedir ajuda"
        accessibilityRole="button"
        onPress={showSupportInstructions}
        style={({ pressed }) => [
          styles.button,
          pressed ? styles.pressed : null,
        ]}
      >
        <Text style={styles.buttonText}>Ver orientação</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: 'center',
    backgroundColor: colors.teal,
    borderRadius: 24,
    elevation: 4,
    padding: 20,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.14,
    shadowRadius: 5,
  },
  icon: {
    alignItems: 'center',
    backgroundColor: colors.white,
    borderRadius: 23,
    height: 46,
    justifyContent: 'center',
    width: 46,
  },
  iconText: {
    color: colors.tealDark,
    fontSize: 25,
    fontWeight: '900',
  },
  copy: {
    alignItems: 'center',
    marginVertical: 11,
  },
  title: {
    color: colors.white,
    fontSize: 18,
    fontWeight: '800',
  },
  description: {
    color: colors.white,
    fontSize: 13.5,
    lineHeight: 19,
    marginTop: 4,
    opacity: 0.94,
    textAlign: 'center',
  },
  button: {
    backgroundColor: colors.yellow,
    borderRadius: 15,
    paddingHorizontal: 22,
    paddingVertical: 12,
  },
  buttonText: {
    color: '#573E00',
    fontSize: 14,
    fontWeight: '800',
  },
  pressed: {
    opacity: 0.78,
    transform: [{ scale: 0.98 }],
  },
});
