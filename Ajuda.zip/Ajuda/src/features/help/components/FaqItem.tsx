import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors } from '../../../theme/colors';
import { HelpQuestion } from '../types/help';

type FaqItemProps = {
  expanded: boolean;
  item: HelpQuestion;
  onPress: () => void;
};

export function FaqItem({ expanded, item, onPress }: FaqItemProps) {
  return (
    <View style={styles.item}>
      <Pressable
        accessibilityLabel={`${expanded ? 'Fechar' : 'Abrir'} resposta: ${item.question}`}
        accessibilityRole="button"
        onPress={onPress}
        style={({ pressed }) => [
          styles.questionButton,
          pressed ? styles.pressed : null,
        ]}
      >
        <View style={styles.questionCopy}>
          <Text style={styles.category}>{item.category}</Text>
          <Text style={styles.question}>{item.question}</Text>
        </View>
        <View style={[styles.toggle, expanded ? styles.toggleExpanded : null]}>
          <Text
            style={[
              styles.toggleText,
              expanded ? styles.toggleTextExpanded : null,
            ]}
          >
            {expanded ? '−' : '+'}
          </Text>
        </View>
      </Pressable>

      {expanded ? <Text style={styles.answer}>{item.answer}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  item: {
    borderBottomColor: colors.divider,
    borderBottomWidth: 1,
    paddingVertical: 4,
  },
  questionButton: {
    alignItems: 'center',
    flexDirection: 'row',
    minHeight: 70,
    paddingVertical: 10,
  },
  questionCopy: {
    flex: 1,
    paddingRight: 12,
  },
  category: {
    color: colors.tealDark,
    fontSize: 11.5,
    fontWeight: '800',
    letterSpacing: 0.3,
    marginBottom: 3,
    textTransform: 'uppercase',
  },
  question: {
    color: colors.ink,
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
  },
  toggle: {
    alignItems: 'center',
    backgroundColor: colors.tealSoft,
    borderRadius: 14,
    height: 30,
    justifyContent: 'center',
    width: 30,
  },
  toggleExpanded: {
    backgroundColor: colors.teal,
  },
  toggleText: {
    color: colors.tealDark,
    fontSize: 20,
    fontWeight: '700',
    lineHeight: 22,
  },
  toggleTextExpanded: {
    color: colors.white,
  },
  answer: {
    color: colors.text,
    fontSize: 14,
    lineHeight: 21,
    paddingBottom: 18,
    paddingRight: 36,
  },
  pressed: {
    opacity: 0.7,
  },
});
