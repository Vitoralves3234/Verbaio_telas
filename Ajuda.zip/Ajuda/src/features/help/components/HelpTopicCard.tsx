import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { HelpTopic } from '../types/help';

type HelpTopicCardProps = {
  onPress: () => void;
  topic: HelpTopic;
};

export function HelpTopicCard({ onPress, topic }: HelpTopicCardProps) {
  return (
    <Pressable
      accessibilityLabel={`Abrir ajuda sobre ${topic.label}`}
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        { backgroundColor: topic.background },
        pressed ? styles.pressed : null,
      ]}
    >
      <View style={[styles.icon, { backgroundColor: topic.accent }]}>
        <Text style={styles.symbol}>{topic.symbol}</Text>
      </View>
      <View style={styles.copy}>
        <Text style={[styles.label, { color: topic.accent }]}>{topic.label}</Text>
        <Text style={styles.description}>{topic.description}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 20,
    flexBasis: '47%',
    flexGrow: 1,
    minHeight: 142,
    padding: 16,
  },
  icon: {
    alignItems: 'center',
    borderRadius: 15,
    height: 38,
    justifyContent: 'center',
    marginBottom: 12,
    width: 38,
  },
  symbol: {
    color: '#FFFFFF',
    fontSize: 19,
    fontWeight: '900',
  },
  copy: {
    flex: 1,
  },
  label: {
    fontSize: 15.5,
    fontWeight: '800',
    lineHeight: 19,
  },
  description: {
    color: '#4B5563',
    fontSize: 12.5,
    lineHeight: 17,
    marginTop: 5,
  },
  pressed: {
    opacity: 0.76,
    transform: [{ scale: 0.98 }],
  },
});
