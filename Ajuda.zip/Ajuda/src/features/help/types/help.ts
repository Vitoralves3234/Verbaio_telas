export type HelpTopic = {
  accent: string;
  background: string;
  description: string;
  id: string;
  label: string;
  searchTerm: string;
  symbol: string;
};

export type HelpQuestion = {
  answer: string;
  category: string;
  id: string;
  question: string;
};
