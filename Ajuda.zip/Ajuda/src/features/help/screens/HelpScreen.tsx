import React, { useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { ScreenLayout } from '../../../shared/components/ScreenLayout';
import { SurfaceCard } from '../../../shared/components/SurfaceCard';
import { colors } from '../../../theme/colors';
import { FaqItem } from '../components/FaqItem';
import { HelpSearch } from '../components/HelpSearch';
import { HelpTopicCard } from '../components/HelpTopicCard';
import { SupportCard } from '../components/SupportCard';
import { helpQuestions, helpTopics } from '../data/helpContent';

function normalize(value: string) {
  return value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('pt-BR')
    .trim();
}

export function HelpScreen() {
  const [query, setQuery] = useState('');
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>(null);

  const filteredQuestions = useMemo(() => {
    const normalizedQuery = normalize(query);

    if (!normalizedQuery) {
      return helpQuestions;
    }

    return helpQuestions.filter(item =>
      normalize(`${item.category} ${item.question} ${item.answer}`).includes(
        normalizedQuery,
      ),
    );
  }, [query]);

  function selectTopic(searchTerm: string) {
    setQuery(searchTerm);
    setExpandedQuestion(null);
  }

  return (
    <ScreenLayout
      subtitle="Encontre respostas e orientações sobre o aplicativo."
      title="Ajuda"
    >
      <View style={styles.introduction}>
        <Text style={styles.welcome}>Olá! Como podemos ajudar?</Text>
        <Text style={styles.introductionText}>
          Pesquise uma dúvida ou escolha um assunto abaixo.
        </Text>
      </View>

      <HelpSearch onChangeText={setQuery} value={query} />

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Ajuda rápida</Text>
      </View>

      <View style={styles.topicGrid}>
        {helpTopics.map(topic => (
          <HelpTopicCard
            key={topic.id}
            onPress={() => selectTopic(topic.searchTerm)}
            topic={topic}
          />
        ))}
      </View>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Perguntas frequentes</Text>
        {query ? (
          <Text style={styles.resultCount}>
            {`${filteredQuestions.length} ${
              filteredQuestions.length === 1 ? 'resultado' : 'resultados'
            }`}
          </Text>
        ) : null}
      </View>

      <SurfaceCard style={styles.faqCard}>
        {filteredQuestions.length ? (
          filteredQuestions.map(item => (
            <FaqItem
              expanded={expandedQuestion === item.id}
              item={item}
              key={item.id}
              onPress={() =>
                setExpandedQuestion(current =>
                  current === item.id ? null : item.id,
                )
              }
            />
          ))
        ) : (
          <View style={styles.emptyState}>
            <Text style={styles.emptyTitle}>Nenhuma resposta encontrada</Text>
            <Text style={styles.emptyText}>
              Tente pesquisar usando menos palavras.
            </Text>
          </View>
        )}
      </SurfaceCard>

      <SupportCard />
    </ScreenLayout>
  );
}

const styles = StyleSheet.create({
  introduction: {
    paddingHorizontal: 2,
    paddingTop: 2,
  },
  welcome: {
    color: colors.ink,
    fontSize: 21,
    fontWeight: '800',
  },
  introductionText: {
    color: colors.text,
    fontSize: 14,
    lineHeight: 20,
    marginTop: 4,
  },
  sectionHeader: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 3,
    paddingHorizontal: 2,
  },
  sectionTitle: {
    color: colors.ink,
    fontSize: 18,
    fontWeight: '800',
  },
  resultCount: {
    color: colors.muted,
    fontSize: 12.5,
    fontWeight: '600',
  },
  topicGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  faqCard: {
    paddingHorizontal: 18,
  },
  emptyState: {
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 30,
  },
  emptyTitle: {
    color: colors.ink,
    fontSize: 15.5,
    fontWeight: '800',
    textAlign: 'center',
  },
  emptyText: {
    color: colors.muted,
    fontSize: 13.5,
    marginTop: 5,
    textAlign: 'center',
  },
});
