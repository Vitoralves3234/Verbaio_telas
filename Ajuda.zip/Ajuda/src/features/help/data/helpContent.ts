import { colors } from '../../../theme/colors';
import { HelpQuestion, HelpTopic } from '../types/help';

export const helpTopics: HelpTopic[] = [
  {
    accent: colors.tealDark,
    background: colors.tealSoft,
    description: 'Entenda os primeiros passos no aplicativo.',
    id: 'getting-started',
    label: 'Primeiros passos',
    searchTerm: 'começar',
    symbol: '1',
  },
  {
    accent: colors.blue,
    background: colors.blueSoft,
    description: 'Consulte resultados e baixe o relatório.',
    id: 'metrics',
    label: 'Métricas e PDF',
    searchTerm: 'pdf',
    symbol: '%',
  },
  {
    accent: colors.purple,
    background: colors.purpleSoft,
    description: 'Saiba como funcionam os dados protegidos.',
    id: 'account',
    label: 'Conta e dados',
    searchTerm: 'dados',
    symbol: 'i',
  },
  {
    accent: colors.pink,
    background: colors.pinkSoft,
    description: 'Veja soluções para problemas comuns.',
    id: 'technical',
    label: 'Problemas técnicos',
    searchTerm: 'erro',
    symbol: '!',
  },
];

export const helpQuestions: HelpQuestion[] = [
  {
    answer:
      'Explore as opções disponíveis na tela inicial e escolha a área que deseja consultar. Os dados são organizados para facilitar o acompanhamento da criança.',
    category: 'Primeiros passos',
    id: 'first-access',
    question: 'Como começar a usar o Verbaio?',
  },
  {
    answer:
      'Abra a área de métricas, role até o final da tela e toque em “Baixar PDF das métricas”. O relatório será criado com os dados do período selecionado.',
    category: 'Métricas e PDF',
    id: 'download-pdf',
    question: 'Como baixar o PDF das métricas?',
  },
  {
    answer:
      'No Android, o relatório é salvo na pasta Downloads/Verbaio. O nome do arquivo inclui a data em que ele foi criado.',
    category: 'Métricas e PDF',
    id: 'find-pdf',
    question: 'Onde encontro o PDF baixado?',
  },
  {
    answer:
      'Não. As informações da criança, do responsável, da clínica e do profissional são protegidas e ficam disponíveis apenas para consulta.',
    category: 'Conta e dados',
    id: 'edit-data',
    question: 'Posso alterar os dados cadastrados?',
  },
  {
    answer:
      'Feche o aplicativo completamente e abra novamente. Se o problema continuar, anote o que apareceu na tela e procure a clínica ou o profissional responsável pelo acompanhamento.',
    category: 'Problemas técnicos',
    id: 'app-error',
    question: 'O que fazer quando o aplicativo apresenta erro?',
  },
];
