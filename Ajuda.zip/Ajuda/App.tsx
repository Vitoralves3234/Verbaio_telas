import React from 'react';
import { StatusBar } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { HelpScreen } from './src/features/help/screens/HelpScreen';
import { colors } from './src/theme/colors';

function App() {
  return (
    <SafeAreaProvider>
      <StatusBar
        backgroundColor={colors.teal}
        barStyle="light-content"
        translucent={false}
      />
      <HelpScreen />
    </SafeAreaProvider>
  );
}

export default App;
