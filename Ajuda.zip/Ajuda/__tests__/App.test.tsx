/**
 * @format
 */

import React from 'react';
import { Alert, TextInput } from 'react-native';
import ReactTestRenderer from 'react-test-renderer';

import App from '../App';

jest.mock('react-native-safe-area-context', () => ({
  SafeAreaProvider: ({ children }: { children: React.ReactNode }) => children,
  useSafeAreaInsets: () => ({ bottom: 0, left: 0, right: 0, top: 0 }),
}));

beforeEach(() => {
  jest.clearAllMocks();
});

test('renders the standalone help screen', async () => {
  let component: ReactTestRenderer.ReactTestRenderer;

  await ReactTestRenderer.act(() => {
    component = ReactTestRenderer.create(<App />);
  });

  expect(component!.root.findByProps({ title: 'Ajuda' })).toBeTruthy();
  expect(
    component!.root.findByProps({ accessibilityLabel: 'Pesquisar na ajuda' }),
  ).toBeTruthy();
  expect(component!.root.findAllByType(TextInput)).toHaveLength(1);
  expect(
    component!.root.findByProps({ children: 'Perguntas frequentes' }),
  ).toBeTruthy();
});

test('opens and closes a frequently asked question', async () => {
  let component: ReactTestRenderer.ReactTestRenderer;

  await ReactTestRenderer.act(() => {
    component = ReactTestRenderer.create(<App />);
  });

  const question = 'Como baixar o PDF das métricas?';
  const answer =
    'Abra a área de métricas, role até o final da tela e toque em “Baixar PDF das métricas”. O relatório será criado com os dados do período selecionado.';

  await ReactTestRenderer.act(() => {
    component!.root
      .findByProps({ accessibilityLabel: `Abrir resposta: ${question}` })
      .props.onPress();
  });

  expect(component!.root.findByProps({ children: answer })).toBeTruthy();

  await ReactTestRenderer.act(() => {
    component!.root
      .findByProps({ accessibilityLabel: `Fechar resposta: ${question}` })
      .props.onPress();
  });

  expect(
    component!.root.findAllByProps({ children: answer }),
  ).toHaveLength(0);
});

test('filters the help questions', async () => {
  let component: ReactTestRenderer.ReactTestRenderer;

  await ReactTestRenderer.act(() => {
    component = ReactTestRenderer.create(<App />);
  });

  await ReactTestRenderer.act(() => {
    component!.root
      .findByProps({ accessibilityLabel: 'Pesquisar na ajuda' })
      .props.onChangeText('PDF');
  });

  expect(component!.root.findByProps({ children: '2 resultados' })).toBeTruthy();
  expect(
    component!.root.findAllByProps({
      children: 'Posso alterar os dados cadastrados?',
    }),
  ).toHaveLength(0);
});

test('uses a quick-help topic to filter the questions', async () => {
  let component: ReactTestRenderer.ReactTestRenderer;

  await ReactTestRenderer.act(() => {
    component = ReactTestRenderer.create(<App />);
  });

  await ReactTestRenderer.act(() => {
    component!.root
      .findByProps({ accessibilityLabel: 'Abrir ajuda sobre Primeiros passos' })
      .props.onPress();
  });

  expect(component!.root.findByProps({ children: '1 resultado' })).toBeTruthy();
  expect(
    component!.root.findByProps({ children: 'Como começar a usar o Verbaio?' }),
  ).toBeTruthy();
});

test('shows support instructions', async () => {
  let component: ReactTestRenderer.ReactTestRenderer;
  jest.spyOn(Alert, 'alert').mockImplementation(() => {});

  await ReactTestRenderer.act(() => {
    component = ReactTestRenderer.create(<App />);
  });

  await ReactTestRenderer.act(() => {
    component!.root
      .findByProps({ accessibilityLabel: 'Ver como pedir ajuda' })
      .props.onPress();
  });

  expect(Alert.alert).toHaveBeenCalledWith(
    'Como pedir ajuda',
    expect.stringContaining('clínica'),
  );
});
