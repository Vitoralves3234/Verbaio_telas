import React from "react";
import { StatusBar } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { AppNavigator } from "./src/app/AppNavigator";
import { colors } from "./src/theme/colors";

function App() {
  return (
    <SafeAreaProvider>
      <StatusBar
        backgroundColor={colors.teal}
        barStyle="light-content"
        translucent={false}
      />
      <AppNavigator />
    </SafeAreaProvider>
  );
}

export default App;
