import React, { useState } from 'react';

import { ChildAccountScreen } from '../features/child-profile/screens/ChildAccountScreen';
import { initialChildProfile } from '../features/child-profile/types/childProfile';
import { ClinicProfileScreen } from '../features/profile/screens/ClinicProfileScreen';
import { ProfessionalProfileScreen } from '../features/profile/screens/ProfessionalProfileScreen';
import { ResponsibleProfileScreen } from '../features/profile/screens/ResponsibleProfileScreen';
import { AccountRole } from '../features/profile/types/accountProfile';

export type AppScreen = 'child-account' | 'account-profile';

type AppNavigatorProps = {
  initialAccountRole?: AccountRole;
  initialScreen?: AppScreen;
};

export function AppNavigator({
  initialAccountRole = 'responsible',
  initialScreen = 'child-account',
}: AppNavigatorProps) {
  const [screen, setScreen] = useState<AppScreen>(initialScreen);

  if (screen === 'account-profile') {
    const commonProps = {
      onBack: () => setScreen('child-account'),
    };

    if (initialAccountRole === 'clinic') {
      return <ClinicProfileScreen {...commonProps} />;
    }

    if (initialAccountRole === 'professional') {
      return <ProfessionalProfileScreen {...commonProps} />;
    }

    return <ResponsibleProfileScreen {...commonProps} />;
  }

  return (
    <ChildAccountScreen
      childProfile={initialChildProfile}
      onBack={() => {}}
      onResponsiblePress={() => setScreen('account-profile')}
    />
  );
}
