import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { colors } from '../../theme/colors';

type ReadOnlyFieldProps = {
  label: string;
  marker: string;
  value: string;
};

export function ReadOnlyField({ label, marker, value }: ReadOnlyFieldProps) {
  return (
    <View
      accessibilityLabel={`${label}: ${value}`}
      accessibilityRole="text"
      style={styles.field}
    >
      <View style={styles.marker}>
        <Text style={styles.markerText}>{marker}</Text>
      </View>
      <View style={styles.copy}>
        <Text style={styles.label}>{label}</Text>
        <View style={styles.valueBox}>
          <Text selectable style={styles.value}>
            {value}
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  field: {
    alignItems: 'flex-end',
    flexDirection: 'row',
    marginBottom: 13,
  },
  marker: {
    alignItems: 'center',
    backgroundColor: colors.tealSoft,
    borderRadius: 16,
    height: 32,
    justifyContent: 'center',
    marginBottom: 9,
    marginRight: 12,
    width: 32,
  },
  markerText: {
    color: colors.tealDark,
    fontSize: 14,
    fontWeight: '900',
  },
  copy: {
    flex: 1,
    minWidth: 0,
  },
  label: {
    color: colors.text,
    fontSize: 13,
    marginBottom: 5,
    marginLeft: 8,
  },
  valueBox: {
    backgroundColor: colors.readOnly,
    borderColor: colors.divider,
    borderRadius: 14,
    borderWidth: 1,
    minHeight: 49,
    justifyContent: 'center',
    paddingHorizontal: 14,
  },
  value: {
    color: colors.text,
    fontSize: 15,
  },
});
