import React from 'react';
import { StyleSheet, View, ViewStyle } from 'react-native';

import { colors } from '../../theme/colors';

type SurfaceCardProps = {
  children: React.ReactNode;
  style?: ViewStyle;
};

export function SurfaceCard({ children, style }: SurfaceCardProps) {
  return <View style={[styles.card, style]}>{children}</View>;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.white,
    borderRadius: 26,
    elevation: 5,
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.16,
    shadowRadius: 6,
  },
});
