import { AccountProfile } from '../types/accountProfile';

export const responsibleProfile: AccountProfile = {
  title: 'Juliana Oliveira',
  roleLabel: 'Responsável',
  screenTitle: 'Informações do responsável',
  subtitle: 'Conta vinculada à criança',
  fields: [
    { label: 'Nome do responsável', marker: 'R', value: 'Juliana Oliveira' },
    { label: 'E-mail', marker: '@', value: 'juliana.oliveira@email.com' },
    { label: 'Telefone', marker: 'T', value: '(67) 99999-9999' },
    { label: 'Plano', marker: 'P', value: 'Premium' },
  ],
};

export const clinicProfile: AccountProfile = {
  title: 'Clínica Verbaio',
  roleLabel: 'Clínica',
  screenTitle: 'Informações da clínica',
  subtitle: 'Conta institucional',
  fields: [
    { label: 'Nome da clínica', marker: 'C', value: 'Clínica Verbaio' },
    { label: 'CNPJ', marker: 'ID', value: '12.345.678/0001-90' },
    { label: 'Responsável técnico', marker: 'R', value: 'Dra. Marina Costa' },
    { label: 'E-mail', marker: '@', value: 'contato@clinicaverbaio.com.br' },
    { label: 'Telefone', marker: 'T', value: '(67) 3333-4444' },
  ],
};

export const professionalProfile: AccountProfile = {
  title: 'Dra. Camila Souza',
  roleLabel: 'Profissional',
  screenTitle: 'Informações profissionais',
  subtitle: 'Conta de atendimento',
  fields: [
    { label: 'Nome completo', marker: 'N', value: 'Dra. Camila Souza' },
    { label: 'Especialidade', marker: 'E', value: 'Fonoaudióloga' },
    { label: 'Registro profissional', marker: 'ID', value: 'CRFa 2-12345' },
    { label: 'E-mail', marker: '@', value: 'camila.souza@email.com' },
    { label: 'Telefone', marker: 'T', value: '(67) 98888-7777' },
  ],
};
