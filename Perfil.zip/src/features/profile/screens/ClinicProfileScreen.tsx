import React from 'react';

import { LockedProfileScreen } from '../components/LockedProfileScreen';
import { clinicProfile } from '../data/initialProfiles';

type ClinicProfileScreenProps = {
  onBack: () => void;
};

export function ClinicProfileScreen({ onBack }: ClinicProfileScreenProps) {
  return <LockedProfileScreen onBack={onBack} profile={clinicProfile} />;
}
