import React from 'react';

import { LockedProfileScreen } from '../components/LockedProfileScreen';
import { professionalProfile } from '../data/initialProfiles';

type ProfessionalProfileScreenProps = {
  onBack: () => void;
};

export function ProfessionalProfileScreen({
  onBack,
}: ProfessionalProfileScreenProps) {
  return <LockedProfileScreen onBack={onBack} profile={professionalProfile} />;
}
