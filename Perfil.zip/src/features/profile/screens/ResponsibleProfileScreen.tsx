import React from 'react';

import { LockedProfileScreen } from '../components/LockedProfileScreen';
import { responsibleProfile } from '../data/initialProfiles';

type ResponsibleProfileScreenProps = {
  onBack: () => void;
};

export function ResponsibleProfileScreen({
  onBack,
}: ResponsibleProfileScreenProps) {
  return <LockedProfileScreen onBack={onBack} profile={responsibleProfile} />;
}
