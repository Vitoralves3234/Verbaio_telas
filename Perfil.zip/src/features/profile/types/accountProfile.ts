export type AccountRole = 'responsible' | 'clinic' | 'professional';

export type AccountProfileField = {
  label: string;
  marker: string;
  value: string;
};

export type AccountProfile = {
  fields: AccountProfileField[];
  roleLabel: string;
  screenTitle: string;
  subtitle: string;
  title: string;
};
