import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

import { ReadOnlyField } from '../../../shared/components/ReadOnlyField';
import { ScreenLayout } from '../../../shared/components/ScreenLayout';
import { SurfaceCard } from '../../../shared/components/SurfaceCard';
import { colors } from '../../../theme/colors';
import { AccountProfile } from '../types/accountProfile';

type LockedProfileScreenProps = {
  onBack: () => void;
  profile: AccountProfile;
};

export function LockedProfileScreen({
  onBack,
  profile,
}: LockedProfileScreenProps) {
  return (
    <ScreenLayout onBack={onBack} title={profile.screenTitle}>
      <SurfaceCard style={styles.card}>
        <View style={styles.identity}>
          <View style={styles.avatarPlaceholder}>
            <Text style={styles.avatarText}>
              {profile.roleLabel.slice(0, 1).toUpperCase()}
            </Text>
          </View>
          <View style={styles.identityCopy}>
            <Text style={styles.name}>{profile.title}</Text>
            <View style={styles.rolePill}>
              <Text style={styles.roleText}>{profile.roleLabel}</Text>
            </View>
            <Text style={styles.subtitle}>{profile.subtitle}</Text>
          </View>
        </View>

        <View accessibilityRole="text" style={styles.lockNotice}>
          <Text style={styles.lockIcon}>●</Text>
          <Text style={styles.lockText}>
            Informações protegidas. Estes dados não podem ser alterados no
            aplicativo.
          </Text>
        </View>

        <View style={styles.fields}>
          {profile.fields.map(field => (
            <ReadOnlyField
              key={field.label}
              label={field.label}
              marker={field.marker}
              value={field.value}
            />
          ))}
        </View>
      </SurfaceCard>
    </ScreenLayout>
  );
}

const styles = StyleSheet.create({
  card: {
    paddingBottom: 12,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  identity: {
    alignItems: 'center',
    flexDirection: 'row',
    marginBottom: 17,
  },
  avatarPlaceholder: {
    alignItems: 'center',
    backgroundColor: colors.teal,
    borderRadius: 37,
    height: 74,
    justifyContent: 'center',
    marginRight: 15,
    width: 74,
  },
  avatarText: {
    color: colors.white,
    fontSize: 30,
    fontWeight: '900',
  },
  identityCopy: {
    alignItems: 'flex-start',
    flex: 1,
    minWidth: 0,
  },
  name: {
    color: colors.ink,
    fontSize: 22,
    fontWeight: '800',
  },
  rolePill: {
    backgroundColor: colors.tealSoft,
    borderRadius: 14,
    marginTop: 4,
    paddingHorizontal: 10,
    paddingVertical: 3,
  },
  roleText: {
    color: colors.tealDark,
    fontSize: 12,
    fontWeight: '800',
  },
  subtitle: {
    color: colors.muted,
    fontSize: 12,
    marginTop: 4,
  },
  lockNotice: {
    alignItems: 'center',
    backgroundColor: colors.yellowSoft,
    borderColor: colors.yellow,
    borderRadius: 16,
    borderWidth: 1,
    flexDirection: 'row',
    marginBottom: 18,
    paddingHorizontal: 13,
    paddingVertical: 11,
  },
  lockIcon: {
    color: colors.yellowDark,
    fontSize: 15,
    marginRight: 9,
  },
  lockText: {
    color: colors.text,
    flex: 1,
    fontSize: 12.5,
    lineHeight: 18,
  },
  fields: {
    paddingTop: 1,
  },
});
