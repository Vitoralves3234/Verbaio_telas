import React from 'react';

import { ScreenLayout } from '../../../shared/components/ScreenLayout';
import { ChildInformationCard } from '../components/ChildInformationCard';
import { ChildObjectivesCard } from '../components/ChildObjectivesCard';
import { ResponsibleInformationButton } from '../components/ResponsibleInformationButton';
import { ChildSummaryCard } from '../components/ChildSummaryCard';
import { ChildProfile } from '../types/childProfile';

type ChildAccountScreenProps = {
  childProfile: ChildProfile;
  onBack?: () => void;
  onResponsiblePress: () => void;
};

export function ChildAccountScreen({
  childProfile,
  onBack,
  onResponsiblePress,
}: ChildAccountScreenProps) {
  return (
    <ScreenLayout onBack={onBack} title="Minha conta">
      <ChildSummaryCard childProfile={childProfile} />
      <ChildInformationCard childProfile={childProfile} />
      <ChildObjectivesCard objectives={childProfile.objectives} />
      <ResponsibleInformationButton onPress={onResponsiblePress} />
    </ScreenLayout>
  );
}
