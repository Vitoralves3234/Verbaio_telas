export type ChildProfile = {
  age: string;
  fullName: string;
  guardianName: string;
  guardianPhone: string;
  objectives: string[];
  photoUri?: string;
};

export const initialChildProfile: ChildProfile = {
  age: '7',
  fullName: 'Sthela Oliveira',
  guardianName: 'Juliana Oliveira',
  guardianPhone: '(67) 99999-9999',
  objectives: [
    'Formação de frases',
    'Ampliação de vocabulário',
    'Interação social',
  ],
};
