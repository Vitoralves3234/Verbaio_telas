import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';

import { SurfaceCard } from '../../../shared/components/SurfaceCard';
import { colors } from '../../../theme/colors';
import { ChildProfile } from '../types/childProfile';

const sectionIcon = require('../../../assets/dados_da_crianca/informacoes_pessoais.png');
const userIcon = require('../../../assets/dados_da_crianca/usuario_linha.png');
const calendarIcon = require('../../../assets/dados_da_crianca/calendario_linha.png');
const guardianIcon = require('../../../assets/dados_da_crianca/responsavel_linha.png');

type ChildInformationCardProps = {
  childProfile: ChildProfile;
};

type ChildDataRowProps = {
  icon: number;
  label: string;
  value: string;
};

function ChildDataRow({ icon, label, value }: ChildDataRowProps) {
  return (
    <View
      accessibilityLabel={`${label}: ${value}`}
      accessibilityRole="text"
      style={styles.dataRow}
    >
      <Image source={icon} style={styles.dataIcon} />
      <View style={styles.dataCopy}>
        <Text style={styles.dataLabel}>{label}</Text>
        <Text selectable style={styles.dataValue}>
          {value}
        </Text>
      </View>
    </View>
  );
}

export function ChildInformationCard({
  childProfile,
}: ChildInformationCardProps) {
  return (
    <SurfaceCard style={styles.card}>
      <View style={styles.heading}>
        <Image source={sectionIcon} style={styles.sectionIcon} />
        <View style={styles.headingCopy}>
          <Text style={styles.title}>Informações da criança</Text>
          <Text style={styles.subtitle}>Dados protegidos</Text>
        </View>
      </View>

      <ChildDataRow
        icon={userIcon}
        label="Nome completo"
        value={childProfile.fullName}
      />
      <ChildDataRow
        icon={calendarIcon}
        label="Idade"
        value={`${childProfile.age} ${
          childProfile.age === '1' ? 'ano' : 'anos'
        }`}
      />
      <ChildDataRow
        icon={guardianIcon}
        label="Nome do responsável"
        value={childProfile.guardianName}
      />
      <ChildDataRow
        icon={guardianIcon}
        label="Telefone do responsável"
        value={childProfile.guardianPhone}
      />
    </SurfaceCard>
  );
}

const styles = StyleSheet.create({
  card: {
    paddingBottom: 8,
    paddingHorizontal: 17,
    paddingTop: 16,
  },
  heading: {
    alignItems: 'center',
    flexDirection: 'row',
    marginBottom: 4,
  },
  sectionIcon: {
    height: 57,
    marginRight: 13,
    resizeMode: 'contain',
    width: 57,
  },
  headingCopy: {
    flex: 1,
  },
  title: {
    color: colors.ink,
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  subtitle: {
    color: colors.tealDark,
    fontSize: 12,
    marginTop: 2,
  },
  dataRow: {
    alignItems: 'center',
    borderBottomColor: colors.divider,
    borderBottomWidth: StyleSheet.hairlineWidth,
    flexDirection: 'row',
    minHeight: 62,
  },
  dataIcon: {
    height: 24,
    marginRight: 11,
    resizeMode: 'contain',
    width: 24,
  },
  dataCopy: {
    flex: 1,
    minWidth: 0,
  },
  dataLabel: {
    color: colors.muted,
    fontSize: 12,
    marginBottom: 3,
  },
  dataValue: {
    color: colors.text,
    fontSize: 15,
  },
});
