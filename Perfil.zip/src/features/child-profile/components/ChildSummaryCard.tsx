import React from 'react';
import {
  Image,
  ImageSourcePropType,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import { SurfaceCard } from '../../../shared/components/SurfaceCard';
import { colors } from '../../../theme/colors';
import { ChildProfile } from '../types/childProfile';

const defaultAvatar = require('../../../assets/comuns/avatar_sthela.png');

type ChildSummaryCardProps = {
  childProfile: ChildProfile;
};

export function ChildSummaryCard({ childProfile }: ChildSummaryCardProps) {
  const firstName = childProfile.fullName.trim().split(/\s+/)[0] || 'Criança';
  const avatarSource: ImageSourcePropType = childProfile.photoUri
    ? { uri: childProfile.photoUri }
    : defaultAvatar;

  return (
    <SurfaceCard style={styles.card}>
      <Image
        accessibilityLabel={`Foto de ${childProfile.fullName || 'criança'}`}
        resizeMode={childProfile.photoUri ? 'cover' : 'contain'}
        source={avatarSource}
        style={styles.avatar}
      />

      <View style={styles.copy}>
        <Text
          adjustsFontSizeToFit
          minimumFontScale={0.78}
          numberOfLines={1}
          style={styles.name}
        >
          {firstName}
        </Text>

        <View style={styles.pill}>
          <Text style={styles.star}>★</Text>
          <Text style={styles.pillText}>
            {childProfile.age || '—'}{' '}
            {childProfile.age === '1' ? 'ano' : 'anos'}
          </Text>
        </View>

        <View style={styles.pill}>
          <Text style={styles.check}>✓</Text>
          <Text style={styles.pillText}>Perfil ativo</Text>
        </View>
      </View>
    </SurfaceCard>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: 'center',
    flexDirection: 'row',
    minHeight: 148,
    paddingHorizontal: 22,
    paddingVertical: 16,
  },
  avatar: {
    backgroundColor: colors.background,
    borderColor: colors.white,
    borderRadius: 56,
    borderWidth: 2,
    height: 112,
    width: 112,
  },
  copy: {
    alignItems: 'flex-start',
    flex: 1,
    marginLeft: 18,
    minWidth: 0,
  },
  name: {
    color: colors.ink,
    fontSize: 28,
    fontWeight: '800',
    letterSpacing: -0.6,
    marginBottom: 5,
    maxWidth: '100%',
  },
  pill: {
    alignItems: 'center',
    alignSelf: 'flex-start',
    backgroundColor: colors.tealSoft,
    borderRadius: 16,
    flexDirection: 'row',
    marginBottom: 5,
    minHeight: 27,
    paddingHorizontal: 9,
    paddingVertical: 3,
  },
  star: {
    color: colors.yellowDark,
    fontSize: 16,
    marginRight: 6,
  },
  check: {
    backgroundColor: colors.teal,
    borderRadius: 9,
    color: colors.white,
    fontSize: 12,
    fontWeight: '900',
    height: 18,
    lineHeight: 18,
    marginRight: 6,
    textAlign: 'center',
    width: 18,
  },
  pillText: {
    color: colors.ink,
    fontSize: 13,
    fontWeight: '700',
  },
});
