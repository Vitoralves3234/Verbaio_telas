import React from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';

import { SurfaceCard } from '../../../shared/components/SurfaceCard';
import { colors } from '../../../theme/colors';

const responsibleIcon = require('../../../assets/perfil_e_conta/perfil_usuario.png');
const arrowIcon = require('../../../assets/comuns/seta_direita.png');

type ResponsibleInformationButtonProps = {
  onPress: () => void;
};

export function ResponsibleInformationButton({
  onPress,
}: ResponsibleInformationButtonProps) {
  return (
    <Pressable
      accessibilityHint="Abre os dados protegidos dos pais ou responsável"
      accessibilityLabel="Ver informações do responsável"
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [pressed ? styles.pressed : null]}
    >
      <SurfaceCard style={styles.card}>
        <View style={styles.iconCircle}>
          <Image source={responsibleIcon} style={styles.icon} />
        </View>
        <View style={styles.copy}>
          <Text style={styles.title}>Informações do responsável</Text>
          <Text style={styles.description}>
            Veja os dados dos pais ou responsável pela criança.
          </Text>
        </View>
        <Image source={arrowIcon} style={styles.arrow} />
      </SurfaceCard>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: 'center',
    flexDirection: 'row',
    minHeight: 102,
    paddingHorizontal: 17,
    paddingVertical: 14,
  },
  iconCircle: {
    alignItems: 'center',
    backgroundColor: colors.tealSoft,
    borderRadius: 31,
    height: 62,
    justifyContent: 'center',
    marginRight: 14,
    width: 62,
  },
  icon: {
    height: 34,
    resizeMode: 'contain',
    width: 34,
  },
  copy: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    color: colors.ink,
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 4,
  },
  description: {
    color: colors.muted,
    fontSize: 12.5,
    lineHeight: 18,
  },
  arrow: {
    height: 30,
    marginLeft: 10,
    resizeMode: 'contain',
    width: 23,
  },
  pressed: {
    opacity: 0.78,
    transform: [{ scale: 0.99 }],
  },
});
