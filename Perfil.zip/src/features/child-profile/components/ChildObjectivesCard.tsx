import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';

import { SurfaceCard } from '../../../shared/components/SurfaceCard';
import { colors } from '../../../theme/colors';

const objectivesIcon = require('../../../assets/dados_da_crianca/objetivos.png');

type ChildObjectivesCardProps = {
  objectives: string[];
};

export function ChildObjectivesCard({ objectives }: ChildObjectivesCardProps) {
  return (
    <SurfaceCard style={styles.card}>
      <Image source={objectivesIcon} style={styles.icon} />
      <View style={styles.content}>
        <Text style={styles.title}>Objetivos</Text>
        {objectives.map((objective, index) => (
          <View key={index} style={styles.objectiveRow}>
            <View style={styles.bullet} />
            <Text
              accessibilityLabel={`Objetivo ${index + 1}: ${objective}`}
              selectable
              style={styles.objectiveText}
            >
              {objective}
            </Text>
          </View>
        ))}
      </View>
    </SurfaceCard>
  );
}

const styles = StyleSheet.create({
  card: {
    alignItems: 'flex-start',
    flexDirection: 'row',
    paddingBottom: 14,
    paddingHorizontal: 17,
    paddingTop: 16,
  },
  icon: {
    height: 57,
    marginRight: 13,
    resizeMode: 'contain',
    width: 57,
  },
  content: {
    flex: 1,
    minWidth: 0,
  },
  title: {
    color: colors.ink,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 3,
  },
  objectiveRow: {
    alignItems: 'center',
    flexDirection: 'row',
    minHeight: 38,
  },
  bullet: {
    backgroundColor: colors.yellow,
    borderRadius: 5,
    height: 10,
    marginRight: 9,
    width: 10,
  },
  objectiveText: {
    color: colors.text,
    flex: 1,
    fontSize: 14,
    lineHeight: 20,
    paddingVertical: 8,
  },
});
