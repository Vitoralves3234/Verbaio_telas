import ReactNativeBlobUtil from 'react-native-blob-util';
import { GalleryImage } from '../src/features/gallery/types/gallery';
import { TEST_PNG_BASE64 } from './pngFixture';

export const normalDirectory = '/documents/verbaio-gallery';
export const cryptogramDirectory = '/documents/verbaio-cryptograms';

export function createNativeFileMock() {
  const files = new Map<string, string>();
  const directories = new Set<string>();
  const fs = ReactNativeBlobUtil.fs;
  (fs.exists as jest.Mock).mockImplementation(
    async (path) => files.has(path) || directories.has(path),
  );
  (fs.mkdir as jest.Mock).mockImplementation(async (path) => {
    if (directories.has(path)) {
      throw new Error('Directory already exists');
    }
    directories.add(path);
  });
  (fs.readFile as jest.Mock).mockImplementation(async (path) => {
    if (!files.has(path)) {
      throw new Error('File not found');
    }
    return files.get(path);
  });
  (fs.writeFile as jest.Mock).mockImplementation(
    async (path, content, encoding) => {
      files.set(
        path,
        encoding === 'base64'
          ? Buffer.from(content, 'base64').toString('binary')
          : content,
      );
    },
  );
  const copy = async (source: string, target: string) => {
    if (!files.has(source)) {
      throw new Error('File not found');
    }
    files.set(target, files.get(source)!);
    return target;
  };
  (fs.cp as jest.Mock).mockImplementation(copy);
  (
    ReactNativeBlobUtil.MediaCollection.copyToInternal as jest.Mock
  ).mockImplementation(copy);
  (fs.mv as jest.Mock).mockImplementation(async (source, target) => {
    await copy(source, target);
    files.delete(source);
    return true;
  });
  (fs.unlink as jest.Mock).mockImplementation(async (path) => {
    files.delete(path);
  });
  (fs.stat as jest.Mock).mockImplementation(async (path) => ({
    size: files.get(path)?.length || 0,
  }));
  const downloads = jest.fn(async (_url: string) => {
    return {
      info: () => ({ status: 200, headers: { 'Content-Type': 'image/png' } }),
      base64: () => TEST_PNG_BASE64,
    };
  });
  (ReactNativeBlobUtil.config as jest.Mock).mockImplementation(({ path }) => ({
    fetch: (_method: string, url: string) => {
      // Regressão do FileStorage 0.24.10: o app deve receber o PNG em memória.
      if (path) {
        return Promise.reject(new Error('Download interrupted.'));
      }
      return downloads(url);
    },
  }));
  return { files, directories, downloads };
}

export function seedImage(
  files: Map<string, string>,
  directory: string,
  name: string,
  selected = false,
): GalleryImage {
  const localPath = `${directory}/${name}.png`;
  const image: GalleryImage = {
    id: name,
    fileName: `${name}.png`,
    importedAt: '2026-09-12T12:00:00.000Z',
    localPath,
    mimeType: 'image/png',
    selected,
    uri: `file://${localPath}`,
  };
  files.set(localPath, 'image-bytes');
  files.set(`${directory}/gallery.json`, JSON.stringify([image]));
  return image;
}
