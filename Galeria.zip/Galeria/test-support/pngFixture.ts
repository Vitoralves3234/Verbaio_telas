import { readFileSync } from 'fs';
import { join } from 'path';

// PNG criado para estes testes; não contém pictogramas do catálogo ARASAAC.
export const TEST_PNG = readFileSync(join(__dirname, 'fixtures/sample.png'));
export const TEST_PNG_BASE64 = TEST_PNG.toString('base64');
export const TEST_PNG_BINARY = TEST_PNG.toString('binary');
