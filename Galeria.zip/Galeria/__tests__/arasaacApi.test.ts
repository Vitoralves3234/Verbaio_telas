import {
  ARASAAC_SEARCH_TIMEOUT,
  arasaacImageUrl,
  searchArasaac,
} from '../src/features/gallery/services/arasaacApi';

describe('busca pública do ARASAAC', () => {
  const originalFetch = global.fetch;
  let request: jest.Mock;
  beforeEach(() => {
    request = jest.fn();
    global.fetch = request;
  });
  afterEach(() => {
    global.fetch = originalFetch;
    jest.useRealTimers();
  });

  it('busca em português com acentos e aceita somente IDs válidos sem duplicatas', async () => {
    request.mockResolvedValue({
      ok: true,
      status: 200,
      json: async () => [
        { _id: 1, keywords: [{ keyword: ' água ' }, { keyword: 'beber' }] },
        { _id: 1, keywords: [] },
        { _id: '../arquivo' },
        { _id: -2 },
        null,
        { _id: 3, keywords: [null, { keyword: 4 }] },
      ],
    });
    expect(await searchArasaac(' água / beber ')).toEqual([
      { id: 1, label: 'água', keywords: ['água', 'beber'] },
      { id: 3, label: 'Pictograma 3', keywords: [] },
    ]);
    expect(request).toHaveBeenCalledWith(
      'https://api.arasaac.org/v1/pictograms/pt/bestsearch/%C3%A1gua%20%2F%20beber',
      expect.objectContaining({ signal: expect.anything() }),
    );
    expect(arasaacImageUrl(1)).toBe(
      'https://static.arasaac.org/pictograms/1/1_500.png',
    );
    expect(() => arasaacImageUrl(-2)).toThrow();
  });

  it('distingue busca vazia, nenhum resultado, falha HTTP e erro de conexão', async () => {
    expect(await searchArasaac('   ')).toEqual([]);
    expect(request).not.toHaveBeenCalled();
    request.mockResolvedValueOnce({ status: 404, ok: false });
    expect(await searchArasaac('inexistente')).toEqual([]);
    request.mockResolvedValueOnce({ status: 503, ok: false });
    await expect(searchArasaac('água')).rejects.toThrow('indisponível');
    request.mockRejectedValueOnce(new TypeError('Network request failed'));
    await expect(searchArasaac('água')).rejects.toThrow('Confira sua internet');
    request.mockResolvedValueOnce({
      status: 200,
      ok: true,
      json: async () => ({ unexpected: true }),
    });
    await expect(searchArasaac('água')).rejects.toThrow('resposta inesperada');
  });

  it('interrompe uma busca que não responde, permitindo outra tentativa', async () => {
    jest.useFakeTimers();
    request.mockImplementation(
      (_url, { signal }) =>
        new Promise((_resolve, reject) => {
          signal.addEventListener('abort', () => reject(new Error('aborted')));
        }),
    );
    const pending = searchArasaac('água');
    await Promise.all([
      expect(pending).rejects.toThrow('demorou'),
      jest.advanceTimersByTimeAsync(ARASAAC_SEARCH_TIMEOUT),
    ]);
    expect(jest.getTimerCount()).toBe(0);
  });
});
