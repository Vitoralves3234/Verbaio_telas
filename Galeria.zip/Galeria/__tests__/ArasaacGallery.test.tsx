import React from 'react';
import { Alert } from 'react-native';
import ReactNativeBlobUtil from 'react-native-blob-util';
import { launchImageLibrary } from 'react-native-image-picker';
import { act, create, ReactTestRenderer } from 'react-test-renderer';
import { GalleryScreen } from '../src/features/gallery/screens/GalleryScreen';
import { TEST_PNG_BINARY, TEST_PNG_BASE64 } from '../test-support/pngFixture';
import {
  loadGalleryImages,
  loadSelectedGalleryImages,
} from '../src/features/gallery/services/galleryStorage';
import {
  createNativeFileMock,
  cryptogramDirectory,
  normalDirectory,
  seedImage,
} from '../test-support/galleryFiles';

const jsonResponse = (items: { id: number; label: string }[]) => ({
  status: 200,
  ok: true,
  json: async () =>
    items.map((item) => ({
      _id: item.id,
      keywords: [{ keyword: item.label }],
    })),
});

describe('pesquisar, adicionar e guardar pictogramas', () => {
  let tree: ReactTestRenderer;
  let native: ReturnType<typeof createNativeFileMock>;
  let request: jest.Mock;
  const originalFetch = global.fetch;
  const button = (label: string) =>
    tree.root.findAll(
      (node) =>
        node.props.accessibilityLabel === label &&
        typeof node.props.onPress === 'function',
    )[0];
  const tap = async (label: string) => {
    await act(async () => {
      await button(label).props.onPress();
    });
  };
  const type = async (value: string) => {
    await act(async () => {
      tree.root
        .findAll(
          (node) =>
            node.props.accessibilityLabel ===
              'Pesquisar pictogramas em português' &&
            typeof node.props.onChangeText === 'function',
        )[0]
        .props.onChangeText(value);
    });
  };
  const search = async (
    value: string,
    items: { id: number; label: string }[],
  ) => {
    await type(value);
    request.mockResolvedValueOnce(jsonResponse(items));
    await tap('Buscar no ARASAAC');
  };
  const mount = async () => {
    await act(async () => {
      tree = create(<GalleryScreen initialGallery="cryptograms" />);
    });
  };
  const open = async () => {
    await mount();
    await tap('Pesquisar pictogramas no ARASAAC');
  };
  beforeEach(() => {
    jest.resetAllMocks();
    native = createNativeFileMock();
    request = jest.fn();
    global.fetch = request;
    jest.spyOn(Alert, 'alert').mockImplementation(() => undefined);
  });
  afterEach(async () => {
    if (tree) {
      await act(async () => tree.unmount());
    }
    global.fetch = originalFetch;
    jest.restoreAllMocks();
  });

  it('adiciona resultados de várias buscas sem duplicar e mantém fotos e criptogramas antigos', async () => {
    const photo = seedImage(native.files, normalDirectory, 'foto', true);
    const old = seedImage(native.files, cryptogramDirectory, 'antigo', true);
    await open();
    expect(request).not.toHaveBeenCalled();
    await search('água', [{ id: 1, label: 'água' }]);
    await tap('Selecionar pictograma água, ARASAAC 1');
    await search('comer', [{ id: 2, label: 'comer' }]);
    await tap('Selecionar pictograma comer, ARASAAC 2');
    const add = button('Adicionar pictogramas selecionados').props.onPress;
    await act(async () => {
      await Promise.all([add(), add()]);
    });
    expect(launchImageLibrary).not.toHaveBeenCalled();
    expect(native.downloads).toHaveBeenCalledTimes(2);
    const stored = await loadGalleryImages('cryptograms');
    expect(stored).toHaveLength(3);
    expect(stored[0]).toEqual(old);
    expect(stored[1]).toMatchObject({
      fileName: 'água.png',
      source: {
        provider: 'arasaac',
        pictogramId: 1,
        author: 'Sergio Palao',
        license: 'CC BY-NC-SA',
      },
    });
    expect(stored[1].uri).toMatch(
      /^file:\/\/\/documents\/verbaio-cryptograms\//,
    );
    expect(native.files.get(stored[1].localPath)).toBe(TEST_PNG_BINARY);
    expect(await loadSelectedGalleryImages('images')).toEqual([photo]);
    await tap('Selecionar imagem água.png');
    await act(async () => tree.unmount());
    await mount();
    expect(button('Desmarcar imagem água.png')).toBeTruthy();
    await tap('Pesquisar pictogramas no ARASAAC');
    await search('água', [{ id: 1, label: 'água' }]);
    expect(
      button('Já adicionado pictograma água, ARASAAC 1').props.disabled,
    ).toBe(true);
    expect(button('Adicionar pictogramas selecionados').props.disabled).toBe(
      true,
    );
    expect(native.downloads).toHaveBeenCalledTimes(2);
  });

  it('não exibe resultados de uma consulta antiga depois de alterar o texto', async () => {
    await open();
    await type('água');
    let finish: (value: ReturnType<typeof jsonResponse>) => void = () => {};
    request.mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          finish = resolve;
        }),
    );
    let pending: Promise<void>;
    await act(async () => {
      pending = button('Buscar no ARASAAC').props.onPress();
    });
    const signal = request.mock.calls[0][1].signal;
    await search('comer', [{ id: 2, label: 'comer' }]);
    expect(signal.aborted).toBe(true);
    await act(async () => {
      finish(jsonResponse([{ id: 1, label: 'água' }]));
      await pending;
    });
    expect(button('Selecionar pictograma água, ARASAAC 1')).toBeUndefined();
    expect(button('Selecionar pictograma comer, ARASAAC 2')).toBeTruthy();
  });

  it('mostra erro de rede, permite tentar novamente e trata busca sem resultado', async () => {
    await open();
    await type('água');
    request.mockRejectedValueOnce(new TypeError('Network request failed'));
    await tap('Buscar no ARASAAC');
    expect(button('Tentar busca novamente')).toBeTruthy();
    request.mockResolvedValueOnce({ status: 404, ok: false });
    await tap('Tentar busca novamente');
    expect(
      tree.root.findAllByProps({ children: 'Nenhum pictograma encontrado' })
        .length,
    ).toBeGreaterThan(0);
    await tap('Voltar para a galeria');
    expect(await loadGalleryImages('cryptograms')).toEqual([]);
    expect(native.downloads).not.toHaveBeenCalled();
  });

  it('salva os downloads bem-sucedidos e permite tentar os que falharam sem repetir os anteriores', async () => {
    await open();
    await search('casa', [
      { id: 1, label: 'casa' },
      { id: 2, label: 'lar' },
    ]);
    await tap('Selecionar pictograma casa, ARASAAC 1');
    await tap('Selecionar pictograma lar, ARASAAC 2');
    native.downloads.mockImplementationOnce(async () => {
      return {
        info: () => ({ status: 503, headers: { 'Content-Type': 'text/html' } }),
        base64: () => TEST_PNG_BASE64,
      };
    });
    await tap('Adicionar pictogramas selecionados');
    expect(await loadGalleryImages('cryptograms')).toHaveLength(1);
    expect(
      button('Já adicionado pictograma lar, ARASAAC 2').props.disabled,
    ).toBe(true);
    expect(button('Desmarcar pictograma casa, ARASAAC 1')).toBeTruthy();
    expect([...native.files.values()]).not.toContain('error-html');
    expect(Alert.alert).toHaveBeenCalledWith(
      'Adição parcial',
      expect.stringContaining('HTTP 503'),
    );
    await tap('Adicionar pictogramas selecionados');
    expect(await loadGalleryImages('cryptograms')).toHaveLength(2);
    expect(native.downloads).toHaveBeenCalledTimes(3);
  });

  it('preserva o índice antigo e apaga os novos downloads se a gravação falhar', async () => {
    const old = seedImage(native.files, cryptogramDirectory, 'antigo', true);
    await open();
    await search('água', [{ id: 1, label: 'água' }]);
    await tap('Selecionar pictograma água, ARASAAC 1');
    const write = ReactNativeBlobUtil.fs.writeFile as jest.Mock;
    const originalWrite = write.getMockImplementation()!;
    let failIndex = true;
    write.mockImplementation(async (...args) => {
      if (failIndex && args[0].endsWith('/gallery.json.next')) {
        failIndex = false;
        throw new Error('Disk full');
      }
      return originalWrite(...args);
    });
    await tap('Adicionar pictogramas selecionados');
    expect(await loadGalleryImages('cryptograms')).toEqual([old]);
    expect(
      [...native.files.keys()].filter((path) => path.includes('/arasaac-')),
    ).toEqual([]);
    expect(button('Desmarcar pictograma água, ARASAAC 1')).toBeTruthy();
    await tap('Adicionar pictogramas selecionados');
    expect(await loadGalleryImages('cryptograms')).toHaveLength(2);
  });
});
