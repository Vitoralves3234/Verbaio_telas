import ReactNativeBlobUtil from 'react-native-blob-util';
import {
  importGalleryImages,
  loadGalleryImages,
  loadSelectedGalleryImages,
  removeGalleryImages,
  saveGalleryImages,
} from '../src/features/gallery/services/galleryStorage';
import {
  createNativeFileMock,
  cryptogramDirectory,
  normalDirectory,
  seedImage,
} from '../test-support/galleryFiles';

describe('armazenamento separado das galerias', () => {
  let files: Map<string, string>;
  beforeEach(() => {
    jest.resetAllMocks();
    files = createNativeFileMock().files;
  });

  it('lê o índice original sem migrar ou perder seleções', async () => {
    const image = seedImage(files, normalDirectory, 'antiga', true);
    expect(await loadGalleryImages()).toEqual([image]);
    expect(await loadGalleryImages('cryptograms')).toEqual([]);
    expect(ReactNativeBlobUtil.fs.writeFile).not.toHaveBeenCalled();
  });

  it('importa arquivos e content URIs para a coleção escolhida, incluindo vários na primeira importação', async () => {
    files.set('/phone/foto.png', 'photo');
    files.set('content://phone/simbolo', 'symbol');
    const normal = await importGalleryImages([
      { uri: 'file:///phone/foto.png', type: 'image/png' },
    ]);
    const cryptograms = await importGalleryImages(
      [
        { uri: 'content://phone/simbolo', type: 'image/png' },
        { uri: 'file:///phone/foto.png', type: 'image/png' },
      ],
      'cryptograms',
    );
    expect(cryptograms).toHaveLength(2);
    expect(normal[0].localPath).toContain(`${normalDirectory}/`);
    expect(
      cryptograms.every((image) =>
        image.localPath.startsWith(`${cryptogramDirectory}/`),
      ),
    ).toBe(true);
    await saveGalleryImages(normal);
    await saveGalleryImages(
      cryptograms.map((image) => ({ ...image, selected: true })),
      'cryptograms',
    );
    expect(await loadSelectedGalleryImages()).toEqual([]);
    expect(await loadSelectedGalleryImages('cryptograms')).toHaveLength(2);
    expect(files.get('/phone/foto.png')).toBe('photo');
  });

  it('recusa gravação e exclusão de arquivos da outra galeria', async () => {
    const normal = seedImage(files, normalDirectory, 'foto');
    await expect(saveGalleryImages([normal], 'cryptograms')).rejects.toThrow(
      'outra galeria',
    );
    await expect(removeGalleryImages([normal], 'cryptograms')).rejects.toThrow(
      'outra galeria',
    );
    expect(files.has(normal.localPath)).toBe(true);
    expect(ReactNativeBlobUtil.fs.unlink).not.toHaveBeenCalled();
  });

  it('mantém o índice anterior quando uma gravação falha', async () => {
    const normal = seedImage(files, normalDirectory, 'foto');
    (ReactNativeBlobUtil.fs.writeFile as jest.Mock).mockRejectedValueOnce(
      new Error('Disk full'),
    );
    await expect(
      saveGalleryImages([{ ...normal, selected: true }]),
    ).rejects.toThrow('Disk full');
    expect(await loadGalleryImages()).toEqual([normal]);
  });

  it('recupera o índice anterior se uma substituição de arquivo falhar', async () => {
    const normal = seedImage(files, normalDirectory, 'foto');
    const mv = ReactNativeBlobUtil.fs.mv as jest.Mock;
    const originalMove = mv.getMockImplementation()!;
    mv.mockImplementationOnce(originalMove).mockRejectedValueOnce(
      new Error('Move failed'),
    );
    await expect(
      saveGalleryImages([{ ...normal, selected: true }]),
    ).rejects.toThrow('Move failed');
    expect(await loadGalleryImages()).toEqual([normal]);
  });

  it('informa erro de leitura em vez de sobrescrever um índice inválido', async () => {
    files.set(`${cryptogramDirectory}/gallery.json`, '{incompleto');
    await expect(loadGalleryImages('cryptograms')).rejects.toThrow();
    expect(await loadGalleryImages()).toEqual([]);
    expect(ReactNativeBlobUtil.fs.writeFile).not.toHaveBeenCalled();
  });
});
