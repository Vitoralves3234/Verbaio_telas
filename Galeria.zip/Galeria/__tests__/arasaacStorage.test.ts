import ReactNativeBlobUtil from 'react-native-blob-util';
import { downloadArasaacPictograms } from '../src/features/gallery/services/arasaacStorage';
import { createNativeFileMock } from '../test-support/galleryFiles';
import {
  TEST_PNG,
  TEST_PNG_BASE64,
  TEST_PNG_BINARY,
} from '../test-support/pngFixture';

describe('download completo dos PNGs', () => {
  let native: ReturnType<typeof createNativeFileMock>;
  const casa = { id: 2317, label: 'casa', keywords: ['casa'] };
  beforeEach(() => {
    jest.resetAllMocks();
    native = createNativeFileMock();
  });

  it('salva mais de 8 KB sem usar o caminho FileStorage que interrompia o download', async () => {
    expect(TEST_PNG.length).toBeGreaterThan(8192);
    const { images, failedIds } = await downloadArasaacPictograms([casa]);
    expect(failedIds).toEqual([]);
    expect(images).toHaveLength(1);
    expect(ReactNativeBlobUtil.config).toHaveBeenCalledWith({
      timeout: 20000,
      fileCache: false,
    });
    expect(ReactNativeBlobUtil.fs.writeFile).toHaveBeenCalledWith(
      images[0].localPath,
      TEST_PNG_BASE64,
      'base64',
    );
    expect(native.files.get(images[0].localPath)).toBe(TEST_PNG_BINARY);
    expect(
      Number((await ReactNativeBlobUtil.fs.stat(images[0].localPath)).size),
    ).toBe(TEST_PNG.length);
  });

  it('aceita um PNG completo mesmo sem Content-Type e recusa conteúdo incompleto', async () => {
    native.downloads.mockResolvedValueOnce({
      info: () => ({ status: 200, headers: {} as { 'Content-Type': string } }),
      base64: () => TEST_PNG_BASE64,
    });
    expect((await downloadArasaacPictograms([casa])).images).toHaveLength(1);
    const truncated = TEST_PNG.subarray(0, 8192).toString('base64');
    native.downloads.mockResolvedValueOnce({
      info: () => ({ status: 200, headers: { 'Content-Type': 'image/png' } }),
      base64: () => truncated,
    });
    const result = await downloadArasaacPictograms([{ ...casa, id: 6964 }]);
    expect(result.images).toEqual([]);
    expect(result.failures[0].message).toContain('não é um PNG completo');
    expect(ReactNativeBlobUtil.fs.writeFile).toHaveBeenCalledTimes(1);
  });

  it('preserva a causa HTTP ou nativa para a mensagem do aplicativo', async () => {
    native.downloads.mockResolvedValueOnce({
      info: () => ({ status: 503, headers: { 'Content-Type': 'text/html' } }),
      base64: () => '',
    });
    let result = await downloadArasaacPictograms([casa]);
    expect(result.failures[0]).toMatchObject({
      id: 2317,
      message: expect.stringContaining('HTTP 503'),
    });
    native.downloads.mockRejectedValueOnce(new Error('SSL handshake failed'));
    result = await downloadArasaacPictograms([casa]);
    expect(result.failures[0].message).toContain('SSL handshake failed');
    expect(ReactNativeBlobUtil.fs.writeFile).not.toHaveBeenCalled();
  });

  it('remove gravações incompletas e informa falha ao salvar', async () => {
    (ReactNativeBlobUtil.fs.writeFile as jest.Mock).mockImplementationOnce(
      async (path: string) => {
        native.files.set(path, 'partial');
        throw new Error('ENOSPC');
      },
    );
    const result = await downloadArasaacPictograms([casa]);
    expect(result.images).toEqual([]);
    expect(result.failures[0].message).toContain('salvar');
    expect(result.failures[0].message).toContain('ENOSPC');
    expect(native.files.size).toBe(0);
  });
});
