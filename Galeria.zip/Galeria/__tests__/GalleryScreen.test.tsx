import React from 'react';
import { Alert } from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import { act, create, ReactTestRenderer } from 'react-test-renderer';
import { GalleryScreen } from '../src/features/gallery/screens/GalleryScreen';
import {
  loadGalleryImages,
  loadSelectedGalleryImages,
} from '../src/features/gallery/services/galleryStorage';
import {
  createNativeFileMock,
  cryptogramDirectory,
  normalDirectory,
  seedImage,
} from '../test-support/galleryFiles';

describe('Galeria com duas abas', () => {
  let tree: ReactTestRenderer;
  let files: Map<string, string>;
  const picker = launchImageLibrary as jest.Mock;
  const button = (label: string) =>
    tree.root.findAll(
      (node) =>
        node.props.accessibilityLabel === label &&
        typeof node.props.onPress === 'function',
    )[0];
  const tap = async (label: string) => {
    await act(async () => {
      await button(label).props.onPress();
    });
  };
  const mount = async () => {
    await act(async () => {
      tree = create(<GalleryScreen />);
    });
  };

  beforeEach(() => {
    jest.resetAllMocks();
    files = createNativeFileMock().files;
  });
  afterEach(async () => {
    if (tree) {
      await act(async () => tree.unmount());
    }
    jest.restoreAllMocks();
  });

  it('seleciona e remove criptogramas sem alterar fotos, mantendo seleções após reabrir', async () => {
    const photo = seedImage(files, normalDirectory, 'foto', true);
    const symbol = seedImage(files, cryptogramDirectory, 'simbolo');
    await mount();
    expect(button('Desmarcar imagem foto.png')).toBeTruthy();
    await tap('Galeria de criptogramas');
    expect(button('Selecionar imagem simbolo.png')).toBeTruthy();
    expect(button('Desmarcar imagem foto.png')).toBeUndefined();
    await tap('Selecionar imagem simbolo.png');
    await act(async () => tree.unmount());
    await mount();
    await tap('Galeria de criptogramas');
    expect(button('Desmarcar imagem simbolo.png')).toBeTruthy();
    expect(await loadSelectedGalleryImages()).toEqual([photo]);

    const alert = jest
      .spyOn(Alert, 'alert')
      .mockImplementation(() => undefined);
    await tap('Remover imagens selecionadas');
    const confirm = alert.mock.calls[0][2]!.find(
      (action) => action.text === 'Remover',
    )!;
    await act(async () => {
      await confirm.onPress!();
    });
    expect(await loadGalleryImages('cryptograms')).toEqual([]);
    expect(files.has(symbol.localPath)).toBe(false);
    expect(files.has(photo.localPath)).toBe(true);
    await tap('Galeria de imagens');
    expect(button('Desmarcar imagem foto.png')).toBeTruthy();
  });

  it('abre a busca para criptogramas e cancelar preserva as duas galerias', async () => {
    seedImage(files, cryptogramDirectory, 'simbolo');
    await mount();
    await tap('Galeria de criptogramas');
    await tap('Pesquisar pictogramas no ARASAAC');
    expect(button('Buscar no ARASAAC')).toBeTruthy();
    expect(picker).not.toHaveBeenCalled();
    await tap('Voltar para a galeria');
    expect(await loadGalleryImages('cryptograms')).toHaveLength(1);
    expect(await loadGalleryImages()).toHaveLength(0);
    expect(button('Selecionar imagem simbolo.png')).toBeTruthy();
    await tap('Galeria de imagens');
    picker.mockResolvedValueOnce({ didCancel: true });
    await tap('Importar imagens do celular');
    expect(await loadGalleryImages()).toHaveLength(0);
    expect(await loadGalleryImages('cryptograms')).toHaveLength(1);
  });

  it('o botão Todas atua apenas na galeria atual', async () => {
    seedImage(files, normalDirectory, 'foto');
    seedImage(files, cryptogramDirectory, 'simbolo');
    await mount();
    await tap('Selecionar todas');
    expect(await loadSelectedGalleryImages()).toHaveLength(1);
    expect(await loadSelectedGalleryImages('cryptograms')).toHaveLength(0);
    await tap('Galeria de criptogramas');
    await tap('Selecionar todas');
    await tap('Desmarcar todas');
    expect(await loadSelectedGalleryImages()).toHaveLength(1);
    expect(await loadSelectedGalleryImages('cryptograms')).toHaveLength(0);
  });
});
