import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors } from '../../../theme/colors';
import { galleryCollections, galleryKinds } from '../data/galleryCollections';
import { GalleryKind } from '../types/gallery';

type GalleryTabsProps = {
  active: GalleryKind;
  disabled: boolean;
  onChange: (kind: GalleryKind) => void;
};

export function GalleryTabs({ active, disabled, onChange }: GalleryTabsProps) {
  return (
    <View style={styles.tabs}>
      {galleryKinds.map((kind) => (
        <Pressable
          accessibilityLabel={`Galeria de ${galleryCollections[
            kind
          ].label.toLowerCase()}`}
          accessibilityRole="tab"
          accessibilityState={{ disabled, selected: active === kind }}
          disabled={disabled}
          key={kind}
          onPress={() => onChange(kind)}
          style={({ pressed }) => [
            styles.tab,
            active === kind ? styles.activeTab : null,
            pressed ? styles.pressed : null,
          ]}
        >
          <Text
            style={[styles.label, active === kind ? styles.activeLabel : null]}
          >
            {galleryCollections[kind].label}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  tabs: {
    backgroundColor: colors.tealSoft,
    borderRadius: 18,
    flexDirection: 'row',
    gap: 6,
    padding: 5,
  },
  tab: {
    alignItems: 'center',
    borderRadius: 14,
    flex: 1,
    justifyContent: 'center',
    minHeight: 48,
    paddingHorizontal: 8,
    paddingVertical: 10,
  },
  activeTab: { backgroundColor: colors.teal },
  label: { color: colors.tealDark, fontSize: 14, fontWeight: '800' },
  activeLabel: { color: colors.white },
  pressed: { opacity: 0.75 },
});
