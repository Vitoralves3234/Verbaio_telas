import React, { useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { colors } from '../../../theme/colors';
import { arasaacImageUrl } from '../services/arasaacApi';
import { ArasaacPictogram } from '../types/arasaac';

type Props = {
  pictogram: ArasaacPictogram;
  selected: boolean;
  added: boolean;
  disabled: boolean;
  width: number;
  onToggle: () => void;
};

export function ArasaacResultCard({
  pictogram,
  selected,
  added,
  disabled,
  width,
  onToggle,
}: Props) {
  const [imageFailed, setImageFailed] = useState(false);
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${
        added ? 'Já adicionado' : selected ? 'Desmarcar' : 'Selecionar'
      } pictograma ${pictogram.label}, ARASAAC ${pictogram.id}`}
      accessibilityState={{
        selected: selected || added,
        disabled: disabled || added,
      }}
      disabled={disabled || added}
      onPress={onToggle}
      style={[
        styles.card,
        { width },
        selected ? styles.selected : null,
        added ? styles.added : null,
      ]}
    >
      <View style={styles.preview}>
        {imageFailed ? (
          <Text style={styles.previewError}>Prévia indisponível</Text>
        ) : (
          <Image
            onError={() => setImageFailed(true)}
            source={{ uri: arasaacImageUrl(pictogram.id) }}
            resizeMode="contain"
            style={styles.image}
          />
        )}
        <View style={[styles.badge, added || selected ? styles.checked : null]}>
          <Text style={styles.check}>{added || selected ? '✓' : '+'}</Text>
        </View>
      </View>
      <Text numberOfLines={2} style={styles.label}>
        {pictogram.label}
      </Text>
      <Text style={styles.state}>
        {added
          ? 'Na sua galeria'
          : selected
          ? 'Selecionado'
          : 'Toque para selecionar'}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.white,
    borderColor: colors.divider,
    borderWidth: 2,
    borderRadius: 18,
    padding: 10,
    marginBottom: 12,
  },
  selected: { borderColor: colors.tealDark, backgroundColor: '#F0FBF9' },
  added: { borderColor: colors.tealSoft, backgroundColor: colors.readOnly },
  preview: { aspectRatio: 1.2, alignItems: 'center', justifyContent: 'center' },
  image: { width: '100%', height: '100%' },
  previewError: { color: colors.muted, fontSize: 12, textAlign: 'center' },
  badge: {
    position: 'absolute',
    right: 0,
    top: 0,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: colors.muted,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checked: { backgroundColor: '#08777A' },
  check: { color: colors.white, fontWeight: '800', fontSize: 19 },
  label: {
    color: colors.ink,
    fontSize: 14,
    fontWeight: '700',
    minHeight: 38,
    marginTop: 9,
  },
  state: { color: '#08777A', fontSize: 10.5, marginTop: 4 },
});
