import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors } from '../../../theme/colors';
import { galleryCollections } from '../data/galleryCollections';
import { GalleryKind } from '../types/gallery';

type GalleryEmptyStateProps = {
  disabled?: boolean;
  kind?: GalleryKind;
  onImport: () => void;
};

export function GalleryEmptyState({
  disabled = false,
  kind = 'images',
  onImport,
}: GalleryEmptyStateProps) {
  const copy = galleryCollections[kind];
  return (
    <View style={styles.container}>
      <View style={styles.pictureIcon}>
        <View style={styles.sun} />
        <View style={styles.mountainLeft} />
        <View style={styles.mountainRight} />
      </View>
      <Text style={styles.title}>{copy.emptyTitle}</Text>
      <Text style={styles.description}>{copy.emptyDescription}</Text>
      <Pressable
        accessibilityLabel={
          kind === 'cryptograms'
            ? 'Pesquisar primeiros pictogramas no ARASAAC'
            : 'Adicionar primeiras imagens'
        }
        accessibilityRole="button"
        disabled={disabled}
        accessibilityState={{ disabled }}
        onPress={onImport}
        style={({ pressed }) => [
          styles.button,
          pressed ? styles.pressed : null,
        ]}
      >
        <Text style={styles.buttonText}>{copy.importTitle}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    borderColor: colors.teal,
    borderRadius: 24,
    borderStyle: 'dashed',
    borderWidth: 2,
    paddingHorizontal: 24,
    paddingVertical: 31,
  },
  pictureIcon: {
    backgroundColor: colors.tealSoft,
    borderColor: colors.teal,
    borderRadius: 12,
    borderWidth: 2,
    height: 57,
    overflow: 'hidden',
    position: 'relative',
    width: 68,
  },
  sun: {
    backgroundColor: colors.yellow,
    borderRadius: 6,
    height: 12,
    position: 'absolute',
    right: 10,
    top: 9,
    width: 12,
  },
  mountainLeft: {
    backgroundColor: colors.teal,
    bottom: -16,
    height: 45,
    left: -3,
    position: 'absolute',
    transform: [{ rotate: '45deg' }],
    width: 45,
  },
  mountainRight: {
    backgroundColor: colors.tealDark,
    bottom: -18,
    height: 42,
    position: 'absolute',
    right: -1,
    transform: [{ rotate: '45deg' }],
    width: 42,
  },
  title: {
    color: colors.ink,
    fontSize: 17,
    fontWeight: '800',
    marginTop: 17,
  },
  description: {
    color: colors.text,
    fontSize: 13.5,
    lineHeight: 19,
    marginTop: 5,
    textAlign: 'center',
  },
  button: {
    backgroundColor: colors.yellow,
    borderRadius: 14,
    marginTop: 16,
    paddingHorizontal: 20,
    paddingVertical: 11,
  },
  buttonText: {
    color: '#573E00',
    fontSize: 14,
    fontWeight: '800',
  },
  pressed: {
    opacity: 0.78,
    transform: [{ scale: 0.98 }],
  },
});
