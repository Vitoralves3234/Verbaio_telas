import React from 'react';
import {
  Alert,
  Linking,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { colors } from '../../../theme/colors';
import { ARASAAC } from '../services/arasaacApi';

export function ArasaacAttribution() {
  async function openTerms() {
    try {
      await Linking.openURL(ARASAAC.licenseUrl);
    } catch {
      Alert.alert(
        'Créditos ARASAAC',
        `Consulte as condições de uso em ${ARASAAC.licenseUrl}`,
      );
    }
  }
  return (
    <View style={styles.container}>
      <Text style={styles.text}>
        Pictogramas: {ARASAAC.author} · {ARASAAC.owner} · ARASAAC
      </Text>
      <Pressable
        accessibilityRole="link"
        accessibilityLabel="Ver licença e créditos do ARASAAC"
        onPress={openTerms}
        style={styles.link}
      >
        <Text style={styles.linkText}>
          CC BY-NC-SA · Uso não comercial · Ver licença
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { paddingVertical: 10, alignItems: 'center' },
  text: {
    color: colors.muted,
    fontSize: 11,
    lineHeight: 17,
    textAlign: 'center',
  },
  link: { minHeight: 44, paddingHorizontal: 8, justifyContent: 'center' },
  linkText: {
    color: '#08777A',
    fontSize: 11.5,
    lineHeight: 17,
    textAlign: 'center',
    textDecorationLine: 'underline',
  },
});
