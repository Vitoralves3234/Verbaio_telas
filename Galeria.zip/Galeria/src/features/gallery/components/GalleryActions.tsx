import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

import { colors } from '../../../theme/colors';

type GalleryActionsProps = {
  disabled?: boolean;
  imageCount: number;
  onRemoveSelected: () => void;
  onToggleAll: () => void;
  selectedCount: number;
};

export function GalleryActions({
  disabled = false,
  imageCount,
  onRemoveSelected,
  onToggleAll,
  selectedCount,
}: GalleryActionsProps) {
  const allSelected = imageCount > 0 && selectedCount === imageCount;

  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.count}>{`${imageCount} ${
          imageCount === 1 ? 'imagem' : 'imagens'
        }`}</Text>
        <Text style={styles.selectedCount}>{`${selectedCount} ${
          selectedCount === 1 ? 'selecionada' : 'selecionadas'
        }`}</Text>
      </View>
      <View style={styles.buttons}>
        <Pressable
          accessibilityLabel={
            allSelected ? 'Desmarcar todas' : 'Selecionar todas'
          }
          accessibilityRole="button"
          disabled={disabled}
          accessibilityState={{ disabled }}
          onPress={onToggleAll}
          style={({ pressed }) => [
            styles.secondaryButton,
            pressed ? styles.pressed : null,
          ]}
        >
          <Text style={styles.secondaryButtonText}>
            {allSelected ? 'Desmarcar' : 'Todas'}
          </Text>
        </Pressable>
        {selectedCount > 0 ? (
          <Pressable
            accessibilityLabel="Remover imagens selecionadas"
            accessibilityRole="button"
            disabled={disabled}
            accessibilityState={{ disabled }}
            onPress={onRemoveSelected}
            style={({ pressed }) => [
              styles.removeButton,
              pressed ? styles.pressed : null,
            ]}
          >
            <Text style={styles.removeButtonText}>Remover</Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  count: {
    color: colors.ink,
    fontSize: 17,
    fontWeight: '800',
  },
  selectedCount: {
    color: colors.tealDark,
    fontSize: 12.5,
    fontWeight: '700',
    marginTop: 2,
  },
  buttons: {
    flexDirection: 'row',
    gap: 8,
  },
  secondaryButton: {
    backgroundColor: colors.tealSoft,
    borderRadius: 12,
    paddingHorizontal: 13,
    paddingVertical: 9,
  },
  secondaryButtonText: {
    color: colors.tealDark,
    fontSize: 12.5,
    fontWeight: '800',
  },
  removeButton: {
    backgroundColor: colors.pinkSoft,
    borderRadius: 12,
    paddingHorizontal: 13,
    paddingVertical: 9,
  },
  removeButtonText: {
    color: colors.pink,
    fontSize: 12.5,
    fontWeight: '800',
  },
  pressed: {
    opacity: 0.72,
  },
});
