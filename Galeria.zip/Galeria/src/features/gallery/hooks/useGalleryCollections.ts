import { useEffect, useRef, useState } from 'react';
import { Alert } from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';

import { galleryCollections, galleryKinds } from '../data/galleryCollections';
import { downloadArasaacPictograms } from '../services/arasaacStorage';
import { ArasaacPictogram } from '../types/arasaac';
import {
  importGalleryImages,
  loadGalleryImages,
  removeGalleryImages,
  saveGalleryImages,
} from '../services/galleryStorage';
import { GalleryImage, GalleryKind } from '../types/gallery';

type CollectionState = {
  images: GalleryImage[];
  loading: boolean;
  error: string | null;
};
type Collections = Record<GalleryKind, CollectionState>;
type Operation = 'import' | 'save' | 'remove';

function initialCollections(): Collections {
  return {
    images: { images: [], loading: true, error: null },
    cryptograms: { images: [], loading: true, error: null },
  };
}

export function useGalleryCollections() {
  const [collections, setCollections] =
    useState<Collections>(initialCollections);
  const [operation, setOperation] = useState<Operation | null>(null);
  const current = useRef(collections);
  const locked = useRef(false);
  const mounted = useRef(true);

  function update(kind: GalleryKind, patch: Partial<CollectionState>) {
    current.current = {
      ...current.current,
      [kind]: { ...current.current[kind], ...patch },
    };
    if (mounted.current) {
      setCollections(current.current);
    }
  }

  async function refresh(kind: GalleryKind) {
    update(kind, { loading: true, error: null });
    try {
      update(kind, { images: await loadGalleryImages(kind), loading: false });
    } catch {
      update(kind, {
        loading: false,
        error: 'Não foi possível carregar esta galeria. Tente novamente.',
      });
    }
  }

  useEffect(() => {
    mounted.current = true;
    galleryKinds.forEach((kind) => {
      refresh(kind);
    });
    return () => {
      mounted.current = false;
    };
    // A primeira leitura ocorre uma vez; novas leituras usam o botão Tentar novamente.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function run<T>(
    kind: GalleryKind,
    action: Operation,
    task: () => Promise<T>,
  ) {
    if (
      locked.current ||
      current.current[kind].loading ||
      current.current[kind].error
    ) {
      return;
    }
    locked.current = true;
    setOperation(action);
    try {
      return await task();
    } catch (cause) {
      if (mounted.current) {
        Alert.alert(
          'Não foi possível concluir',
          cause instanceof Error
            ? cause.message
            : 'Tente novamente em alguns instantes.',
        );
      }
    } finally {
      locked.current = false;
      if (mounted.current) {
        setOperation(null);
      }
    }
  }

  function addArasaacPictograms(pictograms: ArasaacPictogram[]) {
    return run('cryptograms', 'import', async () => {
      const existing = current.current.cryptograms.images;
      const existingIds = new Set(
        existing.map((image) => image.source?.pictogramId),
      );
      const pending = pictograms.filter((item) => !existingIds.has(item.id));
      if (!pending.length) {
        return pictograms.map((item) => item.id);
      }
      const {
        images: imported,
        failedIds,
        failures,
      } = await downloadArasaacPictograms(pending);
      if (!imported.length) {
        throw new Error(
          failures[0]?.message ||
            'Não foi possível adicionar os pictogramas. Tente novamente.',
        );
      }
      const next = [...existing, ...imported];
      try {
        await saveGalleryImages(next, 'cryptograms');
      } catch {
        await removeGalleryImages(imported, 'cryptograms').catch(
          () => undefined,
        );
        throw new Error(
          'Não foi possível salvar os pictogramas. Confira o espaço no celular e tente novamente.',
        );
      }
      update('cryptograms', { images: next });
      if (failedIds.length && mounted.current) {
        Alert.alert(
          'Adição parcial',
          `${imported.length} pictograma(s) adicionado(s). ${
            failedIds.length
          } continuam marcados para tentar novamente.\n\n${
            failures[0]?.message || ''
          }`,
        );
      }
      return pictograms
        .filter((item) => !failedIds.includes(item.id))
        .map((item) => item.id);
    });
  }

  function importImages(kind: GalleryKind) {
    return run(kind, 'import', async () => {
      const response = await launchImageLibrary({
        assetRepresentationMode: 'compatible',
        includeBase64: false,
        mediaType: 'photo',
        selectionLimit: 0,
      });
      if (response.didCancel || !mounted.current) {
        return;
      }
      if (response.errorCode) {
        throw new Error(
          response.errorMessage ||
            'Não foi possível abrir as imagens do celular.',
        );
      }
      const assets = response.assets || [];
      if (!assets.length) {
        return;
      }
      const imported = await importGalleryImages(assets, kind);
      if (!imported.length) {
        throw new Error(
          'Não foi possível copiar as imagens selecionadas. Tente novamente.',
        );
      }
      const next = [...current.current[kind].images, ...imported];
      try {
        await saveGalleryImages(next, kind);
      } catch {
        await removeGalleryImages(imported, kind).catch(() => undefined);
        throw new Error(
          'Não foi possível salvar a importação. Tente novamente.',
        );
      }
      update(kind, { images: next });
      if (imported.length < assets.length && mounted.current) {
        Alert.alert(
          'Importação parcial',
          `${imported.length} de ${
            assets.length
          } imagens foram adicionadas à galeria de ${galleryCollections[
            kind
          ].label.toLowerCase()}.`,
        );
      }
    });
  }

  function saveSelection(
    kind: GalleryKind,
    transform: (images: GalleryImage[]) => GalleryImage[],
  ) {
    return run(kind, 'save', async () => {
      const next = transform(current.current[kind].images);
      await saveGalleryImages(next, kind);
      update(kind, { images: next });
    });
  }

  function toggleImage(kind: GalleryKind, imageId: string) {
    return saveSelection(kind, (images) =>
      images.map((image) =>
        image.id === imageId ? { ...image, selected: !image.selected } : image,
      ),
    );
  }

  function toggleAll(kind: GalleryKind) {
    return saveSelection(kind, (images) => {
      const selected = !images.every((image) => image.selected);
      return images.map((image) => ({ ...image, selected }));
    });
  }

  function confirmRemove(kind: GalleryKind) {
    const selected = current.current[kind].images.filter(
      (image) => image.selected,
    );
    if (!selected.length || locked.current) {
      return;
    }
    Alert.alert(
      `Remover da galeria de ${galleryCollections[kind].label.toLowerCase()}?`,
      kind === 'cryptograms'
        ? `Remover ${selected.length} imagem(ns) selecionada(s) desta galeria? Você pode pesquisar e adicionar os pictogramas do ARASAAC novamente.`
        : `Remover ${selected.length} imagem(ns) selecionada(s) do Verbaio? Os arquivos originais do celular serão preservados.`,
      [
        { style: 'cancel', text: 'Cancelar' },
        {
          style: 'destructive',
          text: 'Remover',
          onPress: () =>
            run(kind, 'remove', async () => {
              const selectedIds = new Set(selected.map((image) => image.id));
              const remaining = current.current[kind].images.filter(
                (image) => !selectedIds.has(image.id),
              );
              await saveGalleryImages(remaining, kind);
              update(kind, { images: remaining });
              await removeGalleryImages(selected, kind);
            }),
        },
      ],
    );
  }

  return {
    collections,
    operation,
    refresh,
    importImages,
    addArasaacPictograms,
    toggleImage,
    toggleAll,
    confirmRemove,
  };
}
