import { useEffect, useRef, useState } from 'react';
import { searchArasaac } from '../services/arasaacApi';
import { ArasaacPictogram } from '../types/arasaac';

export function useArasaacSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ArasaacPictogram[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const request = useRef<AbortController | null>(null);

  useEffect(() => () => request.current?.abort(), []);

  function changeQuery(value: string) {
    request.current?.abort();
    setQuery(value);
    setLoading(false);
    setSearched(false);
    setError(null);
    setResults([]);
  }

  async function search() {
    if (!query.trim()) {
      return;
    }
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setLoading(true);
    setError(null);
    setSearched(true);
    setResults([]);
    try {
      const next = await searchArasaac(query, controller.signal);
      if (!controller.signal.aborted) {
        setResults(next);
      }
    } catch (cause) {
      if (!controller.signal.aborted) {
        setError(
          cause instanceof Error
            ? cause.message
            : 'Não foi possível pesquisar. Tente novamente.',
        );
      }
    } finally {
      if (!controller.signal.aborted) {
        setLoading(false);
      }
    }
  }

  return { query, results, loading, searched, error, changeQuery, search };
}
