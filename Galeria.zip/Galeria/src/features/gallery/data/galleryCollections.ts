import { GalleryKind } from '../types/gallery';

export const galleryKinds: GalleryKind[] = ['images', 'cryptograms'];

export const galleryCollections: Record<
  GalleryKind,
  {
    label: string;
    title: string;
    importTitle: string;
    importDescription: string;
    emptyTitle: string;
    emptyDescription: string;
  }
> = {
  images: {
    label: 'Imagens',
    title: 'Galeria de imagens',
    importTitle: 'Adicionar imagens',
    importDescription: 'Escolha uma ou várias fotos armazenadas no celular.',
    emptyTitle: 'Sua galeria está vazia',
    emptyDescription:
      'Importe imagens do celular para visualizá-las e selecioná-las aqui.',
  },
  cryptograms: {
    label: 'Criptogramas',
    title: 'Galeria de criptogramas',
    importTitle: 'Pesquisar no ARASAAC',
    importDescription:
      'Pesquise pictogramas em português e guarde seus favoritos nesta galeria.',
    emptyTitle: 'Nenhum criptograma adicionado',
    emptyDescription:
      'Encontre imagens no ARASAAC. Depois de adicionadas, elas ficam disponíveis mesmo sem internet.',
  },
};
