export type ArasaacPictogram = {
  id: number;
  label: string;
  keywords: string[];
};
