export type GalleryKind = 'images' | 'cryptograms';

export type GalleryImage = {
  source?: {
    provider: 'arasaac';
    pictogramId: number;
    pageUrl: string;
    imageUrl: string;
    author: string;
    owner: string;
    license: string;
    licenseUrl: string;
  };
  fileName: string;
  height?: number;
  id: string;
  importedAt: string;
  localPath: string;
  mimeType: string;
  selected: boolean;
  uri: string;
  width?: number;
};
