import React from 'react';
import { GalleryScreen } from './GalleryScreen';

/** Entrada opcional para abrir diretamente a segunda galeria. */
export function CryptogramGalleryScreen() {
  return <GalleryScreen initialGallery="cryptograms" />;
}
