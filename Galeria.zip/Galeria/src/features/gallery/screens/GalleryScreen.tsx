import React, { useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';

import { ScreenLayout } from '../../../shared/components/ScreenLayout';
import { colors } from '../../../theme/colors';
import { GalleryActions } from '../components/GalleryActions';
import { GalleryEmptyState } from '../components/GalleryEmptyState';
import { GalleryImageCard } from '../components/GalleryImageCard';
import { GalleryImportCard } from '../components/GalleryImportCard';
import { GalleryTabs } from '../components/GalleryTabs';
import { ArasaacAttribution } from '../components/ArasaacAttribution';
import { ArasaacSearchModal } from './ArasaacSearchModal';
import { galleryCollections } from '../data/galleryCollections';
import { useGalleryCollections } from '../hooks/useGalleryCollections';
import { GalleryKind } from '../types/gallery';

type GalleryScreenProps = { initialGallery?: GalleryKind };

export function GalleryScreen({
  initialGallery = 'images',
}: GalleryScreenProps) {
  const { width } = useWindowDimensions();
  const [searchOpen, setSearchOpen] = useState(false);
  const [activeGallery, setActiveGallery] =
    useState<GalleryKind>(initialGallery);
  const {
    collections,
    operation,
    refresh,
    importImages,
    addArasaacPictograms,
    toggleImage,
    toggleAll,
    confirmRemove,
  } = useGalleryCollections();
  const { images, loading, error } = collections[activeGallery];
  const copy = galleryCollections[activeGallery];
  const busy = operation !== null;
  const selectedCount = images.filter((image) => image.selected).length;
  const columns = width >= 600 ? 3 : width < 320 ? 1 : 2;
  const itemWidth = (width - 40 - (columns - 1) * 10) / columns;

  function addImages() {
    if (activeGallery === 'cryptograms') {
      setSearchOpen(true);
    } else {
      return importImages('images');
    }
  }

  return (
    <ScreenLayout
      subtitle="Organize suas imagens e seus criptogramas."
      title="Galeria"
    >
      <GalleryTabs
        active={activeGallery}
        disabled={busy}
        onChange={setActiveGallery}
      />
      <Text accessibilityRole="header" style={styles.title}>
        {copy.title}
      </Text>
      {loading ? (
        <View style={styles.status}>
          <ActivityIndicator color={colors.teal} />
          <Text style={styles.statusText}>Carregando imagens...</Text>
        </View>
      ) : error ? (
        <View style={styles.status}>
          <Text accessibilityRole="alert" style={styles.statusText}>
            {error}
          </Text>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Tentar carregar galeria novamente"
            onPress={() => refresh(activeGallery)}
            style={styles.retry}
          >
            <Text style={styles.retryText}>Tentar novamente</Text>
          </Pressable>
        </View>
      ) : (
        <>
          <GalleryImportCard
            disabled={busy}
            importing={operation === 'import'}
            kind={activeGallery}
            onImport={addImages}
          />
          {images.length ? (
            <>
              <GalleryActions
                disabled={busy}
                imageCount={images.length}
                onRemoveSelected={() => confirmRemove(activeGallery)}
                onToggleAll={() => toggleAll(activeGallery)}
                selectedCount={selectedCount}
              />
              <View style={styles.grid}>
                {images.map((image) => (
                  <GalleryImageCard
                    contain={activeGallery === 'cryptograms'}
                    disabled={busy}
                    image={image}
                    itemWidth={itemWidth}
                    key={image.id}
                    onToggle={() => toggleImage(activeGallery, image.id)}
                  />
                ))}
              </View>
              <View style={styles.note}>
                <Text style={styles.noteTitle}>Suas escolhas ficam salvas</Text>
                <Text style={styles.noteText}>
                  As imagens marcadas nesta galeria permanecem selecionadas
                  quando você voltar.
                </Text>
              </View>
            </>
          ) : (
            <GalleryEmptyState
              disabled={busy}
              kind={activeGallery}
              onImport={addImages}
            />
          )}
          {operation === 'save' || operation === 'remove' ? (
            <Text accessibilityLiveRegion="polite" style={styles.statusText}>
              Salvando alterações...
            </Text>
          ) : null}
        </>
      )}
      {activeGallery === 'cryptograms' ? <ArasaacAttribution /> : null}
      {searchOpen ? (
        <ArasaacSearchModal
          addedIds={collections.cryptograms.images.flatMap((item) =>
            item.source?.provider === 'arasaac'
              ? [item.source.pictogramId]
              : [],
          )}
          busy={busy}
          onAdd={addArasaacPictograms}
          onClose={() => setSearchOpen(false)}
        />
      ) : null}
    </ScreenLayout>
  );
}

const styles = StyleSheet.create({
  title: { color: colors.ink, fontSize: 19, fontWeight: '800', marginTop: 4 },
  status: { alignItems: 'center', gap: 12, paddingVertical: 28 },
  statusText: { color: colors.muted, fontSize: 14, textAlign: 'center' },
  retry: { backgroundColor: colors.teal, borderRadius: 12, padding: 14 },
  retryText: { color: colors.white, fontWeight: '700' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  note: {
    backgroundColor: colors.yellowSoft,
    borderColor: colors.yellow,
    borderRadius: 18,
    borderWidth: 1,
    padding: 16,
  },
  noteTitle: { color: colors.ink, fontSize: 14.5, fontWeight: '800' },
  noteText: { color: colors.text, fontSize: 13, lineHeight: 19, marginTop: 4 },
});
