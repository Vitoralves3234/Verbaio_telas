import React, { useEffect, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../../theme/colors';
import { ArasaacAttribution } from '../components/ArasaacAttribution';
import { ArasaacResultCard } from '../components/ArasaacResultCard';
import { useArasaacSearch } from '../hooks/useArasaacSearch';
import { MAX_ARASAAC_SELECTION } from '../services/arasaacApi';
import { ArasaacPictogram } from '../types/arasaac';

type Props = {
  addedIds: number[];
  busy: boolean;
  onClose: () => void;
  onAdd: (items: ArasaacPictogram[]) => Promise<number[] | undefined>;
};

export function ArasaacSearchModal({ addedIds, busy, onClose, onAdd }: Props) {
  const { query, results, loading, searched, error, changeQuery, search } =
    useArasaacSearch();
  const [selected, setSelected] = useState<ArasaacPictogram[]>([]);
  const [adding, setAdding] = useState(false);
  const locked = useRef(false);
  const mounted = useRef(true);
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const columns = width >= 600 ? 3 : width < 320 ? 1 : 2;
  const itemWidth = (width - 40 - (columns - 1) * 12) / columns;
  const added = new Set(addedIds);
  const pending = selected.filter((item) => !added.has(item.id));
  const disabled = busy || adding;

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  function close() {
    if (!locked.current && !busy) {
      onClose();
    }
  }

  function toggle(pictogram: ArasaacPictogram) {
    if (disabled || added.has(pictogram.id)) {
      return;
    }
    if (pending.some((item) => item.id === pictogram.id)) {
      setSelected((items) => items.filter((item) => item.id !== pictogram.id));
    } else if (pending.length >= MAX_ARASAAC_SELECTION) {
      Alert.alert(
        'Adicione em etapas',
        `Você pode adicionar até ${MAX_ARASAAC_SELECTION} pictogramas por vez.`,
      );
    } else {
      setSelected((items) => [...items, pictogram]);
    }
  }

  async function add() {
    if (locked.current || busy || !pending.length) {
      return;
    }
    locked.current = true;
    setAdding(true);
    try {
      const successful = await onAdd(pending);
      if (!mounted.current || !successful) {
        return;
      }
      const remaining = pending.filter((item) => !successful.includes(item.id));
      setSelected(remaining);
      if (!remaining.length) {
        onClose();
        Alert.alert(
          'Pictogramas adicionados',
          `${successful.length} pictograma(s) salvo(s) na sua galeria. Agora você pode selecioná-los mesmo sem internet.`,
        );
      }
    } finally {
      locked.current = false;
      if (mounted.current) {
        setAdding(false);
      }
    }
  }

  function submit() {
    if (disabled || loading) {
      return;
    }
    Keyboard.dismiss();
    return search();
  }

  return (
    <Modal visible animationType="slide" onRequestClose={close}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        style={[
          styles.screen,
          { paddingTop: insets.top, paddingBottom: insets.bottom },
        ]}
      >
        <View style={styles.header}>
          <View style={styles.headingRow}>
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Voltar para a galeria"
              accessibilityState={{ disabled }}
              disabled={disabled}
              onPress={close}
              style={styles.back}
            >
              <Text style={styles.backText}>‹</Text>
            </Pressable>
            <View style={styles.headingCopy}>
              <Text accessibilityRole="header" style={styles.title}>
                Pesquisar no ARASAAC
              </Text>
              <Text style={styles.subtitle}>Pictogramas em português</Text>
            </View>
          </View>
          <View style={styles.searchRow}>
            <TextInput
              accessibilityLabel="Pesquisar pictogramas em português"
              autoCapitalize="none"
              autoCorrect={false}
              editable={!disabled}
              maxLength={80}
              onChangeText={changeQuery}
              onSubmitEditing={submit}
              placeholder="Ex.: água, comer, casa"
              placeholderTextColor={colors.muted}
              returnKeyType="search"
              style={styles.input}
              value={query}
            />
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Buscar no ARASAAC"
              accessibilityState={{
                disabled: disabled || loading || !query.trim(),
                busy: loading,
              }}
              disabled={disabled || loading || !query.trim()}
              onPress={submit}
              style={[
                styles.searchButton,
                disabled || loading || !query.trim() ? styles.disabled : null,
              ]}
            >
              <Text style={styles.buttonText}>Buscar</Text>
            </Pressable>
          </View>
          {results.length ? (
            <Text accessibilityLiveRegion="polite" style={styles.resultCount}>
              {results.length} resultado(s) · Toque nas imagens que deseja
              adicionar.
            </Text>
          ) : null}
        </View>

        <FlatList
          data={results}
          key={columns}
          numColumns={columns}
          keyExtractor={(item) => String(item.id)}
          columnWrapperStyle={columns > 1 ? styles.row : undefined}
          contentContainerStyle={styles.list}
          keyboardShouldPersistTaps="handled"
          initialNumToRender={12}
          extraData={{ selected, addedIds, disabled }}
          renderItem={({ item }) => (
            <ArasaacResultCard
              pictogram={item}
              width={itemWidth}
              selected={pending.some((value) => value.id === item.id)}
              added={added.has(item.id)}
              disabled={disabled}
              onToggle={() => toggle(item)}
            />
          )}
          ListEmptyComponent={
            <View style={styles.empty}>
              {loading ? (
                <ActivityIndicator size="large" color={colors.tealDark} />
              ) : null}
              <Text
                accessibilityRole={error ? 'alert' : undefined}
                accessibilityLiveRegion="polite"
                style={styles.emptyTitle}
              >
                {loading
                  ? 'Buscando pictogramas...'
                  : error
                  ? 'Não foi possível pesquisar'
                  : searched
                  ? 'Nenhum pictograma encontrado'
                  : 'O que você quer encontrar?'}
              </Text>
              <Text style={styles.emptyText}>
                {error ||
                  (searched && !loading
                    ? 'Tente outra palavra, como água, comer ou brincar.'
                    : loading
                    ? 'Aguarde os resultados do ARASAAC.'
                    : 'Digite uma palavra e toque em Buscar. A pesquisa precisa de internet.')}
              </Text>
              {error ? (
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel="Tentar busca novamente"
                  onPress={submit}
                  disabled={disabled}
                  style={styles.retry}
                >
                  <Text style={styles.retryText}>Tentar novamente</Text>
                </Pressable>
              ) : null}
            </View>
          }
          ListFooterComponent={<ArasaacAttribution />}
        />

        <View style={styles.footer}>
          <View style={styles.selectionRow}>
            <Text accessibilityLiveRegion="polite" style={styles.selectionText}>
              {pending.length} selecionado(s)
            </Text>
            {pending.length ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Limpar seleção da busca"
                disabled={disabled}
                onPress={() => setSelected([])}
                style={styles.clear}
              >
                <Text style={styles.retryText}>Limpar seleção</Text>
              </Pressable>
            ) : null}
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Adicionar pictogramas selecionados"
            accessibilityState={{
              disabled: disabled || !pending.length,
              busy: disabled,
            }}
            disabled={disabled || !pending.length}
            onPress={add}
            style={[
              styles.addButton,
              disabled || !pending.length ? styles.disabled : null,
            ]}
          >
            {disabled ? <ActivityIndicator color={colors.white} /> : null}
            <Text style={styles.buttonText}>
              {disabled
                ? 'Baixando e salvando...'
                : `Adicionar à galeria${
                    pending.length ? ` (${pending.length})` : ''
                  }`}
            </Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background },
  header: { padding: 20, paddingBottom: 12 },
  headingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 18,
  },
  back: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.yellow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backText: { color: '#08777A', fontSize: 36, lineHeight: 40 },
  headingCopy: { flex: 1 },
  title: { color: colors.ink, fontSize: 20, fontWeight: '800' },
  subtitle: { color: colors.text, fontSize: 13, marginTop: 4 },
  searchRow: { flexDirection: 'row', gap: 8 },
  input: {
    flex: 1,
    minWidth: 0,
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.tealDark,
    borderRadius: 14,
    minHeight: 50,
    color: colors.ink,
    fontSize: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  searchButton: {
    backgroundColor: '#08777A',
    borderRadius: 14,
    paddingHorizontal: 16,
    justifyContent: 'center',
  },
  buttonText: {
    color: colors.white,
    fontSize: 14,
    fontWeight: '800',
    textAlign: 'center',
  },
  resultCount: {
    color: colors.text,
    fontSize: 12,
    lineHeight: 18,
    marginTop: 12,
  },
  list: { paddingHorizontal: 20, paddingBottom: 16 },
  row: { gap: 12 },
  empty: {
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 32,
    gap: 12,
  },
  emptyTitle: {
    color: colors.ink,
    fontSize: 17,
    fontWeight: '700',
    textAlign: 'center',
  },
  emptyText: {
    color: colors.text,
    fontSize: 14,
    lineHeight: 21,
    textAlign: 'center',
  },
  retry: { minHeight: 44, justifyContent: 'center', paddingHorizontal: 16 },
  retryText: { color: '#08777A', fontSize: 13, fontWeight: '700' },
  footer: {
    backgroundColor: colors.white,
    borderTopColor: colors.divider,
    borderTopWidth: 1,
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  selectionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 44,
  },
  selectionText: { color: colors.text, fontSize: 13 },
  clear: { minHeight: 44, justifyContent: 'center' },
  addButton: {
    flexDirection: 'row',
    gap: 10,
    minHeight: 50,
    borderRadius: 16,
    backgroundColor: '#08777A',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
  },
  disabled: { opacity: 0.5 },
});
