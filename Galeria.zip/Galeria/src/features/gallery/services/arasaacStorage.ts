import ReactNativeBlobUtil from 'react-native-blob-util';

import { ArasaacPictogram } from '../types/arasaac';
import { GalleryImage } from '../types/gallery';
import { ARASAAC, arasaacImageUrl, MAX_ARASAAC_SELECTION } from './arasaacApi';
import { ensureGalleryDirectory, getGalleryDirectory } from './galleryStorage';

const MAX_PNG_BYTES = 2 * 1024 * 1024;

type DownloadFailure = { id: number; message: string };

function errorDetail(cause: unknown) {
  return (cause instanceof Error ? cause.message : String(cause)).slice(0, 200);
}

function validatePng(base64: unknown): { content: string; byteLength: number } {
  if (typeof base64 !== 'string' || !base64.length) {
    throw new Error('O ARASAAC não enviou o conteúdo da imagem.');
  }
  if (base64.length > Math.ceil(MAX_PNG_BYTES / 3) * 4) {
    throw new Error('O pictograma excede o tamanho permitido de 2 MB.');
  }
  // Valida o conteúdo, sem depender do nome de um cabeçalho HTTP.
  const data = ReactNativeBlobUtil.base64.decode(base64);
  const signature = '\x89PNG\r\n\x1a\n';
  const ending = '\x00\x00\x00\x00IEND\xaeB\x60\x82';
  if (
    data.length < 45 ||
    data.length > MAX_PNG_BYTES ||
    !data.startsWith(signature) ||
    !data.endsWith(ending)
  ) {
    throw new Error(
      'O arquivo recebido não é um PNG completo. Tente adicionar o pictograma novamente.',
    );
  }
  return { content: base64, byteLength: data.length };
}

async function downloadOne(pictogram: ArasaacPictogram): Promise<GalleryImage> {
  const imageUrl = arasaacImageUrl(pictogram.id);
  const id = `arasaac-${pictogram.id}-${Date.now().toString(36)}-${Math.random()
    .toString(36)
    .slice(2, 8)}`;
  const localPath = `${getGalleryDirectory('cryptograms')}/${id}.png`;
  let stage: 'download' | 'validate' | 'save' = 'download';
  try {
    // Evita FileStorage de react-native-blob-util 0.24.10 no Android:
    // sua leitura do stream pode terminar antes de gravar todo o PNG.
    // Recebe o arquivo inteiro em memória e grava os bytes somente depois.
    const response = await ReactNativeBlobUtil.config({
      timeout: 20000,
      fileCache: false,
    }).fetch('GET', imageUrl, {
      Accept: 'image/png',
      'RNFB-Response': 'base64',
    });
    const status = Number(response.info().status);
    if (status !== 200) {
      throw new Error(
        Number.isFinite(status)
          ? `O ARASAAC respondeu com erro HTTP ${status}.`
          : 'Não foi possível confirmar a resposta do ARASAAC.',
      );
    }
    stage = 'validate';
    const { content, byteLength } = validatePng(await response.base64());
    stage = 'save';
    await ReactNativeBlobUtil.fs.writeFile(localPath, content, 'base64');
    if (
      !(await ReactNativeBlobUtil.fs.exists(localPath)) ||
      Number((await ReactNativeBlobUtil.fs.stat(localPath)).size) !== byteLength
    ) {
      throw new Error('A imagem não foi gravada por completo no aplicativo.');
    }
    return {
      id,
      fileName: `${pictogram.label}.png`,
      importedAt: new Date().toISOString(),
      localPath,
      mimeType: 'image/png',
      selected: false,
      uri: `file://${localPath}`,
      source: {
        provider: 'arasaac',
        pictogramId: pictogram.id,
        pageUrl: `${ARASAAC.websiteUrl}/pictograms/pt/${pictogram.id}`,
        imageUrl,
        author: ARASAAC.author,
        owner: ARASAAC.owner,
        license: ARASAAC.license,
        licenseUrl: ARASAAC.licenseUrl,
      },
    };
  } catch (cause) {
    if (stage === 'save') {
      await ReactNativeBlobUtil.fs.unlink(localPath).catch(() => undefined);
    }
    const action =
      stage === 'save' ? 'salvar' : stage === 'validate' ? 'validar' : 'baixar';
    throw new Error(
      `Não foi possível ${action} “${pictogram.label}” (ARASAAC ${
        pictogram.id
      }).\n${errorDetail(cause)}`,
    );
  }
}

export async function downloadArasaacPictograms(
  pictograms: ArasaacPictogram[],
) {
  const unique = [
    ...new Map(pictograms.map((item) => [item.id, item])).values(),
  ];
  if (unique.length > MAX_ARASAAC_SELECTION) {
    throw new Error(
      `Adicione até ${MAX_ARASAAC_SELECTION} pictogramas de cada vez.`,
    );
  }
  await ensureGalleryDirectory('cryptograms');
  const images: GalleryImage[] = [];
  const failedIds: number[] = [];
  const failures: DownloadFailure[] = [];
  // Três downloads por vez evitam abrir dezenas de conexões no celular.
  for (let start = 0; start < unique.length; start += 3) {
    const batch = unique.slice(start, start + 3);
    const results = await Promise.allSettled(batch.map(downloadOne));
    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        images.push(result.value);
      } else {
        failedIds.push(batch[index].id);
        failures.push({
          id: batch[index].id,
          message: errorDetail(result.reason),
        });
      }
    });
  }
  return { images, failedIds, failures };
}
