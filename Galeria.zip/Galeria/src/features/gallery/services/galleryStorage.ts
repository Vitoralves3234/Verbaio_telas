import ReactNativeBlobUtil from 'react-native-blob-util';
import { Asset } from 'react-native-image-picker';

import { GalleryImage, GalleryKind } from '../types/gallery';

export function getGalleryDirectory(kind: GalleryKind) {
  const folder =
    kind === 'cryptograms' ? 'verbaio-cryptograms' : 'verbaio-gallery';
  return `${ReactNativeBlobUtil.fs.dirs.DocumentDir}/${folder}`;
}

function belongsToGallery(localPath: string, kind: GalleryKind) {
  const prefix = `${getGalleryDirectory(kind)}/`;
  if (!localPath.startsWith(prefix)) {
    return false;
  }
  const fileName = localPath.slice(prefix.length);
  return /^[a-z0-9-]+\.(jpg|jpeg|png|webp|heic|heif|gif|bmp|avif)$/i.test(
    fileName,
  );
}

export async function ensureGalleryDirectory(kind: GalleryKind) {
  const galleryDirectory = getGalleryDirectory(kind);
  const exists = await ReactNativeBlobUtil.fs.exists(galleryDirectory);

  if (!exists) {
    await ReactNativeBlobUtil.fs.mkdir(galleryDirectory);
  }
}

function safeExtension(asset: Asset) {
  const fileNameExtension = asset.fileName?.split('.').pop()?.toLowerCase();

  if (
    fileNameExtension?.match(/^(jpg|jpeg|png|webp|heic|heif|gif|bmp|avif)$/)
  ) {
    return fileNameExtension;
  }

  if (asset.type === 'image/png') {
    return 'png';
  }

  if (asset.type === 'image/webp') {
    return 'webp';
  }

  if (asset.type === 'image/heic' || asset.type === 'image/heif') {
    return 'heic';
  }

  return 'jpg';
}

function makeImageId(index: number) {
  return `${Date.now().toString(36)}-${index}-${Math.random()
    .toString(36)
    .slice(2, 8)}`;
}

async function copyAssetToGallery(
  asset: Asset,
  index: number,
  kind: GalleryKind,
) {
  if (!asset.uri || (asset.type && !asset.type.startsWith('image/'))) {
    return null;
  }

  const id = makeImageId(index);
  const extension = safeExtension(asset);
  const localPath = `${getGalleryDirectory(kind)}/${id}.${extension}`;

  if (asset.uri.startsWith('content://')) {
    await ReactNativeBlobUtil.MediaCollection.copyToInternal(
      asset.uri,
      localPath,
    );
  } else {
    await ReactNativeBlobUtil.fs.cp(
      asset.uri.replace(/^file:\/\//, ''),
      localPath,
    );
  }

  if (!(await ReactNativeBlobUtil.fs.exists(localPath))) {
    throw new Error('A imagem não foi copiada para o aplicativo.');
  }

  const image: GalleryImage = {
    fileName: asset.fileName || `imagem-${id}.${extension}`,
    height: asset.height,
    id,
    importedAt: new Date().toISOString(),
    localPath,
    mimeType: asset.type || `image/${extension}`,
    selected: false,
    uri: `file://${localPath}`,
    width: asset.width,
  };

  return image;
}

export async function importGalleryImages(
  assets: Asset[],
  kind: GalleryKind = 'images',
) {
  await ensureGalleryDirectory(kind);
  const results = await Promise.allSettled(
    assets.map((asset, index) => copyAssetToGallery(asset, index, kind)),
  );

  return results.flatMap((result) =>
    result.status === 'fulfilled' && result.value ? [result.value] : [],
  );
}

export async function loadGalleryImages(
  kind: GalleryKind = 'images',
): Promise<GalleryImage[]> {
  const galleryIndexPath = `${getGalleryDirectory(kind)}/gallery.json`;
  const backupPath = `${galleryIndexPath}.backup`;
  const indexExists = await ReactNativeBlobUtil.fs.exists(galleryIndexPath);

  if (!indexExists && !(await ReactNativeBlobUtil.fs.exists(backupPath))) {
    return [];
  }

  const content = await ReactNativeBlobUtil.fs.readFile(
    indexExists ? galleryIndexPath : backupPath,
    'utf8',
  );
  const images: unknown = JSON.parse(content);
  if (
    !Array.isArray(images) ||
    images.some(
      (image) =>
        !image ||
        typeof image.id !== 'string' ||
        typeof image.fileName !== 'string' ||
        typeof image.localPath !== 'string' ||
        !belongsToGallery(image.localPath, kind),
    )
  ) {
    throw new Error(
      'Não foi possível ler esta galeria. Tente carregar novamente.',
    );
  }
  const checkedImages = await Promise.all(
    images.map(async (image) => ({
      exists: await ReactNativeBlobUtil.fs.exists(image.localPath),
      image,
    })),
  );

  return checkedImages
    .filter((item) => item.exists)
    .map((item) => ({
      ...item.image,
      selected: Boolean(item.image.selected),
      uri: `file://${item.image.localPath}`,
    }));
}

export async function saveGalleryImages(
  images: GalleryImage[],
  kind: GalleryKind = 'images',
) {
  if (images.some((image) => !belongsToGallery(image.localPath, kind))) {
    throw new Error('A imagem pertence a outra galeria.');
  }
  await ensureGalleryDirectory(kind);
  const galleryIndexPath = `${getGalleryDirectory(kind)}/gallery.json`;
  const temporaryPath = `${galleryIndexPath}.next`;
  const backupPath = `${galleryIndexPath}.backup`;
  // Só substitui o índice após escrever o novo conteúdo completo.
  await ReactNativeBlobUtil.fs.writeFile(
    temporaryPath,
    JSON.stringify(images),
    'utf8',
  );
  const hadIndex = await ReactNativeBlobUtil.fs.exists(galleryIndexPath);
  if (hadIndex) {
    await ReactNativeBlobUtil.fs.mv(galleryIndexPath, backupPath);
  }
  try {
    await ReactNativeBlobUtil.fs.mv(temporaryPath, galleryIndexPath);
  } catch (cause) {
    if (hadIndex) {
      await ReactNativeBlobUtil.fs.mv(backupPath, galleryIndexPath);
    }
    throw cause;
  }
}

export async function removeGalleryImages(
  images: GalleryImage[],
  kind: GalleryKind = 'images',
) {
  if (images.some((image) => !belongsToGallery(image.localPath, kind))) {
    throw new Error('A imagem pertence a outra galeria.');
  }
  const results = await Promise.allSettled(
    images.map(async (image) => {
      const exists = await ReactNativeBlobUtil.fs.exists(image.localPath);

      if (exists) {
        await ReactNativeBlobUtil.fs.unlink(image.localPath);
      }
    }),
  );
  if (results.some((result) => result.status === 'rejected')) {
    throw new Error(
      'As imagens saíram da lista, mas algumas cópias locais não puderam ser apagadas.',
    );
  }
}

/** A futura atividade escolhe explicitamente de qual galeria ler a seleção. */
export async function loadSelectedGalleryImages(kind: GalleryKind = 'images') {
  return (await loadGalleryImages(kind)).filter((image) => image.selected);
}
