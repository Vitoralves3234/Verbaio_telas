import { ArasaacPictogram } from '../types/arasaac';

export const ARASAAC = {
  apiUrl: 'https://api.arasaac.org/v1',
  websiteUrl: 'https://arasaac.org',
  author: 'Sergio Palao',
  owner: 'Gobierno de Aragón',
  license: 'CC BY-NC-SA',
  licenseUrl: 'https://arasaac.org/terms-of-use',
} as const;

export const MAX_ARASAAC_SELECTION = 20;
export const ARASAAC_SEARCH_TIMEOUT = 15000;

export function arasaacImageUrl(id: number) {
  if (!Number.isSafeInteger(id) || id <= 0) {
    throw new Error('O identificador do pictograma é inválido.');
  }
  return `https://static.arasaac.org/pictograms/${id}/${id}_500.png`;
}

function normalizeResults(data: unknown): ArasaacPictogram[] {
  if (!Array.isArray(data)) {
    throw new Error(
      'O ARASAAC enviou uma resposta inesperada. Tente novamente.',
    );
  }
  const seen = new Set<number>();
  return data.flatMap((item) => {
    if (
      !item ||
      !Number.isSafeInteger(item._id) ||
      item._id <= 0 ||
      seen.has(item._id)
    ) {
      return [];
    }
    seen.add(item._id);
    const keywords: string[] = Array.isArray(item.keywords)
      ? item.keywords.flatMap((word: { keyword?: unknown } | null) =>
          typeof word?.keyword === 'string' && word.keyword.trim()
            ? [word.keyword.trim()]
            : [],
        )
      : [];
    return [
      {
        id: item._id,
        label: keywords[0] || `Pictograma ${item._id}`,
        keywords,
      },
    ];
  });
}

/** Consulta em português. A API retorna 404 quando não há correspondências. */
export async function searchArasaac(
  query: string,
  signal?: AbortSignal,
): Promise<ArasaacPictogram[]> {
  const term = query.trim().slice(0, 80);
  if (!term) {
    return [];
  }
  const controller = new AbortController();
  const abort = () => controller.abort();
  signal?.addEventListener('abort', abort);
  if (signal?.aborted) {
    abort();
  }
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    abort();
  }, ARASAAC_SEARCH_TIMEOUT);
  try {
    const response = await fetch(
      `${ARASAAC.apiUrl}/pictograms/pt/bestsearch/${encodeURIComponent(term)}`,
      { headers: { Accept: 'application/json' }, signal: controller.signal },
    );
    if (response.status === 404) {
      return [];
    }
    if (!response.ok) {
      throw new Error(
        response.status === 429
          ? 'O ARASAAC recebeu muitas buscas. Aguarde um pouco e tente novamente.'
          : 'O ARASAAC está indisponível no momento. Tente novamente.',
      );
    }
    return normalizeResults(await response.json());
  } catch (cause) {
    if (signal?.aborted) {
      throw cause;
    }
    if (timedOut) {
      throw new Error(
        'A busca demorou para responder. Confira sua conexão e tente novamente.',
      );
    }
    if (cause instanceof TypeError) {
      throw new Error(
        'Não foi possível conectar ao ARASAAC. Confira sua internet e tente novamente.',
      );
    }
    throw cause;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener('abort', abort);
  }
}
