import React from 'react';
import {
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { colors } from '../../theme/colors';

const backgroundWave = require('../../assets/comuns/faixa_ondulada_cabecalho.png');
const logo = require('../../assets/comuns/logo_verbao.png');
const backButton = require('../../assets/comuns/botao_voltar.png');

type AppHeaderProps = {
  onBack?: () => void;
  subtitle?: string;
  title: string;
};

export function AppHeader({ onBack, subtitle, title }: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const compact = width < 360;
  const multilineTitle = title.length > 22;
  const waveHeight = Math.round((width * 130) / 900);
  const contentHeight = subtitle ? (compact ? 124 : 134) : compact ? 102 : 112;
  const totalHeight = insets.top + contentHeight + waveHeight;

  return (
    <View style={[styles.header, { height: totalHeight }]}>
      <View
        style={[
          styles.headerContent,
          {
            height: insets.top + contentHeight,
            paddingTop: insets.top + 12,
          },
        ]}
      >
        <View style={styles.titleGroup}>
          {onBack ? (
            <Pressable
              accessibilityLabel="Voltar"
              accessibilityRole="button"
              hitSlop={10}
              onPress={onBack}
              style={({ pressed }) => [
                styles.backPressable,
                pressed ? styles.pressed : null,
              ]}
            >
              <Image source={backButton} style={styles.backImage} />
            </Pressable>
          ) : null}

          <View style={styles.titleCopy}>
            <Text
              adjustsFontSizeToFit
              minimumFontScale={0.72}
              numberOfLines={multilineTitle ? 2 : 1}
              style={[
                styles.title,
                compact ? styles.compactTitle : null,
                multilineTitle ? styles.multilineTitle : null,
              ]}
            >
              {title}
            </Text>
            {subtitle ? (
              <Text numberOfLines={2} style={styles.subtitle}>
                {subtitle}
              </Text>
            ) : null}
          </View>
        </View>

        <Image source={logo} style={styles.logo} />
      </View>

      <Image
        resizeMode="stretch"
        source={backgroundWave}
        style={[styles.wave, { height: waveHeight }]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: colors.teal,
    overflow: 'hidden',
    width: '100%',
  },
  headerContent: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    zIndex: 1,
  },
  titleGroup: {
    alignItems: 'center',
    flex: 1,
    flexDirection: 'row',
    minWidth: 0,
  },
  backPressable: {
    borderRadius: 28,
    marginRight: 13,
  },
  backImage: {
    height: 48,
    width: 48,
  },
  title: {
    color: colors.white,
    flexShrink: 1,
    fontSize: 29,
    fontWeight: '800',
    letterSpacing: -0.6,
  },
  titleCopy: {
    flex: 1,
    minWidth: 0,
  },
  subtitle: {
    color: colors.white,
    fontSize: 13.5,
    fontWeight: '600',
    lineHeight: 18,
    marginTop: 4,
    maxWidth: 255,
  },
  compactTitle: {
    fontSize: 26,
  },
  multilineTitle: {
    fontSize: 24,
    lineHeight: 27,
  },
  logo: {
    height: 68,
    marginLeft: 10,
    resizeMode: 'contain',
    width: 83,
  },
  wave: {
    bottom: 0,
    left: 0,
    position: 'absolute',
    width: '100%',
  },
  pressed: {
    opacity: 0.72,
    transform: [{ scale: 0.97 }],
  },
});
