import React from 'react';
import {
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  View,
} from 'react-native';

import { colors } from '../../theme/colors';
import { AppHeader } from './AppHeader';

type ScreenLayoutProps = {
  children: React.ReactNode;
  onBack?: () => void;
  subtitle?: string;
  title: string;
};

export function ScreenLayout({
  children,
  onBack,
  subtitle,
  title,
}: ScreenLayoutProps) {
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={styles.screen}
    >
      <ScrollView
        alwaysBounceVertical={false}
        bounces={false}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <AppHeader onBack={onBack} subtitle={subtitle} title={title} />
        <View style={styles.content}>{children}</View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: {
    backgroundColor: colors.background,
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 28,
  },
  content: {
    gap: 14,
    marginTop: 7,
    paddingHorizontal: 20,
  },
});
