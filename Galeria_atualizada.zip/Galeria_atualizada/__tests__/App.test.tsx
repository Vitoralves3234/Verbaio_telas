import React from 'react';
import { launchImageLibrary } from 'react-native-image-picker';
import { act, create, ReactTestRenderer } from 'react-test-renderer';

import App from '../App';
import { loadGalleryImages } from '../src/features/gallery/services/galleryStorage';
import { createNativeFileMock } from '../test-support/galleryFiles';

describe('entrada independente da galeria', () => {
  let tree: ReactTestRenderer;
  let files: Map<string, string>;

  beforeEach(() => {
    jest.resetAllMocks();
    files = createNativeFileMock().files;
  });

  afterEach(async () => {
    await act(async () => tree.unmount());
  });

  it('abre a galeria com as duas abas sem depender de perfil ou métricas', async () => {
    await act(async () => {
      tree = create(<App />);
    });
    expect(tree.root.findByProps({ title: 'Galeria' })).toBeTruthy();
    expect(
      tree.root.findByProps({ accessibilityLabel: 'Galeria de imagens' }),
    ).toBeTruthy();
    expect(
      tree.root.findByProps({ accessibilityLabel: 'Galeria de criptogramas' }),
    ).toBeTruthy();
    expect(
      tree.root.findByProps({ children: 'Sua galeria está vazia' }),
    ).toBeTruthy();
  });

  it('continua importando várias fotos na galeria original pelo seletor Android', async () => {
    files.set('content://photos/1', 'image-one');
    files.set('content://photos/2', 'image-two');
    (launchImageLibrary as jest.Mock).mockResolvedValueOnce({
      assets: [
        {
          fileName: 'foto-um.jpg',
          type: 'image/jpeg',
          uri: 'content://photos/1',
        },
        {
          fileName: 'foto-dois.png',
          type: 'image/png',
          uri: 'content://photos/2',
        },
      ],
    });
    await act(async () => {
      tree = create(<App />);
    });
    await act(async () => {
      await tree.root
        .findByProps({ accessibilityLabel: 'Importar imagens do celular' })
        .props.onPress();
    });
    expect(launchImageLibrary).toHaveBeenCalledWith(
      expect.objectContaining({ mediaType: 'photo', selectionLimit: 0 }),
    );
    expect(tree.root.findByProps({ children: '2 imagens' })).toBeTruthy();
    expect(await loadGalleryImages()).toHaveLength(2);
    expect(await loadGalleryImages('cryptograms')).toHaveLength(0);
  });
});
