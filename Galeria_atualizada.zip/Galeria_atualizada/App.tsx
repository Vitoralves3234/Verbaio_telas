import React from 'react';
import { StatusBar } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { GalleryScreen } from './src/features/gallery/screens/GalleryScreen';
import { colors } from './src/theme/colors';

function App() {
  return (
    <SafeAreaProvider>
      <StatusBar
        backgroundColor={colors.teal}
        barStyle="light-content"
        translucent={false}
      />
      <GalleryScreen />
    </SafeAreaProvider>
  );
}

export default App;
